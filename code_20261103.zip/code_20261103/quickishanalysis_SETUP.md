# quickishanalysis — setup guide (Windows, Anaconda Prompt)

Takes about 10 minutes the first time. You need **Anaconda or Miniconda** installed and an internet connection.
Every command below is typed in **Anaconda Prompt** (Start menu → *Anaconda Prompt*), not in a normal Command Prompt.
The commands use `D:\Claude_Workspace\local data analysis module` as the project folder. On another machine,
replace it with your own folder (for example `D:\pypack`).

---

## Folder structure

```
D:\Claude_Workspace\local data analysis module\      ← project folder
│
├── quickishanalysis\              THE MODULE — only these five files
│   ├── quickishanalysis.py        the module: class Quickish + cleaning helpers
│   ├── quickishanalysis.yaml      settings; must stay beside the .py with the same name
│   ├── quickishanalysis_prompt.md the AI-prompt template used by to_markdown(): description, instructions,
│   │                              guardrails — edit the wording freely, keep {task} {module_reference} {data}
│   ├── requirements.txt           packages to install (step 5)
│   └── SETUP.md                   this guide
│
├── notebooks\                     your notebooks (demo.ipynb is here)
├── data\                          input files (data\sample_data holds the demo data)
│   └── docs\                      data dictionaries / notes offered by to_markdown(has_doc=True)
├── outputs\                       everything the module writes
│   ├── .qa_clean\                 datasets loaded with storage="parquet" — SESSION ONLY, emptied at startup/close
│   ├── .qa_tmp\                   DuckDB spill files (incl. memory datasets above engine.memory_limit)
│   ├── .qa_answers\               your saved answers to prompts (kept)
│   ├── qa_pivots\                 explore() pages (deleted after 1 day)
│   ├── qa_charts\                 saved charts
│   ├── exports\                   export() files (by convention)
│   └── qa_prompt.md               to_markdown() prompt (overwritten each time)
│
└── plan\                          module plan + templates
```

The settings in `quickishanalysis.yaml` use paths relative to the `quickishanalysis\` folder, so `..` means the
project folder. That's how outputs land in `outputs\` and why `qa.load("data/...")` works from any notebook.

---

## Step 1 — Open Anaconda Prompt and check conda

```bat
conda --version
```

Note the number. **Step 2b depends on it:** conda **23.9 or newer** can use the Windows certificate store
(`truststore`); older versions can't, and setting it on an older conda breaks every conda command.

---

## Step 2 — Prevent SSL certificate errors on the work laptop (once per laptop)

Work laptops often inspect HTTPS traffic with a company certificate, so conda and pip refuse to download
(`SSL: CERTIFICATE_VERIFY_FAILED`). Set both up once. The settings are saved in your Windows user profile and apply
to every environment.

**2a. pip:** trust the two Python package sites:

```bat
pip config set global.trusted-host "pypi.org files.pythonhosted.org"
pip config list
```

Expected: `global.trusted-host='pypi.org files.pythonhosted.org'`

> What this does: pip stops checking the certificate for those two sites only. That fixes the error, but it also
> means a tampered download from those sites wouldn't be detected. Recent pip (24.2+) on Python 3.10+ already
> trusts the Windows certificate store, where IT installs the company certificate, so this is often just a safety
> net. To undo: `pip config unset global.trusted-host`

**2b. conda:** what to do depends on the version from step 1.

**conda 23.9 or newer:** use the Windows certificate store (the safe equivalent of 2a):

```bat
conda config --set ssl_verify truststore
conda config --show ssl_verify
```

Expected: `ssl_verify: truststore`

**conda older than 23.9** (e.g. 4.12): **do not** set `truststore`. Change nothing now. If step 4 then fails with
`CERTIFICATE_VERIFY_FAILED` **or** `HTTP 000 CONNECTION FAILED`, use the fallback below. Old conda reports a
rejected company certificate as a connection failure, even though the same link opens fine in your browser.

> **Fallback (any version), only if step 4 fails with an SSL or `HTTP 000` error:** switch checking off for that
> one command, then back on. This is what worked on conda 4.12 on the bank network:
> ```bat
> conda config --set ssl_verify false
> conda create -n quickish -c conda-forge --override-channels python=3.12 pip -y
> conda config --set ssl_verify true
> ```
> (On conda 23.9+, set it back to `truststore` instead of `true`.) After the environment exists, every other
> package installs with pip, which uses step 2a, so conda only needs to download again when you create another
> environment.
>
> If IT gave you a certificate file (`.pem` / `.crt`), it works on every version and is the cleanest fix:
> `conda config --set ssl_verify "C:\path\to\company-root.pem"`

**2c. Only if your office requires a proxy** (ask IT for the address):

```bat
pip config set global.proxy http://proxy-host:port
conda config --set proxy_servers.http  http://proxy-host:port
conda config --set proxy_servers.https http://proxy-host:port
```

---

## Step 3 — Create the project folders

```bat
cd /d "D:\Claude_Workspace\local data analysis module"

if not exist quickishanalysis mkdir quickishanalysis
if not exist notebooks        mkdir notebooks
if not exist data             mkdir data
if not exist outputs\exports  mkdir outputs\exports
if not exist plan             mkdir plan
```

Put the five module files in `quickishanalysis\` (already done if you received the folder ready-made) and check:

```bat
dir /b quickishanalysis
```

Expected: `quickishanalysis.py  quickishanalysis.yaml  quickishanalysis_prompt.md  requirements.txt  SETUP.md`

The `outputs\.qa_*` subfolders are created automatically the first time the module starts.

---

## Step 4 — Create and activate the conda environment

```bat
conda create -n quickish -c conda-forge --override-channels python=3.12 pip -y
conda activate quickish
```

The prompt now starts with `(quickish)`. **Every remaining step must run in this environment.**
After closing the window: reopen Anaconda Prompt and run `conda activate quickish` again.

* **Why conda-forge:** it's the free community channel. Anaconda's own default channel requires a paid licence at
  larger organisations and is often blocked on work networks. If your company has a licence, you can drop
  `-c conda-forge --override-channels`.
* **Fails with `CERTIFICATE_VERIFY_FAILED` or `HTTP 000 CONNECTION FAILED`?** Use the step 2b fallback.
* **`PackagesNotFoundError` for python 3.12** (possible with very old conda): use `python=3.11` instead. The module
  needs 3.10 or newer.
* **Older conda (4.x) can sit on "Solving environment" for several minutes.** Let it run.
* After this step conda isn't needed again: everything else installs with pip (step 2a settings).

---

## Step 5 — Install the packages

```bat
cd /d "D:\Claude_Workspace\local data analysis module\quickishanalysis"
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

This takes a few minutes and ends with `Successfully installed ...`.
If it fails with an SSL error, check `pip config list` shows the `trusted-host` line (step 2a).

| Group | Packages |
|---|---|
| Core | duckdb, pandas, pyarrow, fastparquet, pyyaml, plotly, openpyxl, xlrd, pyxlsb |
| Optional | polars (faster reading), pivottablejs (`explore()`), pyperclip (prompt → clipboard) |
| Notebook | ipykernel, nbformat, notebook |

---

## Step 6 — Register the Jupyter kernel

```bat
python -m ipykernel install --user --name quickishanalysis --display-name "Python (quickishanalysis)"
```

Notebooks (Jupyter or VS Code) can now select **Python (quickishanalysis)**, which runs in this environment.

---

## Step 7 — Check the module works

One line, still in the `quickishanalysis` folder with `(quickish)` active:

```bat
python -c "from quickishanalysis import Quickish; qa = Quickish.startup(); print(qa.sql('select 42 as ok')); qa.close()"
```

Expected: a few `INFO` lines, then a small table with `ok` and `42`.

---

## Step 8 — Open the demo notebook

**Jupyter in the browser:**

```bat
cd /d "D:\Claude_Workspace\local data analysis module\notebooks"
jupyter notebook demo.ipynb
```

Then **Kernel → Change kernel → Python (quickishanalysis)**, and **Run → Run All Cells**.

**VS Code:** open the project folder, open `notebooks\demo.ipynb`, click **Select Kernel → Jupyter Kernel →
Python (quickishanalysis)**, then **Run All**.

The demo reads `data\sample_data\`. If that folder is missing, the load cells will fail.

---

## Using the module in your own notebooks

The module isn't installed into the environment, so each notebook tells Python where to find it.
First cell of every notebook:

```python
import sys
sys.path.insert(0, r"D:\Claude_Workspace\local data analysis module\quickishanalysis")

import pandas as pd
from quickishanalysis import Quickish

qa = Quickish.startup()
```

* Keep the `r` before the path; without it, backslashes such as `\t` or `\n` are read as special characters.
* `insert(0, ...)` rather than `append(...)`, so this folder wins over any other copy Python might find.
* Don't name a variable `dir`: it replaces Python's built-in `dir()` for the rest of the notebook.
* If you move the module folder, update this line in your notebooks.

Paths you give to `qa.load()` / `qa.export()` are relative to the project folder (`"data/..."`,
`"outputs/exports/..."`), or use full paths like `r"D:\exports\sales.csv"`.

**Where cleaned data lives:** by default (`io.storage: "memory"`) each dataset is a DuckDB table in RAM, gone when
the session closes. `qa.load(..., storage="parquet")` stores it as a file in `outputs\.qa_clean` instead.

**One notebook at a time:** starting or closing a second session clears `outputs\.qa_clean`, which breaks the
other notebook's Parquet-stored datasets (memory datasets are per notebook and not affected).

**Every day:**

```bat
conda activate quickish
cd /d "D:\Claude_Workspace\local data analysis module\notebooks"
jupyter notebook
```

(VS Code: just pick the *Python (quickishanalysis)* kernel.)

**After editing `quickishanalysis.py`:** restart the notebook kernel to load the new code, then rerun step 7 to check
nothing is broken.

---

## Troubleshooting

| Symptom | Fix |
|---|---|
| `'conda' is not recognized` | You're in a normal Command Prompt. Use **Anaconda Prompt**. |
| `CERTIFICATE_VERIFY_FAILED` during `conda create` | Step 2b; if it persists, the temporary `ssl_verify false` fallback. |
| `CondaHTTPError: HTTP 000 CONNECTION FAILED` but the URL opens in the browser | The company certificate is being rejected (old conda reports it this way). Use the step 2b fallback with conda-forge: `ssl_verify false` → `conda create ...` → `ssl_verify true`. |
| `HTTP 000` even with `ssl_verify false` | The browser probably uses a proxy only it knows about: `reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\Internet Settings" \| findstr /i "ProxyServer AutoConfigURL"`. If a proxy shows up, use step 2c with it; otherwise ask IT. |
| `CustomValidationError: Parameter ssl_verify = 'truststore' ... is invalid` (every conda command fails) | This conda is older than 23.9. Run `conda config --remove-key ssl_verify`; if that fails too, `notepad %USERPROFILE%\.condarc`, delete the line `ssl_verify: truststore`, save. Then continue with the older-conda path in step 2b. |
| `CERTIFICATE_VERIFY_FAILED` / `SSLError` during `pip install` | `pip config list` must show the trusted-host line (step 2a). Behind a proxy also do step 2c. |
| `ProxyError` / timeouts | Step 2c with the proxy address from IT. |
| `ModuleNotFoundError: quickishanalysis` | The `sys.path.insert` line is missing or points to the wrong folder. It must be the folder that **contains** `quickishanalysis.py`. |
| `ModuleNotFoundError: duckdb` (or pandas, …) | Wrong kernel: select *Python (quickishanalysis)*. Or step 5 ran outside the `quickish` environment. |
| `FileNotFoundError: Config file not found` | `quickishanalysis.yaml` was moved or renamed. It must sit beside the `.py` with the same name. |
| `FileNotFoundError: Prompt template not found` | `quickishanalysis_prompt.md` is missing from the module folder (or `describe.template_path` points elsewhere). |
| Kernel missing in VS Code | Re-run step 6, then restart VS Code. |
| `explore()` shows an empty frame | pivottablejs loads its JavaScript from the internet; a blocked CDN shows a blank frame. The HTML file is still saved in `outputs\qa_pivots`. |
| `PermissionError` when saving | The file is open in Excel. Close it and rerun. |
| Second notebook says *file not found* on a dataset | One notebook at a time (see above). Reload the dataset in the notebook you're using. |

---

## Update or remove

```bat
conda activate quickish
cd /d "D:\Claude_Workspace\local data analysis module\quickishanalysis"
python -m pip install -U -r requirements.txt
```

Remove everything:

```bat
conda deactivate
conda env remove -n quickish -y
jupyter kernelspec uninstall quickishanalysis -y
pip config unset global.trusted-host
```

---

## Known issues

* **fastparquet in pandas 3:** `export()` writes Parquet with `engine="fastparquet"` as specified. pandas 3 marks
  that engine as deprecated. It works today; when pandas removes it, `export()` will need `engine="pyarrow"`
  (same GZIP output).
* Environment creation confirmed on conda 4.12 + conda-forge behind a TLS-inspecting work network (step 2b fallback).
* Tested with Python 3.13 (Linux) and 3.14 (your PC, earlier setup), DuckDB 2.0, pandas 3.1, pyarrow 26,
  polars 2.1. Python 3.12 in the conda environment uses the same package versions.
