"""Deposit data prep.

One module for the monthly CASATIA / Non-CASATIA deposit preparation. It
replaces three earlier files: depo prep.py (loading and reporting attributes),
retail_deposit_demarcation.py (rules engine) and deposit_integrated.py.

What load() does
  1. Reads each extract in chunks, every column as text, so codes such as
     occupation 0044 keep their leading zeros.
  2. Maps source columns to the rule columns (io.column_maps in the YAML).
  3. Cleans codes, names and balances.
  4. Builds the reporting attributes (name, product, dates, contacts, flags).
  5. Gives every account exactly one Customer Type and one Segment, following
     the retail deposit demarcation rules (business rules v0.4, updated with
     the feedback of 27/08/2026).
  6. Returns one row per account per month: keys, transformed columns, and
     any original columns you ask for.

Settings live in depositdataprep.yaml beside this file: column names, rule
order, thresholds and the path to the lookup CSV. Every code list, keyword
list and value mapping lives in ONE long CSV (depositdataprep_lookup.csv,
columns lookup, key, value, mode, deposit_type, casatia_column,
noncasatia_column, note) that the YAML points to. casatia_column and
noncasatia_column set which source column each lookup reads, per file type. Product, branch/state/region and occupation come from codes through that
CSV; codes missing from it raise a warning that lists them. GENDER comes from
the gender code (CFSEX) and, with OCCUPATION, is "Non-Individual" for every
customer type other than Individual. Both are read once,
when DepositModule() is created; create it again to pick up an edit.
dm.lookups shows the lookup table as loaded.

Use (notebook)
--------------
    from depositdataprep import DepositModule

    dm = DepositModule()
    df = dm.load(casa_path, nonc_path, month, year, columns)

    df = dm.load("casatia.csv", "noncasatia.csv", 8, 2026)          # default output
    df = dm.load("casatia.csv", None, 8, 2026)                      # CASATIA only
    df = dm.load("casatia.csv", "noncasatia.csv", 8, 2026,
                 ["CFNA1", "ACNAME", "Branch Name", "HOLD"])        # + original columns
    dm.columns                      # the columns always returned

Output: CIFNO, ACCTNO, then the transformed columns (DEPOSIT_TYPE,
CUSTOMER_TYPE, SEGMENT, BALANCE, ... SOURCE_FILE), all upper case. columns=
adds ORIGINAL file columns, untouched and under their original names; a
column only one deposit type has is blank for the other. An original name
that clashes with a transformed one gets the suffix _RAW.

casa_path / nonc_path each take a file, a folder, or a list of files and
folders. A folder reads every file in it (not subfolders) whose name matches
pattern (glob, default "*.csv"):

    df = dm.load("data/CASATIA", "data/NonCASATIA", 6, 2026)        # folders
    df = dm.load(["c_202606.csv", "c_202607.csv"], None, 6, 2026)   # list
    df = dm.load("data/CASATIA", None, 6, 2026, pattern="*2026*.csv")

Several files: month and year are the STARTING month. Within each deposit
type, files are sorted (natural order of the full path) and given consecutive
months: first file = start month, second = next month, and so on, assuming no
gaps. Name files so they sort in date order (e.g. YYYYMM). The file-to-month
list prints before loading and is kept in dm.files; SOURCE_FILE shows each
row's file. Each file should be unique by ACCTNO; duplicates raise a warning.

sql= runs one DuckDB SELECT on the finished output before it is returned.
Refer to the output as df; quote names with spaces ("Branch Name"):

    df = dm.load(casa, nonc, 8, 2026, sql='''
        SELECT MONTH, SEGMENT, COUNT(*) AS NOA, SUM(BALANCE) AS BALANCE
        FROM df GROUP BY MONTH, SEGMENT ORDER BY MONTH, SEGMENT''')

Options (keywords): pattern= file-name filter; sql= DuckDB query on the
output; output_path= writes a CSV too (after sql); cust_filt=True keeps
accounts the rules class as Individual, with no insider code and PDPA = Y;
show_progress=False hides the progress bar; chunk_mb= sets the read chunk
size (default 64).

Known limits
  - Keyword 'prefix' mode matches at the start of any word, not only at the
    start of the customer name ("KOLEJ SEKOLAH ABC" is School).
  - Class-code rules run before keyword rules, so a class H account with a
    mosque or association name stays School.

Requires polars and pyyaml. tqdm is optional: without it, progress prints as
plain percentages.
"""

from __future__ import annotations

import io
import logging
import re
import warnings
from datetime import datetime as dt
from pathlib import Path
from typing import Any, Callable, Dict, List, Mapping, Optional, Sequence, Tuple, Union

import polars as pl
import yaml

try:  # optional
    from tqdm.auto import tqdm
except ImportError:  # pragma: no cover
    tqdm = None

__all__ = ["DepositModule", "DemarcationError", "read_csv_chunked"]

PathInput = Union[str, Path, Sequence[Union[str, Path]]]

LOG = logging.getLogger("depositdataprep")

CASA = "CASATIA"
NONC = "Non-CASATIA"

# Transformed columns, after CIFNO, ACCTNO, DEPOSIT_TYPE, CUSTOMER_TYPE, SEGMENT.
TRANSFORMED_COLS = [
    "BALANCE", "PRODUCT", "BRANCH", "STATE", "REGION", "OCCUPATION_CODE", "OCCUPATION",
    "PROFESSIONAL", "RACE_CODE", "BUMI_NONBUMI",
    "SALARY", "GENDER", "RELIGION_GRP", "NOA", "DATE_OPEN", "MTHOP", "ONBOARD_DATE",
    "ONBOARD_YR", "MONTH", "NEW_CUST", "NEW_ACCT", "EMAIL", "PHONE_NUMBER",
    # CASATIA only (blank for Non-CASATIA)
    "LAST_ACTIVE_DATE", "MTD_AGG_BAL", "MTD_AGG_DAYS",
    # Non-CASATIA only (blank for CASATIA)
    "PLACEMENT_AMT", "PROFIT_RATE", "MATURITY_DATE", "TERM", "TERM_UNIT",
    # audit
    "SOURCE_FILE",
]

# Internal prefix for untouched copies of original columns asked for in load().
RAW_PREFIX = "__raw__"


class DemarcationError(Exception):
    """Any deliberate failure: bad config, bad schema, missing file or column."""


# =============================================================================
# Progress
# =============================================================================

class _PlainProgress:
    """Fallback when tqdm is not installed: prints every 10%."""

    def __init__(self, total: float, desc: str, disable: bool) -> None:
        self.total, self.desc, self.disable = max(total, 1), desc, disable
        self.done, self.next_mark, self.stage = 0.0, 10, ""

    def update(self, n: float) -> None:
        self.done += n
        pct = int(self.done * 100 / self.total + 1e-9)
        while not self.disable and pct >= self.next_mark and self.next_mark <= 100:
            suffix = " ({0})".format(self.stage) if self.stage else ""
            print("{0}: {1}%{2}".format(self.desc, self.next_mark, suffix), flush=True)
            self.next_mark += 10

    def set_postfix_str(self, text: str) -> None:
        self.stage = text

    def close(self) -> None:
        pass


class _RunProgress:
    """One 0-100% bar for a whole load(): files by bytes read, then stages."""

    def __init__(self, show: bool, desc: str = "Deposit data prep") -> None:
        if tqdm is not None:
            self.bar = tqdm(total=100, desc=desc, disable=not show,
                            bar_format="{desc}: {percentage:3.0f}%|{bar}| "
                                       "[{elapsed}<{remaining}]{postfix}")
        else:
            self.bar = _PlainProgress(100, desc, disable=not show)
        self.done = 0.0

    def stage(self, name: str) -> None:
        self.bar.set_postfix_str(name)

    def advance(self, amount: float) -> None:
        amount = min(amount, 100.0 - self.done)
        if amount > 0:
            self.done += amount
            self.bar.update(amount)

    def finish(self, name: str) -> None:
        self.stage(name)
        self.advance(100.0 - self.done)
        self.bar.close()

    def close(self) -> None:
        self.bar.close()


# =============================================================================
# Chunked CSV reader
# =============================================================================

def read_csv_chunked(
    path: Path,
    columns: List[str],
    chunk_mb: int = 64,
    separator: str = ",",
    on_bytes: Optional[Callable[[int], None]] = None,
) -> pl.DataFrame:
    """Read a CSV in byte chunks, every column as text.

    Chunks are cut at line ends. If a chunk would end inside a quoted field (an
    odd number of quote characters), it waits for the next chunk, so names that
    contain line breaks are never split. Works on every polars version.
    on_bytes, if given, is called with the number of bytes read at each step.
    """
    chunk_bytes = max(int(chunk_mb), 1) * 1024 * 1024
    report = on_bytes or (lambda n: None)
    frames = []  # type: List[pl.DataFrame]
    header = b""

    def parse(body: bytes) -> None:
        frames.append(pl.read_csv(io.BytesIO(header + body), columns=columns,
                                  separator=separator, infer_schema_length=0))

    with open(path, "rb") as handle:
        header = handle.readline()
        report(len(header))
        carry = b""
        while True:
            block = handle.read(chunk_bytes)
            if not block:
                break
            report(len(block))
            data = carry + block
            cut = data.rfind(b"\n")
            if cut == -1 or data[:cut + 1].count(b'"') % 2:
                carry = data  # no complete record yet, or inside a quoted field
                continue
            parse(data[:cut + 1])
            carry = data[cut + 1:]
        if carry.strip():
            parse(carry)

    if not frames:  # header only
        return pl.read_csv(io.BytesIO(header), columns=columns,
                           separator=separator, infer_schema_length=0)
    return pl.concat(frames, how="vertical")


# =============================================================================
# Rules engine (retail deposit demarcation)
# =============================================================================

class _Rules:
    """Compiles the demarcation rules from the config + lookup CSV and
    classifies a frame.

    One row in, one row out: every account gets exactly one rule id, and the
    rule id decides both Customer Type and Segment.
    """

    REQUIRED_COLUMNS = (
        "lob_number", "sector_code", "class_code", "race_code", "occupation_code",
        "balance", "customer_name", "cifno", "acctno",
    )
    OPTIONAL_COLUMNS = ("salary_flag",)
    CODE_COLUMNS = (
        "lob_number", "sector_code", "class_code", "race_code",
        "occupation_code", "salary_flag",
    )
    INDIVIDUAL_RULE_IDS = (
        "IND_NONBUMI", "IND_PROFESSIONAL", "IND_SALARY", "IND_HNWI", "IND_MASS",
    )
    # Lookup names in the CSV, and which data column's cleaning applies to the key.
    LOOKUP_KEY_COLUMN = {
        "retail_lob": "lob_number",
        "individual_sector": "sector_code",
        "bumi_race": "race_code",
        "professional_occupation": "occupation_code",
        "salary_flag": "salary_flag",
        "sme_sector": "sector_code",
        "sme_sector_class": "class_code",
        "nonsme_class": "class_code",
        "nonsme_keyword": None,   # upper-cased only
        # value lookups: key * is the default; deposit_type may limit a row
        "product": "product_code",
        "branch": "branch_code",
        "state": "branch_code",
        "region": "branch_code",
        "occupation": "occupation_code",
        "religion": None,
    }
    VALUE_LOOKUPS = ("product", "branch", "state", "region", "occupation", "religion")
    # Internal column each lookup's key is read into. The SOURCE column per
    # deposit type comes from the lookup CSV (casatia_column, noncasatia_column).
    # Lookups that share an internal column must name the same source column.
    LOOKUP_SOURCE = {
        "retail_lob": "lob_number",
        "individual_sector": "sector_code",
        "sme_sector": "sector_code",
        "bumi_race": "race_code",
        "professional_occupation": "occupation_code",
        "occupation": "occupation_code",
        "salary_flag": "salary_flag",
        "sme_sector_class": "class_code",
        "nonsme_class": "class_code",
        "nonsme_keyword": "customer_name",
        "product": "product_code",
        "branch": "branch_code",
        "state": "branch_code",
        "region": "branch_code",
        "religion": "religion_code",
    }
    # Internal columns cleaned like codes (trim, upper case, padding rules).
    LOOKUP_CODE_COLUMNS = ("product_code", "branch_code", "religion_code")

    def __init__(self, cfg: Dict[str, Any], table: pl.DataFrame, source: str) -> None:
        self.cfg = cfg
        self.lookups = self._read_lookups(table, source)  # name -> [(key, value, mode)]
        self._registry = {}  # type: Dict[str, Tuple[str, str]]
        self._sme_groups = {}  # type: Dict[str, List[str]]
        self._sme_gate_plain = []  # type: List[str]
        self._sme_gate_conditional = []  # type: List[Tuple[str, List[str]]]
        self._nonsme_tests = []  # type: List[Tuple[str, str, Any]]

        keys = lambda name: [k for k, _, _, _ in self.lookups[name]]
        self.retail_lobs = keys("retail_lob")
        self.individual_sectors = keys("individual_sector")
        self.bumi_codes = keys("bumi_race")
        self.professional_codes = keys("professional_occupation")
        self.salary_true = keys("salary_flag")

        labels = cfg["labels"]

        # SME: one table drives both the gate and the segment lookup.
        sme_type = str(labels["sme"]["customer_type"])
        required = {}  # type: Dict[str, List[str]]
        for cls, sector, _, _ in self.lookups["sme_sector_class"]:
            required.setdefault(sector, []).append(cls)
        sme_codes = keys("sme_sector")
        orphan = [s for s in required if s not in sme_codes]
        if orphan:
            raise DemarcationError(
                "{0}: sme_sector_class names sector(s) {1} that are not in sme_sector"
                .format(source, orphan))
        for code, segment, _, _ in self.lookups["sme_sector"]:
            rule_id = "SME_" + re.sub(r"[^A-Z0-9]+", "_", segment.upper()).strip("_")
            self._sme_groups.setdefault(rule_id, []).append(code)
            self._registry[rule_id] = (sme_type, segment)
            if code in required:
                self._sme_gate_conditional.append((code, required[code]))
            else:
                self._sme_gate_plain.append(code)

        # Non-SME: tests in the order the YAML lists them.
        nonsme_type = str(labels["non_sme"]["customer_type"])
        default_mode = str((cfg.get("keyword_matching") or {}).get("default_mode", "substring")).lower()
        used = {"class": set(), "keyword": set()}  # type: Dict[str, set]
        for entry in cfg["non_sme"]["order"]:
            rule_id, test, segment = str(entry["rule_id"]), str(entry["test"]).lower(), str(entry["segment"])
            if test == "class":
                codes = [k for k, v, _, _ in self.lookups["nonsme_class"] if v == segment]
                if not codes:
                    raise DemarcationError("{0}: no nonsme_class rows for segment '{1}' "
                                           "(non_sme.order, {2})".format(source, segment, rule_id))
                self._nonsme_tests.append(("class", rule_id, codes))
            elif test == "keyword":
                pairs = [(k, m) for k, v, m, _ in self.lookups["nonsme_keyword"] if v == segment]
                if not pairs:
                    raise DemarcationError("{0}: no nonsme_keyword rows for segment '{1}' "
                                           "(non_sme.order, {2})".format(source, segment, rule_id))
                self._nonsme_tests.append(("keyword", rule_id, self._keyword_pattern(pairs, default_mode)))
            else:
                raise DemarcationError("non_sme.order {0}: test must be 'class' or 'keyword', got '{1}'"
                                       .format(rule_id, test))
            used[test].add(segment)
            self._registry[rule_id] = (nonsme_type, segment)
        for test, name in (("class", "nonsme_class"), ("keyword", "nonsme_keyword")):
            unused = sorted({v for _, v, _, _ in self.lookups[name]} - used[test])
            if unused:
                raise DemarcationError(
                    "{0}: {1} has segment(s) {2} that no '{3}' test in non_sme.order uses; "
                    "those rows would be ignored".format(source, name, unused, test))
        fallback = cfg["non_sme"]["fallback"]
        self._registry[str(fallback["rule_id"])] = (nonsme_type, str(fallback["segment"]))

        # Individual and Non-Retail labels.
        for entry in labels["individual"]["rules"]:
            self._registry[str(entry["rule_id"])] = (
                str(labels["individual"]["customer_type"]), str(entry["segment"]))
        non_retail = labels["non_retail"]
        self._registry[str(non_retail["rule_id"])] = (
            str(non_retail["customer_type"]), str(non_retail["segment"]))

        missing = [r for r in self.INDIVIDUAL_RULE_IDS if r not in self._registry]
        if missing:
            raise DemarcationError(
                "labels.individual.rules is missing {0}. "
                "Those segments would come out blank.".format(missing))

    # -- lookup CSV ---------------------------------------------------------

    def _read_lookups(self, table: pl.DataFrame, source: str) -> Dict[str, List[Tuple[str, str, str, str]]]:
        """Validate the long lookup table and clean its keys like the data.

        Columns: lookup, key, value, casatia_column, noncasatia_column
        (required); mode, deposit_type, note (optional). Rows come back as
        (key, value, mode, deposit_type). Also sets self.lookup_sources: the
        source column per deposit type for each internal column.
        """
        table = table.rename({c: c.lstrip("\ufeff").strip().lower() for c in table.columns})
        required = ("lookup", "key", "value", "casatia_column", "noncasatia_column")
        absent = [c for c in required if c not in table.columns]
        if absent:
            raise DemarcationError("{0}: lookup file needs columns {1} (mode, deposit_type, note "
                                   "optional); missing {2}".format(source, ", ".join(required), absent))
        for optional in ("mode", "deposit_type"):
            if optional not in table.columns:
                table = table.with_columns(pl.lit("").alias(optional))
        deposit_types = {CASA.upper(): CASA, NONC.upper(): NONC}

        lookups = {name: [] for name in self.LOOKUP_KEY_COLUMN}  # type: Dict[str, List[Tuple[str, str, str, str]]]
        seen = set()
        columns_by_lookup = {}  # type: Dict[str, Dict[Tuple[str, str], List[int]]]
        rows = table.select(["lookup", "key", "value", "mode", "deposit_type",
                             "casatia_column", "noncasatia_column"]).iter_rows()
        for row_no, row in enumerate(rows, start=2):
            name, key, value, mode, scope, casa_col, nonc_col = [
                ("" if v is None else str(v).strip()) for v in row]
            if not name and not key and not value:
                continue  # blank line
            name = name.lower()
            if name not in self.LOOKUP_KEY_COLUMN:
                raise DemarcationError("{0} row {1}: unknown lookup '{2}'. Known: {3}".format(
                    source, row_no, name, sorted(self.LOOKUP_KEY_COLUMN)))
            if not key:
                raise DemarcationError("{0} row {1}: blank key in lookup '{2}'".format(source, row_no, name))
            column = self.LOOKUP_KEY_COLUMN[name]
            if key != "*":
                key = self.clean_text(column, key) if column else key.upper()
            if name == "sme_sector_class":
                value = self.clean_text("sector_code", value)
            mode = mode.lower()
            if mode and name != "nonsme_keyword":
                raise DemarcationError("{0} row {1}: 'mode' is only used by nonsme_keyword".format(
                    source, row_no))
            if scope:
                if name not in self.VALUE_LOOKUPS:
                    raise DemarcationError("{0} row {1}: 'deposit_type' is only used by {2}".format(
                        source, row_no, ", ".join(self.VALUE_LOOKUPS)))
                if scope.upper() not in deposit_types:
                    raise DemarcationError("{0} row {1}: deposit_type must be blank, {2} or {3}; got '{4}'"
                                           .format(source, row_no, CASA, NONC, scope))
                scope = deposit_types[scope.upper()]
            if name == "sme_sector_class":
                ident = (name, key, value)
            elif name in self.VALUE_LOOKUPS:
                ident = (name, key, scope)
            else:
                ident = (name, key)
            if ident in seen:
                raise DemarcationError("{0} row {1}: duplicate key '{2}' in lookup '{3}'{4}".format(
                    source, row_no, key, name, " for " + scope if scope else ""))
            seen.add(ident)
            lookups[name].append((key, value, mode, scope))
            columns_by_lookup.setdefault(name, {}).setdefault((casa_col, nonc_col), []).append(row_no)

        # Source columns: one pair per lookup, and lookups that share an
        # internal column must agree.
        self.lookup_sources = {CASA: {}, NONC: {}}  # type: Dict[str, Dict[str, str]]
        owner = {}  # type: Dict[Tuple[str, str], str]
        for name, pairs in columns_by_lookup.items():
            if len(pairs) > 1:
                listed = "; ".join("CASATIA '{0}' / Non-CASATIA '{1}' (rows {2})".format(
                    c, n, ", ".join(str(r) for r in rws[:5]) + (" ..." if len(rws) > 5 else ""))
                    for (c, n), rws in pairs.items())
                raise DemarcationError("{0}: lookup '{1}' names different source columns on different "
                                       "rows; use one pair for the whole lookup: {2}".format(source, name, listed))
            casa_col, nonc_col = next(iter(pairs))
            internal = self.LOOKUP_SOURCE[name]
            for deposit_type, column in ((CASA, casa_col), (NONC, nonc_col)):
                previous = self.lookup_sources[deposit_type].get(internal)
                if previous is not None and previous != column:
                    raise DemarcationError(
                        "{0}: lookups '{1}' and '{2}' both read {3} but name different {4} columns "
                        "('{5}' vs '{6}'); make them the same".format(
                            source, owner[(deposit_type, internal)], name, internal, deposit_type,
                            previous, column))
                self.lookup_sources[deposit_type][internal] = column
                owner[(deposit_type, internal)] = name
        self.lookup_owner = {internal: name for (_, internal), name in owner.items()}

        missing = [n for n, rows in lookups.items() if not rows and n not in self.VALUE_LOOKUPS]
        if missing:
            raise DemarcationError("{0}: lookup(s) with no rows: {1}".format(source, missing))
        branch_keys = {n: {(k, s) for k, _, _, s in lookups[n] if k != "*"} for n in ("branch", "state", "region")}
        if len({frozenset(v) for v in branch_keys.values()}) > 1:
            gaps = {n: sorted(k for k, _ in set().union(*branch_keys.values()) - v)
                    for n, v in branch_keys.items()}
            raise DemarcationError("{0}: branch, state and region must list the same branch codes; "
                                   "missing {1}".format(source, {n: g for n, g in gaps.items() if g}))
        return lookups

    def value_rows(self, name: str) -> List[Tuple[str, str, str]]:
        """(key, value, deposit_type) rows of a value lookup; key * is the default."""
        return [(k, v, s) for k, v, _, s in self.lookups[name]]

    # -- normalisation ------------------------------------------------------

    def clean_text(self, column: str, value: Any) -> str:
        """Python twin of clean_code, for lookup keys."""
        norm = self.cfg.get("normalisation") or {}
        text = str(value).strip().upper()
        if column in (norm.get("remove_all_whitespace") or []):
            text = re.sub(r"\s+", "", text)
        if re.fullmatch(r"\d+", text):
            width = (norm.get("zero_pad_width") or {}).get(column)
            if width:
                text = text.zfill(int(width))
            if column in (norm.get("strip_leading_zeros") or []):
                text = re.sub(r"^0+(\d)", r"\1", text)
        return text

    def clean_code(self, column: str) -> pl.Expr:
        """Blank-fill, trim, upper-case, then apply this column's padding rule."""
        norm = self.cfg.get("normalisation") or {}
        expr = (pl.col(column).cast(pl.Utf8, strict=False)
                .fill_null(str(norm.get("null_placeholder", "")))
                .str.strip_chars().str.to_uppercase())
        if column in (norm.get("remove_all_whitespace") or []):  # "00 44" -> "0044"
            expr = expr.str.replace_all(r"\s+", "")
        numeric = expr.str.contains(r"^\d+$")
        width = (norm.get("zero_pad_width") or {}).get(column)
        if width:  # occupation 44 -> 0044; P001 stays P001
            expr = pl.when(numeric).then(expr.str.zfill(int(width))).otherwise(expr)
        if column in (norm.get("strip_leading_zeros") or []):  # "08" -> "8", "000" -> "0"
            expr = pl.when(numeric).then(expr.str.replace(r"^0+(\d)", "${1}")).otherwise(expr)
        return expr.alias(column)

    def clean_balance(self) -> pl.Expr:
        expr = pl.col("balance").cast(pl.Utf8, strict=False).fill_null("")
        for character in (self.cfg.get("normalisation") or {}).get("balance_strip_characters") or []:
            expr = expr.str.replace_all(re.escape(str(character)), "")
        return expr.str.strip_chars().cast(pl.Float64, strict=False).alias("balance")

    # -- classification -----------------------------------------------------

    def classify(self, frame: pl.DataFrame) -> pl.DataFrame:
        """Add rule_id, customer_type and segment."""
        out = frame.with_columns(self._rule_id_expression())

        unmapped = out.filter(pl.col("rule_id").is_null())
        if unmapped.height:
            codes = sorted(set(unmapped["sector_code"].to_list()))
            raise DemarcationError(
                "{0} account(s) passed the SME gate but have no segment. Sector code(s) "
                "not in sme_sector: {1}. Investigate rather than default to Others."
                .format(unmapped.height, codes))

        by_type = {}  # type: Dict[str, List[str]]
        by_segment = {}  # type: Dict[str, List[str]]
        for rule_id, (customer_type, segment) in self._registry.items():
            by_type.setdefault(customer_type, []).append(rule_id)
            by_segment.setdefault(segment, []).append(rule_id)

        rule = pl.col("rule_id")
        return out.with_columns([
            self._chain([(rule.is_in(ids), v) for v, ids in by_type.items()], None)
            .alias("customer_type"),
            self._chain([(rule.is_in(ids), v) for v, ids in by_segment.items()], None)
            .alias("segment"),
        ])

    def _rule_id_expression(self) -> pl.Expr:
        cfg = self.cfg
        individual = cfg["individual"]
        sector = pl.col("sector_code")
        class_code = pl.col("class_code")

        is_retail = pl.col("lob_number").is_in(self.retail_lobs)
        is_individual = sector.is_in(self.individual_sectors)

        passes_sme_gate = sector.is_in(self._sme_gate_plain)
        for code, allowed in self._sme_gate_conditional:
            passes_sme_gate = passes_sme_gate | ((sector == code) & class_code.is_in(allowed))

        salary_applies = pl.col("deposit_type").is_in(
            [str(v) for v in individual.get("salary_rule_deposit_types") or []])
        individual_rule = self._chain(
            [
                (~pl.col("race_code").is_in(self.bumi_codes), "IND_NONBUMI"),
                (pl.col("occupation_code").is_in(self.professional_codes), "IND_PROFESSIONAL"),
                (salary_applies & pl.col("salary_flag").is_in(self.salary_true), "IND_SALARY"),
                (pl.col("balance").fill_null(0.0) >= float(individual["hnwi_min_balance"]),
                 "IND_HNWI"),
            ],
            otherwise="IND_MASS",
        )

        # No otherwise: a null means the gate and the table disagree -> error.
        sme_rule = self._chain(
            [(sector.is_in(codes), rule_id) for rule_id, codes in self._sme_groups.items()],
            otherwise=None)

        nonsme_branches = []
        for test, rule_id, target in self._nonsme_tests:
            if test == "class":
                nonsme_branches.append((class_code.is_in(target), rule_id))
            else:
                nonsme_branches.append((pl.col("customer_name").str.contains(target), rule_id))
        nonsme_rule = self._chain(nonsme_branches,
                                  otherwise=str(cfg["non_sme"]["fallback"]["rule_id"]))

        return (
            pl.when(~is_retail)
            .then(pl.lit(str(cfg["labels"]["non_retail"]["rule_id"]), dtype=pl.Utf8))
            .when(is_individual).then(individual_rule)
            .when(passes_sme_gate).then(sme_rule)
            .otherwise(nonsme_rule)
            .alias("rule_id")
        )

    # -- helpers ------------------------------------------------------------

    @staticmethod
    def upper(values: Sequence[Any]) -> List[str]:
        return [str(v).strip().upper() for v in values]

    @staticmethod
    def _chain(branches: Sequence[Tuple[pl.Expr, Optional[str]]],
               otherwise: Optional[str]) -> pl.Expr:
        """when/then/otherwise chain returning text; works on every polars version."""
        expr = None
        for condition, value in branches:
            result = pl.lit(value, dtype=pl.Utf8)
            expr = pl.when(condition).then(result) if expr is None else expr.when(condition).then(result)
        tail = pl.lit(otherwise, dtype=pl.Utf8)
        return tail if expr is None else expr.otherwise(tail)

    @staticmethod
    def _keyword_pattern(pairs: Sequence[Tuple[str, str]], default: str) -> str:
        """One regex per keyword test: substring, word, or prefix (start of a word)."""
        buckets = {"substring": [], "word": [], "prefix": []}  # type: Dict[str, List[str]]
        for keyword, mode in pairs:
            mode = (mode or default).lower()
            if mode not in buckets:
                raise DemarcationError(
                    "keyword '{0}' has match mode '{1}'. Use substring, word or prefix."
                    .format(keyword, mode))
            buckets[mode].append(re.escape(keyword))
        parts = []
        if buckets["substring"]:
            parts.append("(?:" + "|".join(buckets["substring"]) + ")")
        if buckets["word"]:
            parts.append(r"(?:\b(?:" + "|".join(buckets["word"]) + r")\b)")
        if buckets["prefix"]:
            parts.append(r"(?:\b(?:" + "|".join(buckets["prefix"]) + r"))")
        return "|".join(parts)


# =============================================================================
# Public module
# =============================================================================

class DepositModule:
    """Monthly deposit data prep: load, standardise, classify.

        dm = DepositModule()                      # depositdataprep.yaml beside this file
        dm = DepositModule("other.yaml")          # explicit config
        df = dm.load(casa_path, nonc_path, month, year, columns)
    """

    CONFIG_PATH = Path(__file__).resolve().parent / "depositdataprep.yaml"

    def __init__(self, config_path: Optional[Union[str, Path]] = None) -> None:
        path = Path(config_path) if config_path else self.CONFIG_PATH
        if not path.exists():
            raise DemarcationError(
                "config not found: {0}. Pass config_path= to name one.".format(path))
        cfg = yaml.safe_load(path.read_text(encoding="utf-8"))
        if not isinstance(cfg, dict):
            raise DemarcationError("config is empty or malformed: {0}".format(path))
        for section in ("io", "prep", "individual", "labels"):
            if section not in cfg:
                raise DemarcationError("config has no '{0}' section: {1}".format(section, path))

        if not cfg.get("lookup_file"):
            raise DemarcationError("config has no 'lookup_file': {0}".format(path))
        lookup_path = Path(str(cfg["lookup_file"]))
        if not lookup_path.is_absolute():
            lookup_path = path.parent / lookup_path
        if not lookup_path.exists():
            raise DemarcationError("lookup file not found: {0}".format(lookup_path))
        table = pl.read_csv(lookup_path, infer_schema_length=0, encoding="utf8-lossy")

        self.cfg = cfg
        self.config_path = path
        self.lookup_path = lookup_path
        self.lookups = table  # the lookup CSV as loaded, for inspection
        self.rules = _Rules(cfg, table, lookup_path.name)
        self._prep = cfg["prep"]
        io_cfg = cfg["io"]
        self._column_maps = io_cfg.get("column_maps") or {}
        self._output_cfg = io_cfg.get("output") or {}
        self._separator = str((io_cfg.get("csv_read") or {}).get("separator", ","))
        self.files = []  # type: List[Dict[str, str]]  # file-to-month list of the last load()

    @property
    def rules_version(self) -> str:
        return str(self.cfg.get("meta", {}).get("rules_version", "unknown"))

    @property
    def columns(self) -> List[str]:
        """Columns load() always returns: CIFNO, ACCTNO, then the transformed ones."""
        return list(self._output_cfg["columns"].keys()) + TRANSFORMED_COLS

    # ------------------------------------------------------------------
    # Entry point
    # ------------------------------------------------------------------

    def load(
        self,
        casa_path: Optional[PathInput] = None,
        nonc_path: Optional[PathInput] = None,
        month: Optional[int] = None,
        year: Optional[int] = None,
        columns: Optional[Union[str, Sequence[str]]] = None,
        pattern: str = "*.csv",
        sql: Optional[str] = None,
        output_path: Optional[Union[str, Path]] = None,
        cust_filt: bool = False,
        show_progress: bool = True,
        chunk_mb: int = 64,
    ) -> pl.DataFrame:
        """Load, standardise and classify the deposit extracts.

        Parameters
        ----------
        casa_path : CASATIA input: a CSV file, a folder, or a list of files
            and folders. Give this, nonc_path, or both.
        nonc_path : Non-CASATIA input, same forms. None for CASATIA only.
        month, year : reporting month (e.g. 8, 2026). With several files per
            deposit type this is the STARTING month: files are sorted and
            given consecutive months, assuming no gaps.
        columns : ORIGINAL file columns to add, untransformed, under their
            original names (e.g. ["CFEMPL", "Branch Name", "HOLD"]). A column
            only one deposit type has is blank for the other. Without it, the
            output is CIFNO, ACCTNO and the transformed columns (dm.columns).
        pattern : glob on file names inside folders (default "*.csv").
            Files given directly are always read.
        sql : optional DuckDB SELECT run on the finished output before it is
            returned; the output is the table df. One statement; a trailing
            ';' is fine. Needs duckdb (pyarrow optional, makes it faster).
        output_path : also write the result to this CSV (after sql).
        cust_filt : keep only accounts the rules class as Individual, with no
            insider code (CFINSC) and PDPA (CFSIC2) = Y.
        show_progress : print the file-to-month list and one 0-100% bar.
        chunk_mb : read chunk size in MB.

        Returns
        -------
        polars.DataFrame: one row per account per month, or the result of sql.
        """
        query = self._check_sql(sql)  # fail before the long load
        if month is None or year is None:
            raise DemarcationError("give the reporting month and year, e.g. load(c, n, 8, 2026)")
        if not 1 <= int(month) <= 12:
            raise DemarcationError("month must be 1-12, got {0}".format(month))
        if not casa_path and not nonc_path:
            raise DemarcationError("give casa_path, nonc_path, or both")
        extra = [columns] if isinstance(columns, str) else [str(c) for c in (columns or [])]
        extra = list(dict.fromkeys(extra))

        # Resolve inputs and give each file its reporting month.
        plan = []  # type: List[Tuple[Path, str, int, int]]
        counts = {}  # type: Dict[str, int]
        for given, deposit_type in ((casa_path, CASA), (nonc_path, NONC)):
            if not given:
                continue
            files = self._resolve_files(given, pattern, deposit_type)
            counts[deposit_type] = len(files)
            for offset, path in enumerate(files):
                y, m = divmod(int(year) * 12 + int(month) - 1 + offset, 12)
                plan.append((path, deposit_type, y, m + 1))

        # Check every header before the long read.
        headers = {}  # type: Dict[Path, List[str]]
        for path, deposit_type, _, _ in plan:
            header = pl.read_csv(path, n_rows=0, separator=self._separator,
                                 infer_schema_length=0).columns
            absent = [c for c in self._needed(deposit_type) if c not in header]
            if absent:
                raise DemarcationError(
                    "{0} ({1}): columns not in the file: {2}".format(path.name, deposit_type, absent))
            headers[path] = header
        unknown = [c for c in extra if not any(c in h for h in headers.values())]
        if unknown:
            raise DemarcationError(
                "columns not found in any input file: {0}. Use the original column "
                "names, e.g. 'CFEMPL', 'Branch Name'.".format(unknown))
        extra_out = self._extra_names(extra)

        self.files = [{"deposit_type": t, "month": dt(y, m, 1).strftime("%b%y"),
                       "file": str(p)} for p, t, y, m in plan]
        if len(set(counts.values())) > 1:
            warnings.warn(
                "file counts differ by deposit type {0}: the months may not line up. "
                "Check dm.files.".format(counts), stacklevel=2)
        if show_progress:
            for entry in self.files:
                print("{0:<12} {1}  {2}".format(entry["deposit_type"], entry["month"],
                                                entry["file"]), flush=True)

        sizes = [p.stat().st_size for p, _, _, _ in plan]
        total_bytes = max(sum(sizes), 1)
        load_share = float(self._prep.get("progress_load_share", 60))
        stage_share = (100.0 - load_share) / (4 + (1 if query else 0) + (1 if output_path else 0))

        progress = _RunProgress(show_progress)
        try:
            frames = []
            for (path, deposit_type, y, m), size in zip(plan, sizes):
                progress.stage("loading {0} {1}".format(deposit_type, dt(y, m, 1).strftime("%b%y")))
                per_byte = load_share * size / total_bytes / max(size, 1)
                wanted = [c for c in extra if c in headers[path]]
                frame = self._read_extract(
                    path, deposit_type, chunk_mb, wanted,
                    on_bytes=lambda n, k=per_byte: progress.advance(n * k))
                frames.append(frame.with_columns([
                    pl.lit(path.name).alias("SOURCE_FILE"),
                    pl.lit(y).alias("_report_year"),
                    pl.lit(m).alias("_report_month"),
                ]))
            frame = pl.concat(frames, how="diagonal")
            frame = self._fill_absent(frame, extra)

            progress.stage("cleaning codes")
            frame = self._clean(frame)
            progress.advance(stage_share)

            progress.stage("standardising")
            contact = self._contact(frame)
            frame = self._standardise(frame)
            self._warn_unmapped(frame, "PRODUCT", "product_code", "product")
            self._warn_unmapped(frame, "BRANCH", "branch_code", "branch")
            progress.advance(stage_share)

            progress.stage("classifying {0:,} accounts".format(frame.height))
            frame = self.rules.classify(frame)
            frame = self._individual_fields(frame)
            self._warn_unmapped(frame, "OCCUPATION", "occupation_code", "occupation", individual_only=True)
            if cust_filt:
                individual = str(self.cfg["labels"]["individual"]["customer_type"])
                frame = frame.filter(
                    (pl.col("customer_type") == individual)
                    & (pl.col("CFINSC").cast(pl.Utf8).str.strip_chars().fill_null("") == "")
                    & (pl.col("CFSIC2").cast(pl.Utf8).str.strip_chars().str.to_uppercase() == "Y"))
            progress.advance(stage_share)

            progress.stage("adding contacts")
            frame = frame.join(contact, on=["cifno", "_report_year", "_report_month"], how="left")
            output = self._output(frame, extra, extra_out)
            progress.advance(stage_share)

            if query:
                progress.stage("running SQL")
                output = self._run_sql(output, query)
                progress.advance(stage_share)

            if output_path:
                progress.stage("writing CSV")
                target = Path(output_path)
                if str(target.parent) not in ("", "."):
                    target.parent.mkdir(parents=True, exist_ok=True)
                output.write_csv(target)
                progress.advance(stage_share)

            progress.finish("done: {0:,} rows".format(output.height))
        except BaseException:
            progress.close()
            raise
        return output

    # ------------------------------------------------------------------
    # SQL (DuckDB)
    # ------------------------------------------------------------------

    @staticmethod
    def _check_sql(sql: Optional[str]) -> Optional[str]:
        """Clean the query and make sure DuckDB is installed, before loading."""
        if sql is None:
            return None
        query = str(sql).strip().rstrip(";").strip()
        if not query:
            raise DemarcationError("sql is empty")
        try:
            import duckdb  # noqa: F401  (optional dependency)
        except ImportError:
            raise DemarcationError("sql= needs DuckDB: pip install duckdb")
        return query

    @staticmethod
    def _run_sql(frame: pl.DataFrame, query: str) -> pl.DataFrame:
        """Run query on frame (as table df) in DuckDB; return a polars DataFrame.

        With pyarrow installed, the frame is passed in memory. Without it, the
        frame goes through a temporary Parquet file, which needs nothing extra.
        """
        import duckdb
        import tempfile

        try:
            import pyarrow  # noqa: F401
            has_arrow = True
        except ImportError:
            has_arrow = False

        try:
            if has_arrow:
                con = duckdb.connect()
                try:
                    con.register("df", frame)
                    return con.sql(query).pl()
                finally:
                    con.close()

            with tempfile.TemporaryDirectory() as tmp:
                source = Path(tmp) / "df.parquet"
                result = Path(tmp) / "result.parquet"
                frame.write_parquet(source)
                con = duckdb.connect()
                try:
                    con.execute("CREATE VIEW df AS SELECT * FROM read_parquet('{0}')".format(
                        str(source).replace("'", "''")))
                    con.execute("COPY ({0}) TO '{1}' (FORMAT PARQUET)".format(
                        query, str(result).replace("'", "''")))
                finally:
                    con.close()
                # Read into memory so the temporary folder can be removed (Windows).
                return pl.read_parquet(io.BytesIO(result.read_bytes()))
        except duckdb.Error as exc:
            raise DemarcationError("sql failed: {0}".format(exc)) from exc

    # ------------------------------------------------------------------
    # Inputs
    # ------------------------------------------------------------------

    @staticmethod
    def _natural_key(path: Path) -> List[Any]:
        """Sort key so file_2 comes before file_10."""
        return [int(part) if part.isdigit() else part.lower()
                for part in re.split(r"(\d+)", str(path))]

    def _resolve_files(self, given: PathInput, pattern: str, deposit_type: str) -> List[Path]:
        """Files from a file, a folder, or a list of both; natural-sorted, no repeats."""
        items = [given] if isinstance(given, (str, Path)) else list(given)
        files = []  # type: List[Path]
        for item in items:
            path = Path(item)
            if path.is_dir():
                found = [p for p in path.glob(pattern) if p.is_file()]
                if not found:
                    raise DemarcationError(
                        "{0}: no files matching '{1}' in folder {2}".format(
                            deposit_type, pattern, path))
                files.extend(found)
            elif path.is_file():
                files.append(path)
            else:
                raise DemarcationError("{0}: not found: {1}".format(deposit_type, path))
        unique = {str(p.resolve()): p for p in files}
        return sorted(unique.values(), key=self._natural_key)

    def _column_pairs(self, deposit_type: str) -> List[Tuple[str, str]]:
        """(source column, internal column) for this deposit type: keys and
        balance from io.column_maps in the YAML, every lookup key column from
        the lookup CSV (casatia_column / noncasatia_column)."""
        yaml_map = dict(self._column_maps.get(deposit_type) or {})
        if not yaml_map:
            raise DemarcationError("no io.column_maps entry for '{0}'".format(deposit_type))
        from_csv = self.rules.lookup_sources.get(deposit_type, {})
        clash = sorted(logical for logical in yaml_map.values() if logical in from_csv)
        if clash:
            raise DemarcationError(
                "io.column_maps.{0} sets {1}, which the lookup CSV already sets "
                "(casatia_column / noncasatia_column); remove them from the YAML".format(deposit_type, clash))
        valid = set(self.rules.REQUIRED_COLUMNS + self.rules.OPTIONAL_COLUMNS)
        bad = [t for t in yaml_map.values() if t not in valid]
        if bad:
            raise DemarcationError("io.column_maps.{0} targets unknown columns {1}".format(deposit_type, bad))
        pairs = [(str(src), str(logical)) for src, logical in yaml_map.items()]
        pairs += [(src, logical) for logical, src in from_csv.items() if src]
        lookup_cols = self.rules.lookup_sources.get(deposit_type, {})
        missing = [c for c in self.rules.REQUIRED_COLUMNS if c not in {l for _, l in pairs}]
        if missing:
            where = ["{0} (lookup '{1}', {2})".format(
                c, self.rules.lookup_owner.get(c, "?"),
                "casatia_column" if deposit_type == CASA else "noncasatia_column")
                if c in lookup_cols else "{0} (io.column_maps)".format(c) for c in missing]
            raise DemarcationError("{0}: no source column for {1}".format(deposit_type, ", ".join(where)))
        return pairs

    def _needed(self, deposit_type: str) -> List[str]:
        """Source columns this deposit type must have."""
        source_cols = [str(c) for c in (self._prep["source_columns"].get(deposit_type) or [])]
        return list(dict.fromkeys(source_cols + [src for src, _ in self._column_pairs(deposit_type)]))

    def _extra_names(self, extra: List[str]) -> Dict[str, str]:
        """Output name per original column. A name that clashes with a
        transformed column gets '_RAW' (CIFNO/ACCTNO are already present)."""
        taken = set(self.columns)
        names = {}  # type: Dict[str, str]
        for col in extra:
            if col in ("CIFNO", "ACCTNO"):
                continue
            names[col] = col + "_RAW" if col in taken else col
        return names

    def _read_extract(self, path: Path, deposit_type: str, chunk_mb: int, extra: List[str],
                      on_bytes: Optional[Callable[[int], None]] = None) -> pl.DataFrame:
        pairs = self._column_pairs(deposit_type)
        source_cols = [str(c) for c in (self._prep["source_columns"].get(deposit_type) or [])]
        rename = dict((self._prep.get("rename") or {}).get(deposit_type) or {})
        need = list(dict.fromkeys(self._needed(deposit_type) + extra))

        raw = read_csv_chunked(path, need, chunk_mb=chunk_mb, separator=self._separator,
                               on_bytes=on_bytes)

        # Expression select: one source column can feed the rules, the
        # transformed columns and an untouched original copy.
        exprs = [pl.col(c).alias(rename.get(c, c)) for c in source_cols]
        exprs += [pl.col(src).alias(dst) for src, dst in pairs]
        exprs += [pl.col(c).alias(RAW_PREFIX + c) for c in extra]
        frame = raw.select(exprs).with_columns(pl.lit(deposit_type).alias("deposit_type"))

        duplicates = frame.height - frame.select(pl.col("acctno").str.strip_chars()).n_unique()
        if duplicates:
            warnings.warn("{0}: {1:,} duplicate ACCTNO row(s); each file should be unique "
                          "by ACCTNO.".format(path.name, duplicates), stacklevel=3)
        return frame

    def _fill_absent(self, frame: pl.DataFrame, extra: List[str]) -> pl.DataFrame:
        """Blank columns for anything only the other deposit type has."""
        expected = (list(self.rules.OPTIONAL_COLUMNS) + list(self.rules.LOOKUP_CODE_COLUMNS)
                    + [RAW_PREFIX + c for c in extra])
        renames = self._prep.get("rename") or {}
        for deposit_type, cols in (self._prep["source_columns"] or {}).items():
            rename = renames.get(deposit_type) or {}
            expected += [rename.get(str(c), str(c)) for c in cols]
        absent = [c for c in dict.fromkeys(expected) if c not in frame.columns]
        if absent:
            frame = frame.with_columns([pl.lit(None, dtype=pl.Utf8).alias(c) for c in absent])
        return frame

    # ------------------------------------------------------------------
    # Steps
    # ------------------------------------------------------------------

    def _clean(self, frame: pl.DataFrame) -> pl.DataFrame:
        """Rule columns and the lookup key columns, cleaned like codes."""
        frame = frame.with_columns(
            [self.rules.clean_code(c) for c in self.rules.CODE_COLUMNS + self.rules.LOOKUP_CODE_COLUMNS]
            + [
                pl.col("customer_name").cast(pl.Utf8, strict=False).fill_null("")
                .str.strip_chars().str.to_uppercase().alias("customer_name"),
                pl.col("cifno").cast(pl.Utf8, strict=False).fill_null("")
                .str.strip_chars().alias("cifno"),
                pl.col("acctno").cast(pl.Utf8, strict=False).fill_null("")
                .str.strip_chars().alias("acctno"),
                self.rules.clean_balance(),
            ])
        unreadable = frame.filter(pl.col("balance").is_null()).height
        if unreadable:
            LOG.warning("%d account(s) have a balance that is not a number; "
                        "treated as 0 for the HNWI test.", unreadable)
        return frame

    def _contact(self, frame: pl.DataFrame) -> pl.DataFrame:
        """One email and one mobile number per CIF per reporting month.

        Email exists only in CASATIA, so a CIF's email also reaches its
        Non-CASATIA accounts in the same month.
        """
        prefix = str(self._prep.get("mobile_prefix", "01"))
        phones = ["CFHPHO", "CFBPHO", "CFBFHO"]
        keys = ["cifno", "_report_year", "_report_month"]
        valid = [
            pl.when(pl.col(c).cast(pl.Utf8).str.strip_chars().str.starts_with(prefix))
            .then(pl.col(c).cast(pl.Utf8).str.strip_chars()).otherwise(None)
            for c in phones
        ]
        phone = (frame.select(keys + phones)
                 .with_columns(pl.coalesce(valid).alias("PHONE_NUMBER"))
                 .filter(pl.col("PHONE_NUMBER").is_not_null())
                 .unique(subset=keys, keep="first")
                 .select(keys + ["PHONE_NUMBER"]))
        email = (frame.select(keys + [pl.col("CFCEML").cast(pl.Utf8).str.strip_chars().alias("EMAIL")])
                 .filter(pl.col("EMAIL").is_not_null() & (pl.col("EMAIL") != ""))
                 .unique(subset=keys, keep="first"))
        base = frame.select(keys).unique()
        return base.join(email, on=keys, how="left").join(phone, on=keys, how="left")

    def _standardise(self, frame: pl.DataFrame) -> pl.DataFrame:
        """Transformed columns. Bumi, Professional and Salary follow the rules'
        code lists, so they always agree with SEGMENT. MONTH, NEW_CUST and
        NEW_ACCT use each row's own reporting month."""
        bumi = self.rules.bumi_codes
        professional = self.rules.professional_codes
        salary_true = self.rules.salary_true
        floor_year = int(self._prep.get("onboard_year_floor", 1983))
        report = pl.datetime(pl.col("_report_year"), pl.col("_report_month"), 1)
        year_before = pl.datetime(pl.col("_report_year") - 1, pl.col("_report_month"), 1)


        df = frame.with_columns([
            pl.col("balance").alias("BALANCE"),
            self._map_values(pl.col("product_code"), "product").alias("PRODUCT"),
            self._map_values(pl.col("branch_code"), "branch").alias("BRANCH"),
            self._map_values(pl.col("branch_code"), "state").alias("STATE"),
            self._map_values(pl.col("branch_code"), "region").alias("REGION"),
            pl.col("occupation_code").alias("OCCUPATION_CODE"),
            pl.when(pl.col("occupation_code").is_in(professional))
            .then(pl.lit("Professional")).otherwise(pl.lit("OTHERS")).alias("PROFESSIONAL"),
            pl.col("race_code").alias("RACE_CODE"),
            pl.when(pl.col("race_code").is_in(bumi))
            .then(pl.lit("BUMI")).otherwise(pl.lit("NON BUMI")).alias("BUMI_NONBUMI"),
            pl.when(pl.col("salary_flag").is_in(salary_true))
            .then(pl.lit("Salary")).otherwise(pl.lit("Non-Salary")).alias("SALARY"),
            self._map_values(pl.col("religion_code"), "religion").alias("RELIGION_GRP"),
            pl.lit(1).alias("NOA"),
            self._julian("DATOP7").alias("DATE_OPEN"),
            self._julian("CFORGD").alias("ONBOARD_DATE"),
            report.dt.strftime("%b%y").alias("MONTH"),
            self._julian_strict("DLA7").alias("LAST_ACTIVE_DATE"),
            self._number("MTDAGB").alias("MTD_AGG_BAL"),
            self._number("MTDAGD").cast(pl.Int64, strict=False).alias("MTD_AGG_DAYS"),
            self._number("ORGBAL").alias("PLACEMENT_AMT"),
            self._number("RATE").alias("PROFIT_RATE"),
            self._julian_strict("MATDT").alias("MATURITY_DATE"),
            self._number("CDTERM").cast(pl.Int64, strict=False).alias("TERM"),
            pl.col("CDTCOD").cast(pl.Utf8).str.strip_chars().str.to_uppercase().alias("TERM_UNIT"),
        ])
        df = df.with_columns([
            pl.col("DATE_OPEN").dt.strftime("%b%y").alias("MTHOP"),
            pl.col("ONBOARD_DATE").dt.year().clip(floor_year, dt.now().year).alias("ONBOARD_YR"),
        ])
        return df.with_columns([
            pl.when(pl.col("ONBOARD_DATE") >= year_before)
            .then(pl.lit("New to Bank")).otherwise(pl.lit("Existing to Bank")).alias("NEW_CUST"),
            pl.when(pl.col("MTHOP") == pl.col("MONTH"))
            .then(pl.lit("New Acct")).otherwise(pl.lit("Existing Acct")).alias("NEW_ACCT"),
        ])

    def _map_values(self, key: pl.Expr, lookup: str) -> pl.Expr:
        """Map a cleaned key through a value lookup. A row with a deposit_type
        wins over a row without one; unmatched keys take the * row, or blank."""
        rows = self.rules.value_rows(lookup)
        default = next((v for k, v, s in rows if k == "*" and not s), None)
        expr = pl.lit(default, dtype=pl.Utf8)
        for k, v, s in rows:  # rows for both deposit types first ...
            if k != "*" and not s:
                expr = pl.when(key == k).then(pl.lit(v, dtype=pl.Utf8)).otherwise(expr)
        for k, v, s in rows:  # ... then type-specific rows, which take priority
            if s:
                match = pl.col("deposit_type") == s
                if k != "*":
                    match = match & (key == k)
                    expr = pl.when(match).then(pl.lit(v, dtype=pl.Utf8)).otherwise(expr)
        for k, v, s in rows:  # type-specific defaults apply only when nothing matched
            if k == "*" and s:
                expr = pl.when((pl.col("deposit_type") == s) & expr.is_null()).then(
                    pl.lit(v, dtype=pl.Utf8)).otherwise(expr)
        return expr

    def _individual_fields(self, frame: pl.DataFrame) -> pl.DataFrame:
        """GENDER and OCCUPATION: set for Individual accounts only; every other
        customer type gets the non-individual label."""
        gender = self._prep.get("gender") or {}
        prefixes = [str(p).strip().lower() for p in gender.get("female_prefixes") or ["f", "p", "w"]]
        female, male = str(gender.get("female", "Female")), str(gender.get("male", "Male"))
        other = str(self._prep.get("non_individual_label", "Non-Individual"))
        individual = pl.col("customer_type") == str(self.cfg["labels"]["individual"]["customer_type"])

        code = pl.col("CFSEX").cast(pl.Utf8).str.strip_chars().str.to_lowercase().fill_null("")
        is_female = pl.lit(False)
        for prefix in prefixes:
            is_female = is_female | code.str.starts_with(prefix)
        return frame.with_columns([
            pl.when(~individual).then(pl.lit(other))
            .when(is_female).then(pl.lit(female)).otherwise(pl.lit(male)).alias("GENDER"),
            pl.when(~individual).then(pl.lit(other))
            .otherwise(self._map_values(pl.col("occupation_code"), "occupation")).alias("OCCUPATION"),
        ])

    def _warn_unmapped(self, frame: pl.DataFrame, output: str, key: str, lookup: str,
                       individual_only: bool = False) -> None:
        """Warn when codes are missing from a value lookup (the output is blank)."""
        rows = frame.filter(pl.col(output).is_null() & (pl.col(key).fill_null("") != ""))
        if individual_only:
            rows = rows.filter(pl.col("customer_type") == str(self.cfg["labels"]["individual"]["customer_type"]))
        if not rows.height:
            return
        counts = (rows.group_by(["deposit_type", key]).agg(pl.col(output).is_null().sum().alias("n"))
                  .sort("n", descending=True))
        listed = ", ".join("{0} {1!r} ({2:,})".format(t, k, n) for t, k, n in counts.head(10).iter_rows())
        more = "" if counts.height <= 10 else " and {0:,} more".format(counts.height - 10)
        warnings.warn("{0:,} {1} code(s) not in the '{2}' lookup, {3} left blank: {4}{5}. Add rows to {6}."
                      .format(counts.height, lookup, lookup, output, listed, more, self.lookup_path.name),
                      stacklevel=3)

    @staticmethod
    def _julian(col: str) -> pl.Expr:
        """Julian YYYYJJJ to datetime; blanks and zeros take the earliest valid
        date in the load (inherited from depo prep)."""
        vx = pl.col(col).cast(pl.Utf8).str.strip_chars().cast(pl.Int64, strict=False).fill_null(0)
        earliest = vx.filter(vx > 1900000).min()
        earliest = pl.when(earliest.is_null()).then(pl.lit(1900001)).otherwise(earliest)
        return (pl.when(vx <= 1900000).then(earliest).otherwise(vx)
                .cast(pl.Utf8).str.to_datetime(format="%Y%j", strict=False))

    @staticmethod
    def _julian_strict(col: str) -> pl.Expr:
        """Julian YYYYJJJ to datetime; blanks, zeros and bad values stay blank."""
        vx = pl.col(col).cast(pl.Utf8).str.strip_chars().cast(pl.Int64, strict=False)
        return (pl.when(vx > 1900000).then(vx).otherwise(None)
                .cast(pl.Utf8).str.to_datetime(format="%Y%j", strict=False))

    def _number(self, col: str) -> pl.Expr:
        """Text to number, removing the same characters as the balance column."""
        expr = pl.col(col).cast(pl.Utf8, strict=False)
        for character in (self.cfg.get("normalisation") or {}).get("balance_strip_characters") or []:
            expr = expr.str.replace_all(re.escape(str(character)), "")
        return expr.str.strip_chars().cast(pl.Float64, strict=False)

    def _output(self, frame: pl.DataFrame, extra: List[str],
                extra_out: Dict[str, str]) -> pl.DataFrame:
        selection = [pl.col(logical).alias(header)
                     for header, logical in self._output_cfg["columns"].items()]
        selection += [pl.col(c) for c in TRANSFORMED_COLS]
        selection += [pl.col(RAW_PREFIX + c).alias(extra_out[c]) for c in extra if c in extra_out]
        return frame.select(selection)
