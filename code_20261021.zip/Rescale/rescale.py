"""
rescale.py — proportionally rescale granular data so its totals match reference figures.

Typical use: a detailed extract (e.g. by segment x region x product) does not quite add up to an
official report (e.g. by product only). This module scales each period x group of the detail so
its totals equal the report, while every detail row keeps its share within that group.

    import pandas as pd
    import rescale

    report  = pd.read_excel("report figure.xlsx")
    targets = rescale.wide_to_long(report, date_col="Month", group_col="Product",
                                   metrics=["Balance", "NOA"],
                                   group_map={"Savings": "SAVING", "Current": "CURRENT",
                                              "Awfar": "AWFAR", "iGain": "I-GAIN"})
    adjusted, recon = rescale.rescale_to_targets(
        data, targets, date_col="Date", group_cols=["Product"], metrics=["Balance", "NOA"],
        target_date_col="Month", freq="M", integer_metrics=["NOA"])

Rules
- Data and targets are bucketed to the same period (`freq`: "D", "W", "M", "Q", "Y"), so a
  month-end date in the data matches a month-start date in the report.
- Each period x group with a target is scaled by target / data_total, per metric.
- Integer metrics (counts) are rounded with the largest-remainder method: every row is a whole
  number and the group total equals the target exactly.
- Periods / groups without a target are left unchanged (`adjusted` = False).
- Pre-flight checks: the data index may be anything (duplicates included; it is restored on output);
  existing '<metric>_raw' / 'adjusted' columns are refused; unreadable dates and data groups that
  have no reference figure in a referenced period are reported with a warning.
- A target with nothing to scale (data total is 0 or the group has no rows) raises
  `ZeroBaseError` by default. `on_zero="skip"` leaves it unreconciled; `on_zero="spread"` splits
  the target equally across the group's existing rows (still unreconciled if there are none).

Compatible with Python 3.8, pandas 2.0.3, numpy 1.23.5.
"""
import warnings
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

__all__ = ["rescale_to_targets", "wide_to_long", "largest_remainder", "reconcile", "ZeroBaseError"]

_PERIOD = "__period__"
_VALID_ON_ZERO = ("raise", "skip", "spread")


class ZeroBaseError(ValueError):
    """Raised when a target exists but there is no data total to scale proportionally."""


# --------------------------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------------------------
def largest_remainder(values: pd.Series, total: float) -> pd.Series:
    """Round non-negative floats to integers whose sum equals `total` (largest-remainder method)."""
    floors = np.floor(values).astype(int)
    short = int(round(total)) - int(floors.sum())
    if short > 0:
        order = (values - floors).sort_values(ascending=False).index[:short]
        floors.loc[order] += 1
    elif short < 0:
        order = (values - floors).sort_values(ascending=True).index[:-short]
        floors.loc[order] -= 1
    return floors


def _to_period(s: pd.Series, freq: str) -> pd.Series:
    if isinstance(s.dtype, pd.PeriodDtype):
        return s.dt.asfreq(freq)
    return pd.to_datetime(s, errors="coerce").dt.to_period(freq)


def wide_to_long(report: pd.DataFrame, date_col: str, group_col: str, metrics: Sequence[str],
                 group_map: Optional[Dict[str, str]] = None, sep: str = " ") -> pd.DataFrame:
    """Reshape a wide report ('<group><sep><metric>' columns) to one row per date x group.

    `group_map` maps report group names to data group names (e.g. {"Savings": "SAVING"}). If given,
    only those groups are kept; otherwise every '<group> <metric>' column is used. Columns that do
    not end in a listed metric (e.g. 'Total Individual Balance' when that group is not mapped) are
    ignored.
    """
    rows = []
    for col in report.columns:
        if col == date_col:
            continue
        for m in metrics:
            suffix = sep + m
            if isinstance(col, str) and col.endswith(suffix):
                grp = col[: -len(suffix)]
                if group_map is not None:
                    if grp not in group_map:
                        break
                    grp = group_map[grp]
                rows.append(pd.DataFrame({date_col: report[date_col].values, group_col: grp,
                                          "__metric__": m, "__value__": report[col].values}))
                break
    if not rows:
        raise ValueError("No columns matched '<group>{}<metric>' for metrics {}".format(sep, list(metrics)))
    long = pd.concat(rows, ignore_index=True)
    out = long.pivot_table(index=[date_col, group_col], columns="__metric__", values="__value__",
                           aggfunc="first").reset_index()
    out.columns.name = None
    return out[[date_col, group_col] + [m for m in metrics if m in out.columns]]


def reconcile(adjusted: pd.DataFrame, targets: pd.DataFrame, date_col: str, group_cols: Sequence[str],
              metrics: Sequence[str], freq: str = "M", target_date_col: Optional[str] = None) -> pd.DataFrame:
    """Compare adjusted data totals with targets per period x group x metric."""
    target_date_col = target_date_col or date_col
    group_cols = list(group_cols)
    d = adjusted.assign(**{_PERIOD: _to_period(adjusted[date_col], freq)})
    t = targets.assign(**{_PERIOD: _to_period(targets[target_date_col], freq)})
    got = d.groupby([_PERIOD] + group_cols)[list(metrics)].sum()
    want = t.groupby([_PERIOD] + group_cols)[list(metrics)].sum(min_count=1)
    out = []
    for m in metrics:
        r = pd.DataFrame({"metric": m, "target": want[m]}).join(got[[m]].rename(columns={m: "actual"}), how="left")
        r["actual"] = r["actual"].fillna(0.0)
        r["diff"] = r["actual"] - r["target"]
        out.append(r.dropna(subset=["target"]))
    res = pd.concat(out).reset_index().rename(columns={_PERIOD: "period"})
    return res.sort_values(["period"] + group_cols + ["metric"]).reset_index(drop=True)


# --------------------------------------------------------------------------------------------
# main
# --------------------------------------------------------------------------------------------
def rescale_to_targets(data: pd.DataFrame, targets: pd.DataFrame, date_col: str, group_cols: Sequence[str],
                       metrics: Sequence[str], freq: str = "M", target_date_col: Optional[str] = None,
                       integer_metrics: Iterable[str] = (), label_map: Optional[Dict[str, Dict]] = None,
                       on_zero: str = "raise", keep_raw: bool = True,
                       ) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Scale `data` so each period x group total equals `targets`; return (adjusted, reconciliation).

    Parameters
    ----------
    data            granular rows; must contain `date_col`, `group_cols` and `metrics`.
    targets         one row per period x group (long form; see `wide_to_long`), with `metrics` columns.
                    A NaN target for a metric means "no target" for that metric.
    date_col        date column in `data` (datetime, string date or pandas Period).
    group_cols      columns that identify a target group (e.g. ["Product"]). [] = one total per period.
    metrics         additive columns to scale (e.g. ["Balance", "NOA"]).
    freq            period used to match data and targets: "D", "W", "M", "Q" or "Y".
    target_date_col date column in `targets` if it differs from `date_col`.
    integer_metrics metrics rounded to whole numbers with exact group totals (e.g. counts).
    label_map       {column: {data_value: target_value}} relabels data before matching,
                    e.g. {"Product": {"FCA": "CURRENT"}}. Relabelled values appear in the output.
    on_zero         "raise" (default), "skip" or "spread" — see module docstring.
    keep_raw        add '<metric>_raw' columns with the pre-scaling values, and an 'adjusted' flag.

    Returns
    -------
    adjusted        same rows and columns as `data` (plus audit columns), scaled.
    reconciliation  period x group x metric: data_before, target, actual (after), diff, factor, status.
    """
    if on_zero not in _VALID_ON_ZERO:
        raise ValueError("on_zero must be one of {}".format(_VALID_ON_ZERO))
    target_date_col = target_date_col or date_col
    group_cols, metrics = list(group_cols), list(metrics)
    integer_metrics = set(integer_metrics)
    unknown = integer_metrics - set(metrics)
    if unknown:
        raise ValueError("integer_metrics not in metrics: {}".format(sorted(unknown)))
    for name, frame, cols in (("data", data, [date_col] + group_cols + metrics),
                              ("targets", targets, [target_date_col] + group_cols)):
        missing = [c for c in cols if c not in frame.columns]
        if missing:
            raise KeyError("{} is missing columns: {}".format(name, missing))
    missing_t = [m for m in metrics if m not in targets.columns]
    if missing_t:
        raise KeyError("targets is missing metric columns: {}".format(missing_t))
    reserved = [_PERIOD] + ([m + "_raw" for m in metrics] + ["adjusted"] if keep_raw else [])
    clash = [c for c in reserved if c in data.columns]
    if clash:
        raise ValueError("data already has reserved column(s) {}; rename them or pass keep_raw=False".format(clash))

    original_index = data.index
    out = data.reset_index(drop=True)          # positional index: duplicate labels cannot misroute rows
    if label_map:
        for col, mapping in label_map.items():
            out[col] = out[col].replace(mapping)
    for m in metrics:
        out[m] = out[m].fillna(0)

    keys = [_PERIOD] + group_cols
    out[_PERIOD] = _to_period(out[date_col], freq)
    n_bad = int(out[_PERIOD].isna().sum())
    if n_bad:
        warnings.warn("{} data row(s) have a missing or unreadable '{}' and were left unchanged".format(n_bad, date_col))
    tgt = targets.assign(**{_PERIOD: _to_period(targets[target_date_col], freq)})
    if tgt[_PERIOD].isna().any():
        raise ValueError("targets has missing or unreadable dates in '{}'".format(target_date_col))
    dup = tgt.duplicated(keys, keep=False)
    if dup.any():
        raise ValueError("targets has duplicate period x group rows:\n{}".format(tgt.loc[dup, keys]))
    tgt = tgt.set_index(keys)[metrics]

    base = out.groupby(keys)[metrics].sum()
    if group_cols:
        ref_periods = set(tgt.index.get_level_values(0))
        orphans = [k for k in base.index if k[0] in ref_periods and k not in tgt.index]
        if orphans:
            warnings.warn("{} data group(s) have no reference figure in a referenced period and were left unchanged, "
                          "e.g. {}. Check labels or use label_map.".format(len(orphans), orphans[:5]))
    if keep_raw:
        for m in metrics:
            out[m + "_raw"] = out[m]
    out["adjusted"] = False

    recon_rows: List[dict] = []
    problems: List[str] = []
    row_index = out.groupby(keys).indices if keys else {}

    for key, trow in tgt.iterrows():
        key_t = key if isinstance(key, tuple) else (key,)
        idx = row_index.get(key_t if len(key_t) > 1 else key_t[0])
        has_rows = idx is not None and len(idx) > 0
        labels = out.index[idx] if has_rows else pd.Index([])
        any_scaled = False
        for m in metrics:
            target = trow[m]
            if pd.isna(target):
                continue
            before = float(base.loc[key, m]) if has_rows else 0.0
            status, factor = "scaled", np.nan
            if before == 0:
                if target == 0:
                    status = "ok (zero)"
                elif on_zero == "raise" or not has_rows:
                    status = "unreconciled: zero base" if has_rows else "unreconciled: no data rows"
                    problems.append("{} {} target={:,.2f} ({})".format(key_t, m, target, status.split(": ")[1]))
                elif on_zero == "spread":
                    vals = pd.Series(float(target) / len(labels), index=labels)
                    out.loc[labels, m] = largest_remainder(vals, target) if m in integer_metrics else vals
                    status = "spread"
                    any_scaled = True
                else:  # skip
                    status = "unreconciled: zero base (skipped)"
            else:
                factor = float(target) / before
                vals = out.loc[labels, m].astype(float) * factor
                out.loc[labels, m] = largest_remainder(vals, target) if m in integer_metrics else vals
                any_scaled = True
            recon_rows.append(dict(zip(keys, key_t), metric=m, data_before=before, target=float(target),
                                   factor=factor, status=status))
        if any_scaled:
            out.loc[labels, "adjusted"] = True

    if problems and on_zero == "raise":
        raise ZeroBaseError("Targets with nothing to scale (data total is 0 or no rows):\n  " + "\n  ".join(problems)
                            + "\nFix the data/labels, or pass on_zero='skip' or 'spread'.")

    for m in integer_metrics:
        if pd.api.types.is_numeric_dtype(out[m]) and (out[m].dropna() % 1 == 0).all():
            out[m] = out[m].astype(int)

    recon = pd.DataFrame(recon_rows)
    if not recon.empty:
        after = out.groupby(keys)[metrics].sum()
        recon["actual"] = [float(after.loc[tuple(r[k] for k in keys) if len(keys) > 1 else r[keys[0]], r["metric"]])
                           if (tuple(r[k] for k in keys) if len(keys) > 1 else r[keys[0]]) in after.index else 0.0
                           for _, r in recon.iterrows()]
        recon["diff"] = recon["actual"] - recon["target"]
        recon = recon.rename(columns={_PERIOD: "period"})
        recon = recon[["period"] + group_cols + ["metric", "data_before", "target", "actual", "diff", "factor", "status"]]

    out = out.drop(columns=[_PERIOD])
    out.index = original_index
    if not keep_raw:
        out = out.drop(columns=["adjusted"])
    return out, recon
