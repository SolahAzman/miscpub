"""
deposit_univariate_forecaster.py
================================

Univariate time-series forecasting for deposit portfolios at group level.

SCOPE, stated plainly because the name now carries it:

  * Univariate. Each cluster's NOA and ticket size are forecast from their own
    history and nothing else. No interest rates, no campaign calendar, no
    competitor pricing, no macro series, no cross-effects between the two metrics
    and none between clusters. February is the single exception, and it enters as
    a calendar flag derived from the series itself, not as external data.

  * Deposits. Built for month-end deposit balances and account counts, with
    `ticket_size = total_balance / total_noa` as the identity throughout. Nothing
    here is specific to deposits mathematically, but the defaults, the February
    unclaimed-money handling and the eligibility rules assume that shape of book.

What that rules out: if a rate change, a campaign or a competitor move is what
drives your forecast, this module cannot see it and will not tell you it is
missing. It will fit the trend that behaviour left behind in the history.

Pipeline
--------
1.  Preprocess          Vectorised. Derives ticket_size = total_balance / total_noa,
                        computes each group's max_date, and keeps only each group's
                        *latest contiguous run* of month-ends.
2.  Comparability       Per-group z-score of NOA and ticket size over a common
                        trailing window, so groups with different start dates and
                        wildly different scales are compared on shape alone.
3.  Cluster             KMeans on the z-scored series. k swept over a range and
                        chosen by silhouette (subsampled), subject to a floor.
                        Groups with too little history are excluded from fitting
                        and then assigned to the nearest centroid, and flagged.
4.  Cluster series      total_noa    = sum(total_noa)
                        ticket_size  = sum(total_balance) / sum(total_noa)
                        (NOA-weighted, so cluster_balance = cluster_noa x cluster_ticket
                        holds exactly and group forecasts reconcile to the cluster.)
5.  Candidate models    Five families, all fitted per cluster x metric:
                          - ExponentialSmoothing  (SES / Holt, optional damped trend)
                          - Holt-Winters          (additive trend + seasonal, period 12)
                          - Theta                 (statsmodels ThetaModel)
                          - ARIMA                 (statsmodels (p,d,q) grid by AIC)
                          - Prophet
6.  February event      Where a cluster shows a consistent, material February effect,
                        Prophet receives a February holiday and ARIMA a February dummy.
7.  Selection           Rolling-origin backtest (expanding window). Hyperparameters
                        are tuned INSIDE the folds. The 80/20 holdout is never seen
                        during tuning or selection.
8.  Holdout             Winner refit on train, scored on the untouched holdout.
9.  Forecast            Winner refit on the full series, `horizon` steps ahead.
                        Cumulative growth factors derived for point, lower and upper.
9b. Optimism            Optional judgement overlay on TICKET SIZE ONLY, in units of
                        one standard deviation of the forecast distribution
                        (`config.optimism`, range [-1, 1], default 0). Applied to the
                        future forecast only, never to backtesting, selection or
                        holdout scoring. The unadjusted figures survive as
                        `ticket_size_neutral` / `total_balance_neutral`.
10. Apply               Cluster growth factors applied to every eligible group's
                        latest actual values.
11. Group validation    The step-9/10 logic replayed across the holdout window and
                        scored at GROUP level, because cluster-level accuracy can
                        look excellent while individual group forecasts are poor.

Outputs
-------
run() returns (forecast_df, test_df). Also populated on the instance:
    .forecast_df            actuals for all groups + forecasts for eligible groups
    .test_df                long actual-vs-predicted on the holdout, winner only
    .attempts_df            every model x cluster x metric with status and reason
    .group_validation_df    group-level error distribution over the holdout
    .cluster_series         the modelled cluster-level series
    .cluster_assignments    group_id -> cluster, with diagnostics
    .selection_df           winner + backtest scores per cluster x metric

Notes on scale
--------------
Designed for ~20,000 groups x ~43 month-ends. All per-group work is vectorised;
there is no Python loop over groups. Model fitting happens at CLUSTER level only,
so its cost is independent of the group count.

Author: built for the deposit forecasting workstream.
"""

from __future__ import annotations

import json
import logging
import warnings
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score

from statsmodels.tsa.holtwinters import ExponentialSmoothing
from statsmodels.tsa.forecasting.theta import ThetaModel
from statsmodels.tsa.statespace.sarimax import SARIMAX
from statsmodels.tsa.stattools import adfuller

__all__ = ["DepositUnivariateForecaster", "ForecastConfig"]

logger = logging.getLogger(__name__)

# Prophet and its Stan backend are noisy and slow to import. Import lazily.
_PROPHET = None
_PROPHET_CHECKED = False


def silence_stan_logging() -> None:
    """
    Mute Prophet's Stan backend.

    cmdstanpy emits two INFO lines per fit. Across a full run that is thousands of
    lines of 'Chain [1] start processing' in the notebook, which buries the
    pipeline's own progress output. Setting the level alone is not enough --
    cmdstanpy attaches its own handler on import, so the handler has to go too.
    """
    for name in ("cmdstanpy", "prophet", "pystan", "httpstan"):
        lg = logging.getLogger(name)
        lg.handlers = []
        lg.setLevel(logging.CRITICAL)
        lg.propagate = False
        lg.disabled = True


def _get_prophet():
    """Import Prophet on first use. Returns the class, or None if unavailable."""
    global _PROPHET, _PROPHET_CHECKED
    if not _PROPHET_CHECKED:
        _PROPHET_CHECKED = True
        try:
            silence_stan_logging()
            from prophet import Prophet  # type: ignore

            silence_stan_logging()  # again: importing prophet re-attaches handlers
            _PROPHET = Prophet
        except Exception as exc:  # pragma: no cover - environment dependent
            logger.warning("Prophet unavailable (%s). It will be skipped.", exc)
            _PROPHET = None
    return _PROPHET


def _month_end_alias() -> str:
    """
    Return the month-end frequency alias valid for the installed pandas.

    pandas < 2.2 uses 'M'; 2.2 deprecates it in favour of 'ME'; 3.0 removes 'M'.
    """
    try:
        pd.tseries.frequencies.to_offset("ME")
        return "ME"
    except Exception:  # pragma: no cover - pandas < 2.2
        return "M"


ME = _month_end_alias()

# Columns the module owns. Everything else in the input is treated as a
# descriptive attribute (cat_col): ignored during modelling, reattached at output.
_RESERVED_COLS = {
    "as_of_dt",
    "group_id",
    "total_noa",
    "total_balance",
    "ticket_size",
    "max_date",
}

METRICS = ("total_noa", "ticket_size")

MODEL_TYPES = (
    "ExponentialSmoothing",
    "Holt-Winters",
    "Theta",
    "ARIMA",
    "Prophet",
)


# --------------------------------------------------------------------------- #
# Configuration
# --------------------------------------------------------------------------- #
@dataclass
class ForecastConfig:
    """
    All tunable behaviour. Every default is stated here rather than buried in code
    so a reviewer can see the full set of modelling choices in one place.
    """

    # ---- horizon and splitting -------------------------------------------- #
    horizon: int = 6
    test_size: float = 0.20
    backtest_folds: int = 4
    min_fold_train: int = 24  # keep every fold long enough for a 12-period seasonal fit
    seasonal_periods: int = 12

    # ---- group eligibility ------------------------------------------------ #
    min_history_months: int = 12
    common_window_coverage: float = 0.80  # window = longest covered by this share of groups

    # ---- clustering ------------------------------------------------------- #
    k_min: int = 4
    k_max: int = 15
    k_floor: int = 8  # silhouette alone favours very small k at this scale
    min_cluster_size: int = 30
    silhouette_sample: int = 5000
    random_state: int = 42

    # ---- cluster series construction -------------------------------------- #
    # 'auto'    : 'sum' where member composition is stable, 'chained' where it is not
    # 'sum'     : straight sum of member groups (interpretable, but entering/exiting
    #             groups create a spurious trend the model will happily extrapolate)
    # 'chained' : month-over-month growth computed on matched groups only, then
    #             chain-linked from the first month's true level
    cluster_series_mode: str = "auto"
    composition_stability_threshold: float = 0.95

    # ---- February event --------------------------------------------------- #
    # 'prefer' : where a February effect is detected, Prophet wins the cluster if it
    #            is within `feb_event_tolerance` of the best backtest RMSE
    # 'force'  : where detected, Prophet wins outright provided it fitted
    # 'off'    : detection still reported, but selection is pure RMSE
    feb_event: str = "prefer"
    feb_event_tolerance: float = 0.10
    feb_min_observations: int = 2  # Februaries with both neighbours inside the train window
    feb_effect_ratio: float = 1.5  # effect must exceed this x the series' normal deviation
    feb_min_effect: float = 0.005  # and be at least this large in relative terms

    # ---- selection -------------------------------------------------------- #
    selection_metric: str = "RMSE"  # RMSE | MAE | MAPE | MASE

    # ---- anomalous months ------------------------------------------------- #
    # Month-ends whose reported figures are a population artefact rather than
    # behaviour: a tagging exercise, a reclassification, a migration. For each listed
    # month every group's total_noa and total_balance are replaced by the midpoint of
    # its nearest clean months either side, and ticket_size is recomputed from those.
    #
    # The reported figures are NOT discarded. forecast_df keeps them on its Actual
    # rows, and both forecast_df and overall_series carry an `anomaly_month` flag, so
    # reporting still reconciles while the model never learns from the artefact.
    #
    # Leaving a spike in is not a neutral choice. A 5x one-month balance spike, tested
    # on synthetic data, wiped out February detection on ticket size (3 of 4 clusters
    # down to 0 of 4), widened the month-6 ticket interval from 1% to over 600%, moved
    # 18% of groups between clusters and shifted the portfolio balance forecast by 5%.
    #
    #     anomaly_months=["2023-06-30"]
    anomaly_months: Sequence[Any] = ()

    # ---- optimism (judgement overlay) ------------------------------------- #
    # Shifts the TICKET SIZE forecast by `optimism` x one standard deviation of the
    # forecast distribution at each step. NOA is never affected. Range [-1, 1]:
    # -1.0 = one sigma below the model's view (~16th percentile)
    #  0.0 = the model's view, unaltered (default)
    # +1.0 = one sigma above the model's view (~84th percentile)
    #
    # sigma is recovered from the model's own prediction interval, so it grows with
    # horizon: the overlay moves month 6 further than month 1, which is the right
    # shape. It applies to the FUTURE FORECAST ONLY -- never to backtesting, model
    # selection or holdout scoring, because accuracy measured on a deliberately
    # biased forecast would be meaningless.
    #
    # This is a judgement dial, not a modelling improvement. Whatever value is used
    # is stamped onto forecast_df and future_factors, and the unadjusted figure is
    # kept alongside as `ticket_size_neutral`, so a reader can always tell what the
    # model said and what judgement was layered on top.
    optimism: float = 0.0

    # ---- segment (descriptive only) --------------------------------------- #
    segment_lookback: int = 6
    segment_basis: str = "pct"  # 'pct' or 'abs'. 'abs' ranks by size, not behaviour.

    # ---- misc ------------------------------------------------------------- #
    uncertainty_samples: int = 200  # Prophet; lower than default 1000 for speed
    interval_alpha: float = 0.05
    verbose: bool = True

    def validate(self) -> None:
        if not 0 < self.test_size < 0.5:
            raise ValueError("test_size must be in (0, 0.5).")
        if self.horizon < 1:
            raise ValueError("horizon must be >= 1.")
        if self.k_min > self.k_max:
            raise ValueError("k_min must be <= k_max.")
        if self.feb_event not in {"prefer", "force", "off"}:
            raise ValueError("feb_event must be one of 'prefer', 'force', 'off'.")
        if self.cluster_series_mode not in {"auto", "sum", "chained"}:
            raise ValueError("cluster_series_mode must be 'auto', 'sum' or 'chained'.")
        if self.selection_metric not in {"RMSE", "MAE", "MAPE", "MASE"}:
            raise ValueError("selection_metric must be RMSE, MAE, MAPE or MASE.")
        if self.segment_basis not in {"pct", "abs"}:
            raise ValueError("segment_basis must be 'pct' or 'abs'.")
        for m in self.anomaly_months:
            try:
                pd.Timestamp(m)
            except Exception as exc:
                raise ValueError(f"anomaly_months entry {m!r} is not a date: {exc}") from None
        if not -1.0 <= float(self.optimism) <= 1.0:
            raise ValueError(
                f"optimism must be between -1.0 and 1.0 (got {self.optimism}). "
                "It is measured in standard deviations of the forecast distribution."
            )


# --------------------------------------------------------------------------- #
# Error metrics
# --------------------------------------------------------------------------- #
def _safe_denominator(y: np.ndarray) -> np.ndarray:
    d = np.abs(y).astype(float)
    d[d < 1e-8] = 1e-8
    return d


def error_metrics(
    y_true: Sequence[float],
    y_pred: Sequence[float],
    y_train: Optional[Sequence[float]] = None,
) -> Dict[str, float]:
    """MAE / RMSE / MAPE / MDAPE, plus MASE when a training series is supplied."""
    yt = np.asarray(y_true, dtype=float).ravel()
    yp = np.asarray(y_pred, dtype=float).ravel()
    mask = np.isfinite(yt) & np.isfinite(yp)
    yt, yp = yt[mask], yp[mask]
    if yt.size == 0:
        return {k: np.nan for k in ("MAE", "RMSE", "MAPE", "MDAPE", "MASE")}

    err = yt - yp
    ape = np.abs(err) / _safe_denominator(yt) * 100.0
    out = {
        "MAE": float(np.mean(np.abs(err))),
        "RMSE": float(np.sqrt(np.mean(err**2))),
        "MAPE": float(np.mean(ape)),
        "MDAPE": float(np.median(ape)),
        "MASE": np.nan,
    }
    if y_train is not None:
        tr = np.asarray(y_train, dtype=float).ravel()
        tr = tr[np.isfinite(tr)]
        if tr.size > 1:
            scale = np.mean(np.abs(np.diff(tr)))
            if scale > 1e-12:
                out["MASE"] = float(np.mean(np.abs(err)) / scale)
    return out


# --------------------------------------------------------------------------- #
# Model layer
# --------------------------------------------------------------------------- #
def _param_grid(model_type: str, n_obs: int, positive: bool, feb: bool,
                cfg: ForecastConfig) -> List[Dict[str, Any]]:
    """Candidate hyperparameters for one model family, given the series at hand."""
    sp = cfg.seasonal_periods
    if model_type == "ExponentialSmoothing":
        return [
            {"trend": None, "damped_trend": False},
            {"trend": "add", "damped_trend": False},
            {"trend": "add", "damped_trend": True},
        ]
    if model_type == "Holt-Winters":
        grid = [
            {"trend": "add", "seasonal": "add", "damped_trend": False},
            {"trend": "add", "seasonal": "add", "damped_trend": True},
        ]
        if positive:
            grid.append({"trend": "add", "seasonal": "mul", "damped_trend": True})
        return grid
    if model_type == "Theta":
        if n_obs >= 2 * sp:
            return [{"deseasonalize": True}, {"deseasonalize": False}]
        return [{"deseasonalize": False}]
    if model_type == "ARIMA":
        # Order is chosen internally by AIC, so there is nothing to grid over.
        return [{"max_p": 2, "max_q": 2}]
    if model_type == "Prophet":
        cps = [0.01, 0.1, 0.5]
        hps = [1.0, 10.0] if feb else [10.0]
        return [{"changepoint_prior_scale": c, "holidays_prior_scale": h}
                for c in cps for h in hps]
    raise ValueError(f"Unknown model type: {model_type}")


def _model_is_feasible(model_type: str, y: pd.Series, cfg: ForecastConfig) -> Tuple[bool, str]:
    """Cheap pre-flight check so a skip is recorded with a reason instead of a crash."""
    n = len(y)
    sp = cfg.seasonal_periods
    if n < 4:
        return False, f"series too short (n={n})"
    if model_type == "Holt-Winters" and n < 2 * sp:
        return False, f"n={n} < 2 x seasonal_periods ({2 * sp}); seasonal fit not identifiable"
    if model_type == "ARIMA" and n < 8:
        return False, f"n={n} too short for ARIMA order search"
    if model_type == "Prophet":
        if _get_prophet() is None:
            return False, "prophet not installed"
        if n < 8:
            return False, f"n={n} too short for Prophet"
    if not np.isfinite(y.to_numpy(dtype=float)).all():
        return False, "series contains non-finite values"
    if float(np.nanstd(y.to_numpy(dtype=float))) < 1e-12:
        return False, "series is constant"
    return True, ""


def _residual_interval(point: np.ndarray, resid: np.ndarray, alpha: float
                       ) -> Tuple[np.ndarray, np.ndarray]:
    """
    Fan-out interval for models with no native prediction interval.

    Widens with sqrt(h), which is the correct shape for a random-walk-like error
    accumulation and is what makes the band grow with horizon rather than sit flat.
    """
    from scipy.stats import norm

    resid = np.asarray(resid, dtype=float)
    resid = resid[np.isfinite(resid)]
    sd = float(np.std(resid, ddof=1)) if resid.size > 1 else 0.0
    z = float(norm.ppf(1.0 - alpha / 2.0))
    steps = np.arange(1, len(point) + 1, dtype=float)
    half = z * sd * np.sqrt(steps)
    return point - half, point + half


def _choose_arima_d(y: np.ndarray, max_d: int = 2) -> int:
    """Pick the differencing order with a sequence of ADF tests."""
    series = np.asarray(y, dtype=float)
    for d in range(max_d + 1):
        test = series if d == 0 else np.diff(series, n=d)
        if len(test) < 8 or np.std(test) < 1e-12:
            return d
        try:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                pval = adfuller(test, autolag="AIC")[1]
            if pval <= 0.05:
                return d
        except Exception:
            return min(d, 1)
    return max_d


def _fit_arima(y: pd.Series, params: Dict[str, Any], steps: int, alpha: float,
               exog_train: Optional[np.ndarray], exog_future: Optional[np.ndarray]
               ) -> Dict[str, Any]:
    """statsmodels (p,d,q) grid scored by AIC. Replaces pmdarima.auto_arima."""
    values = y.to_numpy(dtype=float)
    d = _choose_arima_d(values)
    best = None
    for p in range(params.get("max_p", 2) + 1):
        for q in range(params.get("max_q", 2) + 1):
            if p == 0 and q == 0 and d == 0:
                continue
            try:
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore")
                    res = SARIMAX(
                        values,
                        exog=exog_train,
                        order=(p, d, q),
                        trend="c" if d == 0 else "n",
                        enforce_stationarity=False,
                        enforce_invertibility=False,
                    ).fit(disp=False)
                aic = float(res.aic)
                if np.isfinite(aic) and (best is None or aic < best[0]):
                    best = (aic, (p, d, q), res)
            except Exception:
                continue
    if best is None:
        raise RuntimeError("no ARIMA order converged")

    _, order, res = best
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        fc = res.get_forecast(steps=steps, exog=exog_future)
        point = np.asarray(fc.predicted_mean, dtype=float)
        ci = np.asarray(fc.conf_int(alpha=alpha), dtype=float)
    return {
        "point": point,
        "lower": ci[:, 0],
        "upper": ci[:, 1],
        "resolved_params": {"order": list(order)},
    }


def _fit_prophet(y: pd.Series, params: Dict[str, Any], steps: int, alpha: float,
                 future_index: pd.DatetimeIndex, holidays: Optional[pd.DataFrame],
                 cfg: ForecastConfig) -> Dict[str, Any]:
    Prophet = _get_prophet()
    if Prophet is None:
        raise RuntimeError("prophet not installed")
    silence_stan_logging()

    hist = pd.DataFrame({"ds": y.index, "y": y.to_numpy(dtype=float)})
    # 34 monthly points cannot support Prophet's default yearly Fourier order of 10
    # (20 parameters). Constrain it, and drop it entirely below two cycles.
    yearly: Any = 3 if len(y) >= 2 * cfg.seasonal_periods else False
    kwargs = dict(
        yearly_seasonality=yearly,
        weekly_seasonality=False,
        daily_seasonality=False,
        interval_width=1.0 - alpha,
        uncertainty_samples=cfg.uncertainty_samples,
        changepoint_prior_scale=params.get("changepoint_prior_scale", 0.05),
    )
    if holidays is not None and not holidays.empty:
        kwargs["holidays"] = holidays
        kwargs["holidays_prior_scale"] = params.get("holidays_prior_scale", 10.0)

    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        model = Prophet(**kwargs)
        model.fit(hist)
        # Build the future frame explicitly. make_future_dataframe's `freq` argument
        # is a moving target across pandas versions; this sidesteps it.
        fut = pd.DataFrame({"ds": future_index})
        pred = model.predict(fut)

    return {
        "point": pred["yhat"].to_numpy(dtype=float),
        "lower": pred["yhat_lower"].to_numpy(dtype=float),
        "upper": pred["yhat_upper"].to_numpy(dtype=float),
        "resolved_params": {},
    }


def fit_predict(
    model_type: str,
    y: pd.Series,
    params: Dict[str, Any],
    steps: int,
    cfg: ForecastConfig,
    future_index: pd.DatetimeIndex,
    feb_holidays: Optional[pd.DataFrame] = None,
    feb_exog_train: Optional[np.ndarray] = None,
    feb_exog_future: Optional[np.ndarray] = None,
) -> Dict[str, Any]:
    """
    Uniform fit-and-forecast interface across all five model families.

    Returns dict with 'point', 'lower', 'upper' (each length `steps`) and
    'resolved_params' for anything decided inside the fit (e.g. the ARIMA order).
    """
    alpha = cfg.interval_alpha
    sp = cfg.seasonal_periods

    if model_type in ("ExponentialSmoothing", "Holt-Winters"):
        kwargs = dict(params)
        if model_type == "Holt-Winters":
            kwargs["seasonal_periods"] = sp
        else:
            kwargs["seasonal"] = None
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            res = ExponentialSmoothing(
                y, initialization_method="estimated", **kwargs
            ).fit(optimized=True)
            point = np.asarray(res.forecast(steps), dtype=float)
            resid = np.asarray(res.resid, dtype=float)
        lower, upper = _residual_interval(point, resid, alpha)
        return {"point": point, "lower": lower, "upper": upper, "resolved_params": {}}

    if model_type == "Theta":
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            res = ThetaModel(y, period=sp, **params).fit()
            point = np.asarray(res.forecast(steps), dtype=float)
            try:
                pi = res.prediction_intervals(steps, alpha=alpha)
                lower = np.asarray(pi.iloc[:, 0], dtype=float)
                upper = np.asarray(pi.iloc[:, 1], dtype=float)
            except Exception:
                fitted = np.asarray(y, dtype=float)
                lower, upper = _residual_interval(point, np.diff(fitted), alpha)
        return {"point": point, "lower": lower, "upper": upper, "resolved_params": {}}

    if model_type == "ARIMA":
        return _fit_arima(y, params, steps, alpha, feb_exog_train, feb_exog_future)

    if model_type == "Prophet":
        return _fit_prophet(y, params, steps, alpha, future_index, feb_holidays, cfg)

    raise ValueError(f"Unknown model type: {model_type}")


# --------------------------------------------------------------------------- #
# February event detection
# --------------------------------------------------------------------------- #
def detect_february_effect(series: pd.Series, cfg: ForecastConfig) -> Dict[str, Any]:
    """
    Test whether February deviates systematically from its two neighbours.

    For every interior month t the local deviation is

        dev[t] = (y[t] - (y[t-1] + y[t+1]) / 2) / |(y[t-1] + y[t+1]) / 2|

    A February effect is flagged when, across the training window, every February
    deviation shares the same sign AND their mean magnitude exceeds both an absolute
    floor and `feb_effect_ratio` times the standard deviation of non-February
    deviations. Sign-agnostic by design: closing dormant low-balance accounts pushes
    NOA down and average ticket size *up*, so the two metrics move oppositely.

    Detection runs on the TRAIN window only; the holdout is never consulted.
    """
    y = series.dropna()
    out: Dict[str, Any] = {
        "detected": False,
        "effect": np.nan,
        "n_observations": 0,
        "reason": "",
    }
    if len(y) < 5:
        out["reason"] = "series too short to test"
        return out

    vals = y.to_numpy(dtype=float)
    neighbours = (vals[:-2] + vals[2:]) / 2.0
    denom = np.abs(neighbours)
    denom[denom < 1e-8] = 1e-8
    dev = (vals[1:-1] - neighbours) / denom
    months = y.index.month.to_numpy()[1:-1]

    feb = dev[months == 2]
    other = dev[months != 2]
    out["n_observations"] = int(feb.size)

    if feb.size < cfg.feb_min_observations:
        out["reason"] = f"only {feb.size} usable February observation(s) in train window"
        return out
    if other.size < 3:
        out["reason"] = "not enough non-February months for a baseline"
        return out

    mean_feb = float(np.mean(feb))
    consistent = bool(np.all(np.sign(feb) == np.sign(mean_feb)) and abs(mean_feb) > 0)
    baseline = float(np.std(other, ddof=1)) if other.size > 1 else 0.0
    out["effect"] = mean_feb

    if not consistent:
        out["reason"] = "February deviations not consistent in sign"
        return out
    if abs(mean_feb) < cfg.feb_min_effect:
        out["reason"] = f"February effect {mean_feb:+.3%} below floor {cfg.feb_min_effect:.3%}"
        return out
    if abs(mean_feb) < cfg.feb_effect_ratio * baseline:
        out["reason"] = (
            f"February effect {mean_feb:+.3%} not distinguishable from normal "
            f"month-to-month noise ({baseline:.3%})"
        )
        return out

    out["detected"] = True
    out["reason"] = (
        f"consistent February effect {mean_feb:+.3%} across {feb.size} year(s), "
        f"vs baseline deviation {baseline:.3%}"
    )
    return out


def build_february_holidays(index: pd.DatetimeIndex, future_index: pd.DatetimeIndex
                            ) -> pd.DataFrame:
    """
    February holiday frame for Prophet, on true month-end dates.

    The previous implementation hard-coded '<year>-02-28'. In a leap year the
    month-end is the 29th, so the February 2024 observation fell outside the
    holiday window entirely and was never modelled.
    """
    all_dates = index.union(future_index)
    if len(all_dates) == 0:
        return pd.DataFrame(columns=["holiday", "ds", "lower_window", "upper_window"])
    start = all_dates.min() - pd.DateOffset(years=1)
    end = all_dates.max() + pd.DateOffset(years=1)
    month_ends = pd.date_range(start=start, end=end, freq=ME)
    febs = month_ends[month_ends.month == 2]
    return pd.DataFrame(
        {
            "holiday": "february_event",
            "ds": febs,
            "lower_window": 0,
            "upper_window": 0,
        }
    )


def february_dummy(index: pd.DatetimeIndex) -> np.ndarray:
    """Column vector February indicator, for use as SARIMAX exog."""
    return (index.month == 2).astype(float).reshape(-1, 1)


# --------------------------------------------------------------------------- #
# Main class
# --------------------------------------------------------------------------- #
class DepositUnivariateForecaster:
    """
    Forecast deposit NOA and ticket size by behavioural cluster, then apply the
    cluster growth paths to every eligible group.

    Parameters
    ----------
    data : pd.DataFrame, optional
        Pre-aggregated input: one row per group_id per month-end. Must contain
        `as_of_dt`, `group_id`, `total_noa` and `total_balance`. `ticket_size` is
        derived if absent. Every other column is treated as a descriptive
        attribute, ignored during modelling and reattached to the output.
    file_path : str, optional
        CSV path, used when `data` is not supplied.
    config : ForecastConfig, optional
    cat_cols : list of str, optional
        Override the auto-detected descriptive columns.

    Example
    -------
    >>> fc = DepositUnivariateForecaster(file_path="deposits.csv")
    >>> forecast_df, test_df = fc.run()
    >>> fc.group_validation_df      # group-level accuracy, not just cluster-level
    """

    def __init__(
        self,
        data: Optional[pd.DataFrame] = None,
        file_path: Optional[str] = None,
        config: Optional[ForecastConfig] = None,
        cat_cols: Optional[List[str]] = None,
    ):
        if data is None and file_path is None:
            raise ValueError("Supply either `data` or `file_path`.")
        self.file_path = file_path
        self._input_data = data
        self.config = config or ForecastConfig()
        self.config.validate()
        self._cat_cols_override = cat_cols

        # populated as the pipeline runs
        self.raw: Optional[pd.DataFrame] = None
        self.panel: Optional[pd.DataFrame] = None
        self.cat_cols: List[str] = []
        self.group_attrs: Optional[pd.DataFrame] = None
        self.group_meta: Optional[pd.DataFrame] = None
        self.window: Optional[int] = None
        self.cluster_assignments: Optional[pd.DataFrame] = None
        self.cluster_series: Optional[pd.DataFrame] = None
        self.cluster_diagnostics: Optional[pd.DataFrame] = None
        self.segment_df: Optional[pd.DataFrame] = None
        self.attempts_df: Optional[pd.DataFrame] = None
        self.selection_df: Optional[pd.DataFrame] = None
        self.test_df: Optional[pd.DataFrame] = None
        self.group_test_df: Optional[pd.DataFrame] = None
        self.combined_df: Optional[pd.DataFrame] = None
        self.future_factors: Optional[pd.DataFrame] = None
        self.forecast_df: Optional[pd.DataFrame] = None
        self.group_validation_df: Optional[pd.DataFrame] = None
        self.registry: Dict[Tuple[str, str], Dict[str, Any]] = {}
        self.all_dates: Optional[pd.DatetimeIndex] = None
        self.latest_date: Optional[pd.Timestamp] = None
        self.split_index: Optional[int] = None
        self.anomaly_dates: pd.DatetimeIndex = pd.DatetimeIndex([])

    # ------------------------------------------------------------------ #
    # small helpers
    # ------------------------------------------------------------------ #
    def _log(self, msg: str, *args: Any) -> None:
        if self.config.verbose:
            print(msg % args if args else msg, flush=True)

    # ------------------------------------------------------------------ #
    # 1. Preprocess
    # ------------------------------------------------------------------ #
    def preprocess(self) -> pd.DataFrame:
        """
        Load, validate and reshape the input.

        Fully vectorised: no per-group Python loop. Extracting each group's latest
        contiguous run is done with a groupby-diff and a cumulative-sum run id,
        which is O(n log n) rather than the O(n_groups x n_rows) scan the previous
        implementation used.
        """
        cfg = self.config
        df = self._input_data.copy() if self._input_data is not None else pd.read_csv(self.file_path)

        missing = {"as_of_dt", "group_id", "total_noa", "total_balance"} - set(df.columns)
        if missing:
            raise ValueError(f"Input is missing required column(s): {sorted(missing)}")

        # Snap to month-end so equality joins against the modelled dates always hold.
        df["as_of_dt"] = pd.to_datetime(df["as_of_dt"]) + pd.offsets.MonthEnd(0)
        df["total_noa"] = pd.to_numeric(df["total_noa"], errors="coerce")
        df["total_balance"] = pd.to_numeric(df["total_balance"], errors="coerce")

        self.cat_cols = (
            list(self._cat_cols_override)
            if self._cat_cols_override is not None
            else [c for c in df.columns if c not in _RESERVED_COLS]
        )

        # Collapse any duplicate (group_id, as_of_dt) rows before deriving ticket size,
        # otherwise the division is done on a fragment of the group.
        dup = df.duplicated(subset=["group_id", "as_of_dt"]).sum()
        if dup:
            self._log("  ! %d duplicate (group_id, as_of_dt) rows found; summing them.", dup)
            agg: Dict[str, Any] = {"total_noa": "sum", "total_balance": "sum"}
            agg.update({c: "last" for c in self.cat_cols})
            df = df.groupby(["group_id", "as_of_dt"], as_index=False).agg(agg)

        # Ticket size is always recomputed from the identity, never trusted from input.
        noa = df["total_noa"].to_numpy(dtype=float)
        bal = df["total_balance"].to_numpy(dtype=float)
        with np.errstate(divide="ignore", invalid="ignore"):
            df["ticket_size"] = np.where(noa > 0, bal / noa, np.nan)

        n_before = len(df)
        df = df[np.isfinite(df["total_noa"]) & (df["total_noa"] > 0)]
        df = df[np.isfinite(df["ticket_size"])]
        if len(df) < n_before:
            self._log("  ! dropped %d row(s) with non-positive or missing NOA.", n_before - len(df))

        self.raw = df.copy()
        self.all_dates = pd.DatetimeIndex(sorted(df["as_of_dt"].unique()))
        self.latest_date = self.all_dates.max()

        # --- latest contiguous run per group (vectorised) ------------------ #
        df = df.sort_values(["group_id", "as_of_dt"], kind="mergesort").reset_index(drop=True)
        month_ix = df["as_of_dt"].dt.year * 12 + df["as_of_dt"].dt.month
        step = month_ix.groupby(df["group_id"]).diff()
        is_break = step.ne(1).fillna(True)
        run_id = is_break.cumsum()
        last_run = run_id.groupby(df["group_id"]).transform("max")
        gaps_per_group = run_id.groupby(df["group_id"]).transform("nunique") - 1

        full_len = df.groupby("group_id")["as_of_dt"].transform("size")
        df = df.assign(_run_id=run_id, _gaps=gaps_per_group, _full_len=full_len)
        panel = df[df["_run_id"] == last_run].copy()

        n_trimmed = int((df["_gaps"] > 0).groupby(df["group_id"]).first().sum())
        if n_trimmed:
            self._log(
                "  %d group(s) had gaps; using only the latest contiguous run for each.",
                n_trimmed,
            )

        # --- group metadata ------------------------------------------------ #
        meta = (
            panel.groupby("group_id")
            .agg(
                max_date=("as_of_dt", "max"),
                first_date=("as_of_dt", "min"),
                run_length=("as_of_dt", "size"),
            )
            .reset_index()
        )
        meta["has_gap"] = (
            df.groupby("group_id")["_gaps"].first().reindex(meta["group_id"]).to_numpy() > 0
        )
        meta["eligible"] = meta["max_date"] == self.latest_date
        meta["thin_history"] = meta["eligible"] & (meta["run_length"] < cfg.min_history_months)
        self.group_meta = meta

        panel["max_date"] = panel["group_id"].map(
            meta.set_index("group_id")["max_date"]
        )

        # --- descriptive attributes, taken at each group's LATEST month ----- #
        attrs = (
            panel.sort_values("as_of_dt", kind="mergesort")
            .groupby("group_id", as_index=False)
            .tail(1)[["group_id"] + self.cat_cols]
            .copy()
        )
        for c in self.cat_cols:
            if attrs[c].dtype == object or isinstance(attrs[c].dtype, pd.CategoricalDtype):
                attrs[c] = attrs[c].astype("category")
        self.group_attrs = attrs

        self.panel = panel[
            ["as_of_dt", "group_id", "total_noa", "total_balance", "ticket_size", "max_date"]
        ].reset_index(drop=True)

        # Neutralise artefact months before clustering, model fitting or the February
        # check ever see them. Runs on the modelling panel only; self.raw keeps the
        # reported figures for the output.
        self._neutralise_anomaly_months()

        n_groups = meta.shape[0]
        n_elig = int(meta["eligible"].sum())
        self._log(
            "  %s rows | %s groups | %s month-ends (%s .. %s)",
            f"{len(self.panel):,}", f"{n_groups:,}", len(self.all_dates),
            self.all_dates.min().date(), self.latest_date.date(),
        )
        self._log(
            "  eligible (present in latest month): %s | thin history (<%d mths): %s",
            f"{n_elig:,}", cfg.min_history_months, f"{int(meta['thin_history'].sum()):,}",
        )
        self._log("  descriptive columns carried through: %s", self.cat_cols or "(none)")
        return self.panel

    def _neutralise_anomaly_months(self) -> None:
        """
        Replace artefact months with the midpoint of each group's nearest clean
        months, so the model never treats a population change as behaviour.

        Vectorised: a grouped ffill and bfill, no Python loop over groups. For a
        single flagged month this is ordinary linear interpolation. For a run of
        consecutive flagged months every one of them takes the same midpoint value
        rather than a ramp, which is the conservative reading when you do not know
        what shape the underlying series had.

        A flagged month at the very start or end of a group's history has a clean
        neighbour on one side only, and takes that side's value.
        """
        cfg = self.config
        self.anomaly_dates = pd.DatetimeIndex(
            sorted({pd.Timestamp(m) + pd.offsets.MonthEnd(0) for m in cfg.anomaly_months})
        )
        if len(self.anomaly_dates) == 0:
            return

        pan = self.panel
        hit = pan["as_of_dt"].isin(self.anomaly_dates)
        matched = self.anomaly_dates.intersection(pd.DatetimeIndex(pan["as_of_dt"].unique()))
        unmatched = self.anomaly_dates.difference(matched)
        if len(unmatched):
            self._log(
                "  ! anomaly_months not present in the data, ignored: %s",
                ", ".join(d.date().isoformat() for d in unmatched),
            )
        if not hit.any():
            return

        cols = ["total_noa", "total_balance"]
        pan = pan.sort_values(["group_id", "as_of_dt"], kind="mergesort").reset_index(drop=True)
        hit = pan["as_of_dt"].isin(self.anomaly_dates)
        reported = pan.loc[hit, cols].to_numpy(dtype=float)

        blanked = pan[cols].astype(float).copy()
        blanked.loc[hit.to_numpy(), :] = np.nan
        g = blanked.groupby(pan["group_id"], sort=False)
        prev, nxt = g.ffill(), g.bfill()
        repl = (prev + nxt) / 2.0
        repl = repl.fillna(prev).fillna(nxt)

        # The midpoint is fractional; if total_noa arrived as an integer column, an
        # in-place assignment raises on strict pandas. Widen the target columns to
        # float first (they hold averaged counts now, not true integers).
        for c in cols:
            pan[c] = pan[c].astype(float)
        pan.loc[hit, cols] = repl.loc[hit].to_numpy()
        pan = pan[pan[cols].notna().all(axis=1)]

        noa = pan["total_noa"].to_numpy(dtype=float)
        bal = pan["total_balance"].to_numpy(dtype=float)
        with np.errstate(divide="ignore", invalid="ignore"):
            pan["ticket_size"] = np.where(noa > 0, bal / noa, np.nan)
        pan = pan[np.isfinite(pan["ticket_size"])]
        self.panel = pan.reset_index(drop=True)

        adjusted = self.panel["as_of_dt"].isin(self.anomaly_dates)
        after = self.panel.loc[adjusted, cols].to_numpy(dtype=float)
        n = min(len(reported), len(after))
        for i, c in enumerate(cols):
            with np.errstate(divide="ignore", invalid="ignore"):
                change = np.where(np.abs(reported[:n, i]) > 0,
                                  after[:n, i] / reported[:n, i] - 1.0, np.nan)
            self._log(
                "  anomaly months %s: %s adjusted for modelling, median %s change %+.1f%%",
                ", ".join(d.date().isoformat() for d in matched),
                f"{int(adjusted.sum()):,}" if i == 0 else "same rows",
                c, float(np.nanmedian(change) * 100.0),
            )
        self._log("  reported figures are unchanged in forecast_df and flagged `anomaly_month`.")

    # ------------------------------------------------------------------ #
    # 2. Comparability window + z-scored matrices
    # ------------------------------------------------------------------ #
    def _z_matrices(self) -> Tuple[pd.DataFrame, np.ndarray, np.ndarray]:
        """
        Build per-group z-scored NOA and ticket-size matrices over a common window.

        The window is the longest trailing span covered by at least
        `common_window_coverage` of eligible groups, which is exactly the
        (1 - coverage) percentile of run length. Rebasing to each group's own first
        value -- the previous approach -- anchors different groups to different
        calendar months and is not a comparable basis.
        """
        cfg = self.config
        meta = self.group_meta
        elig = meta[meta["eligible"]]
        if elig.empty:
            raise ValueError("No group is present in the latest month; nothing to forecast.")

        pct = (1.0 - cfg.common_window_coverage) * 100.0
        window = int(np.floor(np.percentile(elig["run_length"].to_numpy(), pct)))
        window = int(np.clip(window, cfg.min_history_months, len(self.all_dates)))
        coverage = float((elig["run_length"] >= window).mean())
        self.window = window
        self._log(
            "  common window: %d months (covers %.1f%% of eligible groups)",
            window, coverage * 100.0,
        )

        elig_ids = set(elig["group_id"])
        pan = self.panel[self.panel["group_id"].isin(elig_ids)].copy()
        pan = pan.sort_values(["group_id", "as_of_dt"], kind="mergesort")
        # position counted back from each group's last observation
        pan["_pos"] = pan.groupby("group_id").cumcount(ascending=False)
        pan = pan[pan["_pos"] < window]

        noa_wide = pan.pivot(index="group_id", columns="_pos", values="total_noa")
        tkt_wide = pan.pivot(index="group_id", columns="_pos", values="ticket_size")
        # columns currently run newest(0) -> oldest; flip to chronological
        noa_wide = noa_wide.reindex(columns=sorted(noa_wide.columns, reverse=True))
        tkt_wide = tkt_wide.reindex(columns=sorted(tkt_wide.columns, reverse=True))
        return noa_wide, tkt_wide, np.asarray(noa_wide.index)

    @staticmethod
    def _zscore_rows(mat: np.ndarray) -> np.ndarray:
        """Row-wise z-score, with a zero row where the series is flat."""
        mu = np.nanmean(mat, axis=1, keepdims=True)
        sd = np.nanstd(mat, axis=1, keepdims=True)
        sd = np.where(sd < 1e-12, 1.0, sd)
        z = (mat - mu) / sd
        return np.nan_to_num(z, nan=0.0, posinf=0.0, neginf=0.0)

    @staticmethod
    def _resample_to(mat: np.ndarray, target: int) -> np.ndarray:
        """Linearly resample each row (ignoring leading NaNs) onto `target` points."""
        out = np.zeros((mat.shape[0], target), dtype=float)
        xt = np.linspace(0.0, 1.0, target)
        for i in range(mat.shape[0]):
            row = mat[i]
            row = row[np.isfinite(row)]
            if row.size == 0:
                continue
            if row.size == 1:
                out[i, :] = row[0]
                continue
            out[i, :] = np.interp(xt, np.linspace(0.0, 1.0, row.size), row)
        return out

    # ------------------------------------------------------------------ #
    # 3. Cluster
    # ------------------------------------------------------------------ #
    def cluster(self) -> pd.DataFrame:
        """
        Cluster eligible groups on the shape of their z-scored NOA and ticket series.

        `k` is swept over [max(k_min, k_floor), k_max] and chosen by silhouette
        computed on a subsample -- a full silhouette on 20,000 points would build a
        20,000 x 20,000 distance matrix (~3.2 GB).

        Groups whose contiguous run is shorter than `min_history_months` do not
        take part in fitting the centroids; they are resampled onto the common
        window and assigned to the nearest one afterwards, and flagged
        `thin_history=True` so a reader can see which forecasts rest on thin
        evidence.
        """
        cfg = self.config
        noa_wide, tkt_wide, ids = self._z_matrices()
        meta = self.group_meta.set_index("group_id")

        run_len = meta.loc[ids, "run_length"].to_numpy()
        raw_noa = noa_wide.to_numpy(dtype=float)
        raw_tkt = tkt_wide.to_numpy(dtype=float)

        # A group "covers" the window when it has an observation at every position
        # in it. Covering groups fit the centroids. Groups with real but shorter
        # history are time-normalised onto the window and assigned afterwards --
        # a 30-month group is not "thin", it just doesn't span the window.
        covers = np.isfinite(raw_noa).all(axis=1) & np.isfinite(raw_tkt).all(axis=1)
        n_obs = np.isfinite(raw_noa).sum(axis=1)

        X = np.zeros((len(ids), 2 * self.window), dtype=float)
        if covers.any():
            X[covers] = np.hstack(
                [self._zscore_rows(raw_noa[covers]), self._zscore_rows(raw_tkt[covers])]
            )
        if (~covers).any():
            X[~covers] = np.hstack(
                [
                    self._zscore_rows(self._resample_to(raw_noa[~covers], self.window)),
                    self._zscore_rows(self._resample_to(raw_tkt[~covers], self.window)),
                ]
            )

        full_mask = covers
        X_fit = X[full_mask]
        if X_fit.shape[0] < 2:
            raise ValueError(
                "Fewer than 2 groups have enough history to fit clusters. "
                f"min_history_months={cfg.min_history_months} may be too strict."
            )

        ks = [k for k in range(cfg.k_min, cfg.k_max + 1) if k >= cfg.k_floor]
        ks = [k for k in ks if k < X_fit.shape[0]] or [min(2, X_fit.shape[0])]

        sample = min(cfg.silhouette_sample, X_fit.shape[0] - 1)
        best_k, best_score, best_model = None, -np.inf, None
        for k in ks:
            km = KMeans(n_clusters=k, random_state=cfg.random_state, n_init=10)
            labels = km.fit_predict(X_fit)
            if len(np.unique(labels)) < 2:
                continue
            score = float(
                silhouette_score(
                    X_fit, labels, sample_size=sample, random_state=cfg.random_state
                )
            )
            self._log("    k=%-3d silhouette=%.4f", k, score)
            if score > best_score:
                best_k, best_score, best_model = k, score, km
        if best_model is None:
            raise RuntimeError("Clustering failed: no k produced more than one cluster.")

        labels_fit = best_model.labels_
        centroids = best_model.cluster_centers_
        self._log("  chosen k=%d (silhouette %.4f, floor=%d)", best_k, best_score, cfg.k_floor)

        labels = np.empty(X.shape[0], dtype=int)
        labels[full_mask] = labels_fit
        assign_kind = np.where(full_mask, "fitted", "nearest_centroid")

        # groups that do not span the window: assign to the nearest centroid.
        # Below 3 observations there is no shape to match on, so those fall back
        # to the largest cluster and are marked as such rather than pretending.
        out_idx = np.where(~full_mask)[0]
        if out_idx.size:
            usable = n_obs[out_idx] >= 3
            dist = ((X[out_idx][:, None, :] - centroids[None, :, :]) ** 2).sum(axis=2)
            near = dist.argmin(axis=1)
            largest = int(pd.Series(labels_fit).value_counts().idxmax())
            labels[out_idx] = np.where(usable, near, largest)
            assign_kind[out_idx] = np.where(usable, "nearest_centroid", "fallback_largest")
            self._log(
                "  %s group(s) shorter than the window assigned by nearest centroid "
                "(%s by fallback).",
                f"{int(usable.sum()):,}", f"{int((~usable).sum()):,}",
            )

        assign = pd.DataFrame(
            {
                "group_id": ids,
                "cluster": [f"C{int(l):02d}" for l in labels],
                "assignment": assign_kind,
                "run_length": run_len,
                # thin_history means genuinely little evidence, not merely
                # "shorter than the common window"
                "thin_history": run_len < cfg.min_history_months,
            }
        )

        # enforce a minimum cluster size by reassigning tiny clusters
        sizes = assign["cluster"].value_counts()
        small = sizes[sizes < cfg.min_cluster_size].index.tolist()
        keep = [c for c in sizes.index if c not in small]
        # If every cluster is below the floor (a small segment), there is nothing to
        # merge into -- leave the clusters as they are rather than crashing.
        if small and not keep:
            self._log(
                "  all %d cluster(s) are below min_cluster_size=%d; kept as-is "
                "(segment too small to enforce it).", len(small), cfg.min_cluster_size,
            )
            small = []
        if small:
            keep_lbl = np.array([int(c[1:]) for c in keep], dtype=int)
            mask_small = assign["cluster"].isin(small).to_numpy()
            d = ((X[mask_small][:, None, :] - centroids[keep_lbl][None, :, :]) ** 2).sum(axis=2)
            assign.loc[mask_small, "cluster"] = [keep[i] for i in d.argmin(axis=1)]
            assign.loc[mask_small, "assignment"] = "merged_small_cluster"
            self._log("  merged %d cluster(s) below min_cluster_size=%d.", len(small), cfg.min_cluster_size)

        self.cluster_assignments = assign
        counts = assign["cluster"].value_counts().sort_index()
        self._log("  cluster sizes: %s", ", ".join(f"{c}={n:,}" for c, n in counts.items()))
        return assign

    # ------------------------------------------------------------------ #
    # 4. Cluster-level series
    # ------------------------------------------------------------------ #
    def build_cluster_series(self) -> pd.DataFrame:
        """
        Aggregate member groups into one series per cluster.

            total_noa   = sum(total_noa)
            ticket_size = sum(total_balance) / sum(total_noa)

        The NOA-weighted ticket size is the definitionally correct cluster figure.
        An unweighted mean of group ticket sizes -- the previous behaviour -- is not
        the cluster's ticket size at all, and breaks the identity
        balance = noa x ticket, which is what makes group forecasts reconcile back
        to the cluster.

        Composition handling: eligible groups can enter the panel at different
        dates, so a straight sum shows a spurious ramp as members appear. Where
        member coverage is unstable the series is chain-linked instead: growth is
        computed month over month on matched groups only, then compounded from the
        first month's true level.
        """
        cfg = self.config
        assign = self.cluster_assignments[["group_id", "cluster"]]
        pan = self.panel.merge(assign, on="group_id", how="inner")

        grp = pan.groupby(["cluster", "as_of_dt"], observed=True)
        agg = grp.agg(
            total_noa=("total_noa", "sum"),
            total_balance=("total_balance", "sum"),
            n_members=("group_id", "size"),
        ).reset_index()
        agg["ticket_size"] = agg["total_balance"] / agg["total_noa"]

        member_counts = assign.groupby("cluster", observed=True)["group_id"].size()
        agg["composition_ratio"] = agg["n_members"] / agg["cluster"].map(member_counts)

        # matched-pairs growth, for the chained variant
        pan = pan.sort_values(["group_id", "as_of_dt"], kind="mergesort")
        pan["prev_noa"] = pan.groupby("group_id")["total_noa"].shift(1)
        pan["prev_bal"] = pan.groupby("group_id")["total_balance"].shift(1)
        pan["prev_dt"] = pan.groupby("group_id")["as_of_dt"].shift(1)
        matched = pan[
            pan["prev_dt"].notna()
            & (
                (pan["as_of_dt"].dt.year * 12 + pan["as_of_dt"].dt.month)
                - (pan["prev_dt"].dt.year * 12 + pan["prev_dt"].dt.month)
                == 1
            )
        ]
        m = matched.groupby(["cluster", "as_of_dt"], observed=True).agg(
            noa_now=("total_noa", "sum"),
            noa_prev=("prev_noa", "sum"),
            bal_now=("total_balance", "sum"),
            bal_prev=("prev_bal", "sum"),
        ).reset_index()
        m["g_noa"] = m["noa_now"] / m["noa_prev"]
        m["g_tkt"] = (m["bal_now"] / m["noa_now"]) / (m["bal_prev"] / m["noa_prev"])

        agg = agg.merge(m[["cluster", "as_of_dt", "g_noa", "g_tkt"]],
                        on=["cluster", "as_of_dt"], how="left")

        frames, diags = [], []
        for cid, sub in agg.groupby("cluster", observed=True):
            sub = sub.sort_values("as_of_dt").reset_index(drop=True)
            min_comp = float(sub["composition_ratio"].min())
            if cfg.cluster_series_mode == "sum":
                mode = "sum"
            elif cfg.cluster_series_mode == "chained":
                mode = "chained"
            else:
                mode = "sum" if min_comp >= cfg.composition_stability_threshold else "chained"

            if mode == "chained":
                # copy=True: pandas can hand back a read-only view here
                g_noa = np.array(sub["g_noa"].fillna(1.0).to_numpy(), dtype=float, copy=True)
                g_tkt = np.array(sub["g_tkt"].fillna(1.0).to_numpy(), dtype=float, copy=True)
                g_noa[0], g_tkt[0] = 1.0, 1.0
                noa = np.cumprod(g_noa)
                tkt = np.cumprod(g_tkt)
                # Anchor the index on the LATEST month's true total rather than the
                # first. Growth is identical either way, but this puts the level on
                # the same scale as reality at the point the forecast departs from,
                # so `predicted_value` reads as an actual NOA / ticket figure and
                # the group forecasts reconcile to it exactly. Scaling a series by a
                # constant scales every model's error identically, so model
                # selection is unaffected.
                noa = noa / noa[-1] * float(sub["total_noa"].iloc[-1])
                tkt = tkt / tkt[-1] * float(sub["ticket_size"].iloc[-1])
            else:
                noa = sub["total_noa"].to_numpy(dtype=float)
                tkt = sub["ticket_size"].to_numpy(dtype=float)

            frames.append(
                pd.DataFrame(
                    {
                        "cluster": cid,
                        "as_of_dt": sub["as_of_dt"],
                        "total_noa": noa,
                        "ticket_size": tkt,
                        "total_balance": noa * tkt,
                        "actual_total_noa": sub["total_noa"].to_numpy(dtype=float),
                        "actual_ticket_size": sub["ticket_size"].to_numpy(dtype=float),
                        "composition_ratio": sub["composition_ratio"],
                    }
                )
            )
            diags.append(
                {
                    "cluster": cid,
                    "n_groups": int(member_counts.get(cid, 0)),
                    "series_mode": mode,
                    "min_composition_ratio": min_comp,
                    "n_months": int(len(sub)),
                }
            )

        self.cluster_series = pd.concat(frames, ignore_index=True)
        self.cluster_diagnostics = pd.DataFrame(diags)
        n_chained = int((self.cluster_diagnostics["series_mode"] == "chained").sum())
        if n_chained:
            self._log(
                "  %d cluster(s) chain-linked due to unstable member composition.", n_chained
            )
        return self.cluster_series

    def _series_for(self, cluster_id: str, metric: str) -> pd.Series:
        sub = self.cluster_series[self.cluster_series["cluster"] == cluster_id]
        s = sub.set_index("as_of_dt")[metric].sort_index()
        s = s.asfreq(ME)
        return s.astype(float)

    # ------------------------------------------------------------------ #
    # 5. Backtest, tune and select
    # ------------------------------------------------------------------ #
    def _fold_origins(self, n_train: int) -> List[int]:
        """Expanding-window origins inside the training span."""
        cfg = self.config
        h, folds = cfg.horizon, cfg.backtest_folds
        last = n_train - h
        if last < cfg.min_fold_train:
            # not enough room for the requested minimum; fall back to whatever fits
            last = max(4, n_train - h)
            floor = max(4, last - (folds - 1))
        else:
            floor = cfg.min_fold_train
        span = last - floor
        step = 1 if folds <= 1 or span <= 0 else max(1, min(h, span // (folds - 1)))
        origins = sorted({last - i * step for i in range(folds) if last - i * step >= floor})
        return origins or [last]

    def backtest_and_select(self) -> pd.DataFrame:
        """
        Fit all five families per cluster x metric, tune inside backtest folds, and
        pick a winner.

        Two properties matter here and neither held in the previous implementation:

        1. Hyperparameters are chosen on backtest folds carved out of the TRAINING
           span. The 80/20 holdout is not touched until `evaluate_holdout`, so the
           error reported there is genuinely out of sample. Previously parameters
           were tuned by minimising RMSE on the very points then reported as the
           test score, which biases that score low by an unknown amount.

        2. Every model attempt is recorded with a status. Under "fit all five and
           compare", a model that crashes simply never wins -- without a log there
           is no way to distinguish "Prophet lost fairly" from "Prophet threw on
           every cluster and was never in the race".
        """
        cfg = self.config
        clusters = sorted(self.cluster_series["cluster"].unique())
        attempts: List[Dict[str, Any]] = []
        selection: List[Dict[str, Any]] = []
        self.registry = {}

        n_total = len(self.all_dates)
        split = int(np.floor(n_total * (1.0 - cfg.test_size)))
        split = int(np.clip(split, cfg.min_fold_train + 1, n_total - 1))
        self.split_index = split
        origins = self._fold_origins(split)
        self._log(
            "  split: %d train / %d holdout | backtest origins at %s (horizon %d)",
            split, n_total - split, origins, cfg.horizon,
        )

        for cid in clusters:
            for metric in METRICS:
                full = self._series_for(cid, metric)
                train = full.iloc[:split]

                feb = detect_february_effect(train, cfg)
                use_feb = bool(feb["detected"]) and cfg.feb_event != "off"

                results: Dict[str, Dict[str, Any]] = {}
                for model_type in MODEL_TYPES:
                    ok, why = _model_is_feasible(model_type, train, cfg)
                    if not ok:
                        attempts.append(
                            dict(cluster=cid, metric=metric, model_type=model_type,
                                 status="skipped", reason=why, backtest_score=np.nan,
                                 best_params=None, n_folds=0, feb_event_applied=use_feb)
                        )
                        continue

                    positive = bool((train > 0).all())
                    grid = _param_grid(model_type, len(train), positive, use_feb, cfg)
                    best_score, best_params, n_ok = np.inf, None, 0
                    last_err = ""

                    for params in grid:
                        errs: List[np.ndarray] = []
                        acts: List[np.ndarray] = []
                        folds_ok = 0
                        for origin in origins:
                            y_tr = full.iloc[:origin]
                            y_te = full.iloc[origin: origin + cfg.horizon]
                            if len(y_te) == 0:
                                continue
                            feas, _ = _model_is_feasible(model_type, y_tr, cfg)
                            if not feas:
                                continue
                            try:
                                res = fit_predict(
                                    model_type, y_tr, params, len(y_te), cfg,
                                    future_index=y_te.index,
                                    feb_holidays=build_february_holidays(y_tr.index, y_te.index)
                                    if (use_feb and model_type == "Prophet") else None,
                                    feb_exog_train=february_dummy(y_tr.index)
                                    if (use_feb and model_type == "ARIMA") else None,
                                    feb_exog_future=february_dummy(y_te.index)
                                    if (use_feb and model_type == "ARIMA") else None,
                                )
                            except Exception as exc:
                                last_err = f"{type(exc).__name__}: {exc}"[:200]
                                continue
                            p = np.asarray(res["point"], dtype=float)
                            if not np.isfinite(p).all():
                                last_err = "non-finite forecast"
                                continue
                            errs.append(y_te.to_numpy(dtype=float) - p)
                            acts.append(y_te.to_numpy(dtype=float))
                            folds_ok += 1

                        if folds_ok == 0:
                            continue
                        e = np.concatenate(errs)
                        a = np.concatenate(acts)
                        score = self._score(e, a, train)
                        if score < best_score:
                            best_score, best_params, n_ok = score, params, folds_ok

                    if best_params is None:
                        attempts.append(
                            dict(cluster=cid, metric=metric, model_type=model_type,
                                 status="failed", reason=last_err or "no fold converged",
                                 backtest_score=np.nan, best_params=None, n_folds=0,
                                 feb_event_applied=use_feb)
                        )
                        continue

                    attempts.append(
                        dict(cluster=cid, metric=metric, model_type=model_type,
                             status="ok", reason="", backtest_score=best_score,
                             best_params=json.dumps(best_params, default=str),
                             n_folds=n_ok, feb_event_applied=use_feb)
                    )
                    results[model_type] = {"score": best_score, "params": best_params}

                if not results:
                    raise RuntimeError(
                        f"All five models failed for cluster {cid} / {metric}. "
                        "Inspect .attempts_df for the reasons."
                    )

                winner, rule = self._pick_winner(results, use_feb)
                self.registry[(cid, metric)] = {
                    "model_type": winner,
                    "params": results[winner]["params"],
                    "backtest_score": results[winner]["score"],
                    "feb": feb,
                    "feb_event_applied": use_feb,
                    "selection_rule": rule,
                }
                selection.append(
                    dict(
                        cluster=cid, metric=metric, model_type=winner,
                        selection_rule=rule,
                        backtest_score=results[winner]["score"],
                        best_params=json.dumps(results[winner]["params"], default=str),
                        feb_event_applied=use_feb,
                        feb_effect=feb["effect"], feb_reason=feb["reason"],
                        n_models_competed=len(results),
                        runner_up_gap=self._runner_up_gap(results, winner),
                    )
                )

        self.attempts_df = pd.DataFrame(attempts)
        self.selection_df = pd.DataFrame(selection)
        self._log(
            "  winners: %s",
            ", ".join(
                f"{m}={n}" for m, n in
                self.selection_df["model_type"].value_counts().items()
            ),
        )
        n_feb = int(self.selection_df["feb_event_applied"].sum())
        if n_feb:
            self._log("  February event applied in %d cluster-metric combination(s).", n_feb)
        return self.selection_df

    def _score(self, err: np.ndarray, actual: np.ndarray, train: pd.Series) -> float:
        m = self.config.selection_metric
        if m == "RMSE":
            return float(np.sqrt(np.mean(err**2)))
        if m == "MAE":
            return float(np.mean(np.abs(err)))
        if m == "MAPE":
            return float(np.mean(np.abs(err) / _safe_denominator(actual)) * 100.0)
        tr = train.to_numpy(dtype=float)
        scale = np.mean(np.abs(np.diff(tr))) if tr.size > 1 else np.nan
        return float(np.mean(np.abs(err)) / scale) if scale and scale > 1e-12 else np.inf

    @staticmethod
    def _runner_up_gap(results: Dict[str, Dict[str, Any]], winner: str) -> float:
        """Relative gap to the next-best model. Small values mean the choice was a coin flip."""
        others = [v["score"] for k, v in results.items() if k != winner]
        if not others:
            return np.nan
        best = results[winner]["score"]
        second = min(others)
        return float((second - best) / best) if best > 1e-12 else np.nan

    def _pick_winner(self, results: Dict[str, Dict[str, Any]], use_feb: bool) -> Tuple[str, str]:
        cfg = self.config
        best = min(results, key=lambda k: results[k]["score"])
        if not use_feb or "Prophet" not in results:
            return best, "metric"
        if cfg.feb_event == "force":
            return "Prophet", "feb_forced"
        if cfg.feb_event == "prefer" and best != "Prophet":
            bs = results[best]["score"]
            ps = results["Prophet"]["score"]
            if np.isfinite(bs) and bs > 0 and ps <= bs * (1.0 + cfg.feb_event_tolerance):
                return "Prophet", "feb_preference"
        return best, "metric"

    # ------------------------------------------------------------------ #
    # 6. Holdout evaluation
    # ------------------------------------------------------------------ #
    def evaluate_holdout(self) -> pd.DataFrame:
        """
        Refit each winner on the training span and score it on the untouched holdout.

        These are the numbers to quote. They have not informed tuning or selection.

        One caveat worth knowing: with 43 month-ends an 80/20 split leaves a 9-month
        holdout, while models are tuned at `horizon` (6). The last three holdout
        steps therefore sit beyond the horizon the models were optimised for, so
        holdout error is, if anything, slightly pessimistic relative to how the
        6-month production forecast will behave.
        """
        cfg = self.config
        rows: List[Dict[str, Any]] = []
        split = self.split_index

        for (cid, metric), reg in self.registry.items():
            full = self._series_for(cid, metric)
            train, test = full.iloc[:split], full.iloc[split:]
            model_type, params = reg["model_type"], reg["params"]
            use_feb = reg["feb_event_applied"]
            try:
                res = fit_predict(
                    model_type, train, params, len(test), cfg,
                    future_index=test.index,
                    feb_holidays=build_february_holidays(train.index, test.index)
                    if (use_feb and model_type == "Prophet") else None,
                    feb_exog_train=february_dummy(train.index)
                    if (use_feb and model_type == "ARIMA") else None,
                    feb_exog_future=february_dummy(test.index)
                    if (use_feb and model_type == "ARIMA") else None,
                )
            except Exception as exc:
                logger.warning("Holdout fit failed for %s/%s: %s", cid, metric, exc)
                continue

            point = np.asarray(res["point"], dtype=float)
            mets = error_metrics(test.to_numpy(dtype=float), point, train.to_numpy(dtype=float))
            reg["holdout"] = mets
            reg["holdout_point"] = point
            reg["holdout_index"] = test.index
            reg["train_end_value"] = float(train.iloc[-1])

            n_groups = int(
                self.cluster_assignments.loc[
                    self.cluster_assignments["cluster"] == cid
                ].shape[0]
            )
            for dt, act, pred, lo, hi in zip(
                test.index, test.to_numpy(dtype=float), point,
                np.asarray(res["lower"], dtype=float), np.asarray(res["upper"], dtype=float),
            ):
                rows.append(
                    dict(
                        cluster=cid, metric=metric, as_of_dt=dt,
                        actual=float(act), predicted=float(pred),
                        lower=float(lo), upper=float(hi),
                        error=float(act - pred),
                        abs_pct_error=float(abs(act - pred) / max(abs(act), 1e-8) * 100.0),
                        model_type=model_type,
                        selection_rule=reg["selection_rule"],
                        feb_event_applied=use_feb,
                        params=json.dumps(params, default=str),
                        backtest_score=reg["backtest_score"],
                        holdout_MAE=mets["MAE"], holdout_RMSE=mets["RMSE"],
                        holdout_MAPE=mets["MAPE"], holdout_MDAPE=mets["MDAPE"],
                        holdout_MASE=mets["MASE"],
                        n_groups_in_cluster=n_groups,
                    )
                )

        self.test_df = pd.DataFrame(rows).sort_values(
            ["cluster", "metric", "as_of_dt"]
        ).reset_index(drop=True)

        if not self.test_df.empty:
            summary = (
                self.test_df.groupby("metric", observed=True)[["holdout_MAPE", "holdout_MASE"]]
                .mean()
            )
            for metric, row in summary.iterrows():
                mase = row["holdout_MASE"]
                flag = ""
                if np.isfinite(mase) and mase >= 1.0:
                    flag = "  <-- worse than a naive last-value forecast"
                self._log(
                    "  holdout %-12s mean MAPE %6.2f%% | mean MASE %5.2f%s",
                    metric, row["holdout_MAPE"], mase, flag,
                )
        return self.test_df

    # ------------------------------------------------------------------ #
    # 7. Future forecast -> cumulative growth factors
    # ------------------------------------------------------------------ #
    def forecast_future(self) -> pd.DataFrame:
        """
        Refit each winner on the full series and forecast `horizon` steps.

        Growth is expressed as a CUMULATIVE factor relative to the last actual, not
        as a chain of month-over-month percentages applied to point, lower and upper
        alike. That earlier construction gave the point estimate and both bounds the
        same multiplier, so -- having started equal at the last actual -- they stayed
        equal at every step and the intervals carried no information at all.

        Here the bounds are cumulative factors built from the model's own interval,
        so the band widens with horizon as it should.
        """
        cfg = self.config
        rows: List[Dict[str, Any]] = []

        for (cid, metric), reg in self.registry.items():
            full = self._series_for(cid, metric)
            future_index = pd.date_range(
                full.index.max() + pd.offsets.MonthEnd(1), periods=cfg.horizon, freq=ME
            )
            model_type, params = reg["model_type"], reg["params"]
            use_feb = reg["feb_event_applied"]
            try:
                res = fit_predict(
                    model_type, full, params, cfg.horizon, cfg,
                    future_index=future_index,
                    feb_holidays=build_february_holidays(full.index, future_index)
                    if (use_feb and model_type == "Prophet") else None,
                    feb_exog_train=february_dummy(full.index)
                    if (use_feb and model_type == "ARIMA") else None,
                    feb_exog_future=february_dummy(future_index)
                    if (use_feb and model_type == "ARIMA") else None,
                )
            except Exception as exc:
                logger.warning("Future fit failed for %s/%s: %s", cid, metric, exc)
                continue

            last = float(full.iloc[-1])
            if abs(last) < 1e-12:
                continue
            point = np.asarray(res["point"], dtype=float)
            lower = np.asarray(res["lower"], dtype=float)
            upper = np.asarray(res["upper"], dtype=float)
            # keep bounds ordered even if a model returns them crossed
            lower, upper = np.minimum(lower, upper), np.maximum(lower, upper)

            # Recover the forecast standard deviation from the model's own interval.
            # Doing it this way means one definition of sigma serves all five model
            # families, whether the interval came from Prophet's samples, SARIMAX's
            # covariance or a residual fan-out.
            from scipy.stats import norm

            z = float(norm.ppf(1.0 - cfg.interval_alpha / 2.0))
            sigma = (upper - lower) / (2.0 * z) if z > 0 else np.zeros_like(point)

            for i, dt in enumerate(future_index):
                rows.append(
                    dict(
                        cluster=cid, metric=metric, as_of_dt=dt, step=i + 1,
                        model_type=model_type, last_actual=last,
                        predicted_neutral=float(point[i]),
                        lower_neutral=float(lower[i]), upper_neutral=float(upper[i]),
                        sigma=float(sigma[i]),
                        feb_event_applied=use_feb,
                    )
                )

        self.future_factors = pd.DataFrame(rows).sort_values(
            ["cluster", "metric", "step"]
        ).reset_index(drop=True)
        self._apply_optimism()
        return self.future_factors

    # ------------------------------------------------------------------ #
    # 7b. Optimism overlay
    # ------------------------------------------------------------------ #
    def _apply_optimism(self) -> pd.DataFrame:
        """
        Layer the optimism overlay onto the stored neutral forecast.

        adjusted_ticket[h] = neutral_ticket[h] + optimism * sigma[h]

        Only `ticket_size` moves; `total_noa` always carries an overlay of zero.
        The whole interval shifts with the point, so the band keeps its width --
        optimism re-centres the view, it does not change how uncertain the model is.

        This is pure arithmetic on values already computed, so changing optimism
        does not require refitting anything (see `set_optimism`).
        """
        ff = self.future_factors
        if ff is None or ff.empty:
            return ff
        opt = float(self.config.optimism)

        is_ticket = ff["metric"].eq("ticket_size").to_numpy()
        shift = np.where(is_ticket, opt * ff["sigma"].to_numpy(dtype=float), 0.0)

        point = ff["predicted_neutral"].to_numpy(dtype=float) + shift
        last = ff["last_actual"].to_numpy(dtype=float)

        # A large negative overlay on a very uncertain series could in principle push
        # ticket size to or below zero, which is not a meaningful figure. Floor it and
        # say so rather than emitting a negative average balance.
        floor = 1e-6 * np.abs(last)
        breached = point < floor
        if breached.any():
            n = int(breached.sum())
            point = np.where(breached, floor, point)
            shift = point - ff["predicted_neutral"].to_numpy(dtype=float)
            logger.warning(
                "optimism=%.2f drove %d ticket-size forecast point(s) to or below zero; "
                "floored. The overlay is too large relative to those clusters' uncertainty.",
                opt, n,
            )
            self._log(
                "  ! optimism=%.2f floored %d forecast point(s) at zero — overlay too "
                "large for those clusters.", opt, n,
            )

        ff["optimism"] = np.where(is_ticket, opt, 0.0)
        ff["optimism_shift"] = shift
        ff["predicted_value"] = point
        ff["lower_bound"] = ff["lower_neutral"].to_numpy(dtype=float) + shift
        ff["upper_bound"] = ff["upper_neutral"].to_numpy(dtype=float) + shift

        ff["cum_factor"] = point / last
        ff["cum_factor_neutral"] = ff["predicted_neutral"].to_numpy(dtype=float) / last
        ff["cum_factor_lower"] = ff["lower_bound"].to_numpy(dtype=float) / last
        ff["cum_factor_upper"] = ff["upper_bound"].to_numpy(dtype=float) / last

        ff.sort_values(["cluster", "metric", "step"], inplace=True)
        prev = ff.groupby(["cluster", "metric"], observed=True)["predicted_value"].shift(1)
        prev = prev.fillna(ff["last_actual"])
        ff["pct_change_mom"] = (ff["predicted_value"] - prev) / prev.abs() * 100.0
        ff["pct_change_cum"] = (ff["cum_factor"] - 1.0) * 100.0
        ff.reset_index(drop=True, inplace=True)

        self.future_factors = ff
        return ff

    def set_optimism(self, optimism: float) -> pd.DataFrame:
        """
        Change the optimism overlay and rebuild the output, without refitting.

        Returns the rebuilt `forecast_df`.

        >>> fc.set_optimism(0.5)     # half a standard deviation more optimistic on ticket
        """
        self.config.optimism = float(optimism)
        self.config.validate()
        if self.future_factors is None or self.future_factors.empty:
            raise RuntimeError("Run forecast_future() before setting optimism.")
        self._apply_optimism()
        return self.apply_forecasts()

    def _cluster_base(self) -> pd.DataFrame:
        """Latest-month NOA, balance and ticket size per cluster, over eligible groups."""
        elig = self.group_meta.loc[self.group_meta["eligible"], "group_id"]
        b = (
            self.panel[
                (self.panel["as_of_dt"] == self.latest_date)
                & (self.panel["group_id"].isin(elig))
            ]
            .merge(self.cluster_assignments[["group_id", "cluster"]], on="group_id", how="inner")
            .groupby("cluster", observed=True)
            .agg(base_noa=("total_noa", "sum"), base_balance=("total_balance", "sum"))
        )
        b["base_ticket"] = b["base_balance"] / b["base_noa"]
        return b

    def optimism_sensitivity(
        self, values: Sequence[float] = (-1.0, -0.5, 0.0, 0.5, 1.0)
    ) -> pd.DataFrame:
        """
        Show how far the optimism dial actually moves the answer.

        Reports the portfolio position at the final forecast month under each setting.
        Worth running before anyone picks a value: if the spread from -1 to +1 is
        larger than the decision the forecast is feeding, the dial is doing more work
        than the model is, and that should be visible rather than buried in a config.

        The instance's own optimism setting is restored on exit.
        """
        if self.future_factors is None or self.future_factors.empty:
            raise RuntimeError("Run forecast_future() first.")

        base = self._cluster_base()
        final_dt = self.future_factors["as_of_dt"].max()
        original = self.config.optimism
        rows: List[Dict[str, Any]] = []
        try:
            for v in values:
                self.config.optimism = float(v)
                self._apply_optimism()
                ff = self.future_factors
                sub = ff[ff["as_of_dt"] == final_dt].pivot_table(
                    index="cluster", columns="metric", values="cum_factor"
                )
                idx = base.index.intersection(sub.index)
                noa = base.loc[idx, "base_noa"] * sub.loc[idx, "total_noa"]
                tkt = base.loc[idx, "base_ticket"] * sub.loc[idx, "ticket_size"]
                rows.append(
                    {
                        "optimism": float(v),
                        "as_of_dt": final_dt,
                        "portfolio_noa": float(noa.sum()),
                        "portfolio_balance": float((noa * tkt).sum()),
                        "portfolio_ticket": float((noa * tkt).sum() / noa.sum()),
                    }
                )
        finally:
            self.config.optimism = original
            self._apply_optimism()

        out = pd.DataFrame(rows)
        neutral = out.loc[out["optimism"] == 0.0, "portfolio_balance"]
        if len(neutral):
            n = float(neutral.iloc[0])
            out["balance_vs_neutral_pct"] = (out["portfolio_balance"] / n - 1.0) * 100.0
        return out

    # ------------------------------------------------------------------ #
    # 8. Segment (descriptive only)
    # ------------------------------------------------------------------ #
    def assign_segment(self) -> pd.DataFrame:
        """
        Growth-matrix label per group, for reporting only.

        This no longer forms part of the cluster key. It is also computed on
        PERCENTAGE change by default: the previous version quantiled the absolute
        variance (curn - prev), which ranks a 1M-account book growing 2% above a
        small book that doubled. That is a size ranking wearing a behaviour label.
        Set `segment_basis='abs'` to reproduce the old behaviour.
        """
        cfg = self.config
        max_dt = self.latest_date
        prev_dt = max_dt + pd.offsets.MonthEnd(-cfg.segment_lookback)

        sub = self.panel[self.panel["as_of_dt"].isin([max_dt, prev_dt])]
        wide = sub.pivot_table(
            index="group_id", columns="as_of_dt",
            values=["total_noa", "ticket_size", "total_balance"], aggfunc="sum",
        )
        if wide.empty:
            self.segment_df = pd.DataFrame(
                {"group_id": self.group_meta["group_id"], "segment": "Stagnant"}
            )
            return self.segment_df

        out = pd.DataFrame(index=wide.index)
        # A missing lookback month must yield an all-NaN COLUMN, not a bare scalar --
        # a float has no .abs()/.replace() and would blow up the pct branch.
        nan_col = pd.Series(np.nan, index=wide.index, dtype=float)
        for m in ("total_noa", "ticket_size", "total_balance"):
            cur = wide[(m, max_dt)] if (m, max_dt) in wide.columns else nan_col
            pre = wide[(m, prev_dt)] if (m, prev_dt) in wide.columns else nan_col
            out[f"curn_{m}"] = cur
            out[f"prev_{m}"] = pre
            if cfg.segment_basis == "pct":
                out[f"{m}_variance"] = (cur - pre) / pre.abs().replace(0, np.nan) * 100.0
            else:
                out[f"{m}_variance"] = cur - pre

        out = out.reset_index()
        noa_v, tkt_v = out["total_noa_variance"], out["ticket_size_variance"]
        n25, n75 = noa_v.quantile([0.25, 0.75])
        t25, t75 = tkt_v.quantile([0.25, 0.75])
        conditions = [
            (noa_v >= n75) & (tkt_v >= t75),
            (noa_v <= n25) & (tkt_v <= t25),
            (noa_v <= n25) & (tkt_v >= t75),
            (noa_v >= n75) & (tkt_v <= t25),
        ]
        choices = ["Growing", "Losing", "Shrinking", "Broadening"]
        out["segment"] = np.select(conditions, choices, default="Stagnant")
        self.segment_df = out
        return out

    # ------------------------------------------------------------------ #
    # 9. Apply cluster growth to groups
    # ------------------------------------------------------------------ #
    def apply_forecasts(self) -> pd.DataFrame:
        """
        Build the output frame: actual rows for every group, forecast rows for the
        eligible ones.

        Each eligible group's latest actual values are scaled by its cluster's
        cumulative growth factors. `total_balance` is recomputed as noa x ticket so
        the three columns stay internally consistent.

        Interval caveat, stated plainly: the bounds are the CLUSTER's uncertainty
        imposed on the group, not group-specific uncertainty, and the balance band
        multiplies two bounds together so it is deliberately conservative
        (wider than a proper joint interval).

        Optimism: where `config.optimism` is non-zero, `ticket_size` and
        `total_balance` carry the overlay, and `ticket_size_neutral` /
        `total_balance_neutral` carry the model's unaltered view. `total_noa` is
        identical either way. The `optimism` column records the setting used, so a
        consumer of this frame never has to guess whether judgement was applied.
        """
        cfg = self.config

        hist = self.raw[
            ["as_of_dt", "group_id", "total_noa", "ticket_size", "total_balance"]
        ].copy()
        hist["type"] = "Actual"
        for c in ("total_noa", "ticket_size", "total_balance"):
            hist[f"{c}_lower"] = hist[c]
            hist[f"{c}_upper"] = hist[c]

        factors = self.future_factors
        if factors is None or factors.empty:
            raise RuntimeError("No future factors. Run forecast_future() first.")

        wide = factors.pivot_table(
            index=["cluster", "as_of_dt"], columns="metric",
            values=["cum_factor", "cum_factor_lower", "cum_factor_upper",
                    "cum_factor_neutral"],
        )
        wide.columns = [f"{a}__{b}" for a, b in wide.columns]
        wide = wide.reset_index()

        elig_ids = self.group_meta.loc[self.group_meta["eligible"], "group_id"]
        base = self.panel[
            (self.panel["as_of_dt"] == self.latest_date)
            & (self.panel["group_id"].isin(elig_ids))
        ][["group_id", "total_noa", "ticket_size"]].copy()
        base = base.merge(
            self.cluster_assignments[["group_id", "cluster"]], on="group_id", how="inner"
        )

        proj = base.merge(wide, on="cluster", how="inner")
        for metric, prefix in (("total_noa", "total_noa"), ("ticket_size", "ticket_size")):
            proj[f"{prefix}_point"] = proj[metric] * proj[f"cum_factor__{metric}"]
            proj[f"{prefix}_lo"] = proj[metric] * proj[f"cum_factor_lower__{metric}"]
            proj[f"{prefix}_hi"] = proj[metric] * proj[f"cum_factor_upper__{metric}"]

        fc = pd.DataFrame(
            {
                "as_of_dt": proj["as_of_dt"],
                "group_id": proj["group_id"],
                "total_noa": proj["total_noa_point"],
                "ticket_size": proj["ticket_size_point"],
                "total_noa_lower": proj["total_noa_lo"],
                "total_noa_upper": proj["total_noa_hi"],
                "ticket_size_lower": proj["ticket_size_lo"],
                "ticket_size_upper": proj["ticket_size_hi"],
            }
        )
        fc["total_balance"] = fc["total_noa"] * fc["ticket_size"]
        fc["total_balance_lower"] = fc["total_noa_lower"] * fc["ticket_size_lower"]
        fc["total_balance_upper"] = fc["total_noa_upper"] * fc["ticket_size_upper"]
        # What the model said before any judgement overlay. Kept alongside so a reader
        # can always separate the model's view from the optimism layered on top.
        fc["ticket_size_neutral"] = (
            proj["ticket_size"] * proj["cum_factor_neutral__ticket_size"]
        ).to_numpy()
        fc["total_balance_neutral"] = fc["total_noa"] * fc["ticket_size_neutral"]
        fc["optimism"] = float(cfg.optimism)
        fc["type"] = "Forecast"

        hist["ticket_size_neutral"] = hist["ticket_size"]
        hist["total_balance_neutral"] = hist["total_balance"]
        hist["optimism"] = 0.0
        # Actual rows carry the REPORTED figures, artefact months included, so this
        # frame still reconciles to what the business published. The flag says which
        # months the model was not allowed to learn from.
        hist["anomaly_month"] = hist["as_of_dt"].isin(self.anomaly_dates)
        fc["anomaly_month"] = False

        combined = pd.concat([hist, fc], ignore_index=True)

        if self.segment_df is None:
            self.assign_segment()
        combined = (
            combined
            .merge(self.cluster_assignments[["group_id", "cluster", "thin_history", "assignment"]],
                   on="group_id", how="left")
            .merge(self.segment_df[["group_id", "segment"]], on="group_id", how="left")
            .merge(self.group_meta[["group_id", "eligible", "run_length", "has_gap"]],
                   on="group_id", how="left")
            .merge(self.group_attrs, on="group_id", how="left")
        )
        combined["segment"] = combined["segment"].fillna("Stagnant")
        combined["thin_history"] = combined["thin_history"].fillna(False).astype(bool)
        combined["eligible"] = combined["eligible"].fillna(False).astype(bool)
        combined["has_gap"] = combined["has_gap"].fillna(False).astype(bool)
        combined["assignment"] = combined["assignment"].fillna("unassigned")
        combined["run_length"] = combined["run_length"].fillna(0).astype("int16")
        # Low-cardinality label columns as category: at ~900k rows these are
        # otherwise hundreds of MB of duplicated Python strings. group_id is
        # deliberately left as-is, because downstream merges on a categorical key
        # are a common source of surprise.
        for c in ("cluster", "type", "segment", "assignment"):
            combined[c] = combined[c].astype("category")

        cols = [
            "as_of_dt", "group_id", "total_noa", "ticket_size", "total_balance",
            "cluster", "type",
            "total_noa_lower", "total_noa_upper",
            "ticket_size_lower", "ticket_size_upper",
            "total_balance_lower", "total_balance_upper",
            "ticket_size_neutral", "total_balance_neutral", "optimism", "anomaly_month",
            "segment", "eligible", "thin_history", "assignment", "run_length", "has_gap",
        ] + self.cat_cols
        self.forecast_df = combined[cols].sort_values(
            ["group_id", "as_of_dt"]
        ).reset_index(drop=True)
        self._log(
            "  output: %s rows (%s actual, %s forecast) across %s groups",
            f"{len(self.forecast_df):,}",
            f"{int((self.forecast_df['type'] == 'Actual').sum()):,}",
            f"{int((self.forecast_df['type'] == 'Forecast').sum()):,}",
            f"{self.forecast_df['group_id'].nunique():,}",
        )
        return self.forecast_df

    # ------------------------------------------------------------------ #
    # 10. Group-level validation
    # ------------------------------------------------------------------ #
    def validate_group_level(self) -> pd.DataFrame:
        """
        Score the step that actually produces the deliverable.

        `test_df` measures CLUSTER accuracy. But the output is a GROUP forecast,
        produced by applying one cluster growth path to every member. Cluster-level
        MAPE can look excellent while individual group forecasts are poor, because
        the errors cancel inside the aggregate.

        This replays the exact production logic across the holdout window --
        take each group's actual value at train-end, scale it by the cluster's
        cumulative factors implied by the holdout predictions, compare to the
        group's real value -- and reports the error DISTRIBUTION across groups.
        The median and p90 are the numbers to look at; the mean will flatter you.
        """
        if not self.registry:
            raise RuntimeError("Run backtest_and_select() and evaluate_holdout() first.")

        split = self.split_index
        train_end = self.all_dates[split - 1]
        rows: List[Dict[str, Any]] = []

        # cluster cumulative factors implied by the holdout predictions
        fac: Dict[Tuple[str, str], pd.Series] = {}
        for (cid, metric), reg in self.registry.items():
            if "holdout_point" not in reg:
                continue
            base = reg["train_end_value"]
            if abs(base) < 1e-12:
                continue
            fac[(cid, metric)] = pd.Series(
                np.asarray(reg["holdout_point"], dtype=float) / base,
                index=reg["holdout_index"],
            )
        if not fac:
            return pd.DataFrame()

        assign = self.cluster_assignments[["group_id", "cluster"]]
        base_vals = self.panel[self.panel["as_of_dt"] == train_end][
            ["group_id", "total_noa", "ticket_size"]
        ].rename(columns={"total_noa": "base_noa", "ticket_size": "base_ticket"})
        base_vals = base_vals.merge(assign, on="group_id", how="inner")

        actuals = self.panel[self.panel["as_of_dt"] > train_end][
            ["group_id", "as_of_dt", "total_noa", "ticket_size"]
        ]
        joined = actuals.merge(base_vals, on="group_id", how="inner")

        for metric, base_col in (("total_noa", "base_noa"), ("ticket_size", "base_ticket")):
            frames = []
            for (cid, m), series in fac.items():
                if m != metric:
                    continue
                f = series.rename("cum").reset_index()
                f.columns = ["as_of_dt", "cum"]
                f["cluster"] = cid
                frames.append(f)
            if not frames:
                continue
            fdf = pd.concat(frames, ignore_index=True)
            j = joined.merge(fdf, on=["cluster", "as_of_dt"], how="inner")
            if j.empty:
                continue
            pred = j[base_col].to_numpy(dtype=float) * j["cum"].to_numpy(dtype=float)
            act = j[metric].to_numpy(dtype=float)
            ape = np.abs(act - pred) / _safe_denominator(act) * 100.0
            j = j.assign(_ape=ape, _pred=pred, _act=act)

            for dt, sub in j.groupby("as_of_dt", observed=True):
                step = int(
                    (dt.year * 12 + dt.month) - (train_end.year * 12 + train_end.month)
                )
                a = sub["_ape"].to_numpy()
                rows.append(
                    dict(
                        metric=metric, as_of_dt=dt, horizon_step=step,
                        n_groups=int(len(sub)),
                        group_median_APE=float(np.median(a)),
                        group_p75_APE=float(np.percentile(a, 75)),
                        group_p90_APE=float(np.percentile(a, 90)),
                        group_mean_APE=float(np.mean(a)),
                        aggregate_APE=float(
                            abs(sub["_act"].sum() - sub["_pred"].sum())
                            / max(abs(sub["_act"].sum()), 1e-8) * 100.0
                        ),
                    )
                )

        self.group_validation_df = pd.DataFrame(rows).sort_values(
            ["metric", "horizon_step"]
        ).reset_index(drop=True)

        if not self.group_validation_df.empty:
            for metric, sub in self.group_validation_df.groupby("metric", observed=True):
                self._log(
                    "  group-level %-12s median APE %5.2f%% | p90 %6.2f%% | aggregate %5.2f%%",
                    metric,
                    sub["group_median_APE"].mean(),
                    sub["group_p90_APE"].mean(),
                    sub["aggregate_APE"].mean(),
                )
        return self.group_validation_df

    # ------------------------------------------------------------------ #
    # 10b. Group-level test predictions (for the combined output)
    # ------------------------------------------------------------------ #
    def build_group_test(self) -> pd.DataFrame:
        """
        Per-group predictions on the held-back months, in the SAME schema as
        forecast_df, labelled type='Test'.

        These are what the model would have delivered for the holdout window under
        the exact production logic: each unit's actual value at train-end scaled by
        its cluster's holdout cumulative factor. They overlap in month with the
        Actual rows, which is what lets a chart draw actual-vs-test and score it.

        Bounds and *_neutral columns are set to the point value and optimism to 0:
        the holdout is scored before any optimism overlay (optimism touches only the
        future forecast), so a Test row carries no band and no judgement.
        """
        if self.forecast_df is None:
            raise RuntimeError("Run apply_forecasts() first.")
        if not self.registry or self.split_index is None:
            self.group_test_df = self.forecast_df.iloc[0:0].copy()
            return self.group_test_df

        split = self.split_index
        train_end = self.all_dates[split - 1]

        # cluster cumulative factors implied by the holdout point predictions
        fac: Dict[Tuple[str, str], pd.Series] = {}
        for (cid, metric), reg in self.registry.items():
            if "holdout_point" not in reg:
                continue
            base = reg.get("train_end_value")
            if not base or abs(base) < 1e-12:
                continue
            fac[(cid, metric)] = pd.Series(
                np.asarray(reg["holdout_point"], dtype=float) / base,
                index=reg["holdout_index"],
            )
        if not fac:
            self.group_test_df = self.forecast_df.iloc[0:0].copy()
            return self.group_test_df

        base_vals = (
            self.panel[self.panel["as_of_dt"] == train_end][
                ["group_id", "total_noa", "ticket_size"]
            ]
            .rename(columns={"total_noa": "base_noa", "ticket_size": "base_ticket"})
            .merge(self.cluster_assignments[["group_id", "cluster"]], on="group_id", how="inner")
        )

        def _cum_frame(metric: str) -> pd.DataFrame:
            frames = []
            for (cid, m), series in fac.items():
                if m != metric:
                    continue
                f = series.rename(f"cum_{metric}").reset_index()
                f.columns = ["as_of_dt", f"cum_{metric}"]
                f["cluster"] = cid
                frames.append(f)
            return pd.concat(frames, ignore_index=True) if frames else pd.DataFrame()

        cum_noa, cum_tkt = _cum_frame("total_noa"), _cum_frame("ticket_size")
        if cum_noa.empty or cum_tkt.empty:
            self.group_test_df = self.forecast_df.iloc[0:0].copy()
            return self.group_test_df

        proj = (
            base_vals
            .merge(cum_noa, on="cluster", how="inner")
            .merge(cum_tkt, on=["cluster", "as_of_dt"], how="inner")
        )
        proj["total_noa"] = proj["base_noa"] * proj["cum_total_noa"]
        proj["ticket_size"] = proj["base_ticket"] * proj["cum_ticket_size"]
        proj["total_balance"] = proj["total_noa"] * proj["ticket_size"]

        test = proj[["as_of_dt", "group_id", "total_noa", "ticket_size", "total_balance"]].copy()
        test["type"] = "Test"
        for c in ("total_noa", "ticket_size", "total_balance"):
            test[f"{c}_lower"] = test[c]
            test[f"{c}_upper"] = test[c]
        test["ticket_size_neutral"] = test["ticket_size"]
        test["total_balance_neutral"] = test["total_balance"]
        test["optimism"] = 0.0
        test["anomaly_month"] = test["as_of_dt"].isin(self.anomaly_dates)

        # attach the same descriptor columns forecast_df carries
        test = (
            test
            .merge(self.cluster_assignments[["group_id", "cluster", "thin_history", "assignment"]],
                   on="group_id", how="left")
            .merge(self.segment_df[["group_id", "segment"]], on="group_id", how="left")
            .merge(self.group_meta[["group_id", "eligible", "run_length", "has_gap"]],
                   on="group_id", how="left")
            .merge(self.group_attrs, on="group_id", how="left")
        )
        test["segment"] = test["segment"].fillna("Stagnant")
        test["thin_history"] = test["thin_history"].fillna(False).astype(bool)
        test["eligible"] = test["eligible"].fillna(False).astype(bool)
        test["has_gap"] = test["has_gap"].fillna(False).astype(bool)
        test["assignment"] = test["assignment"].fillna("unassigned")
        test["run_length"] = test["run_length"].fillna(0).astype("int16")

        self.group_test_df = test[list(self.forecast_df.columns)].reset_index(drop=True)
        self._log("  group-level test rows: %s across %s groups",
                  f"{len(self.group_test_df):,}", f"{self.group_test_df['group_id'].nunique():,}")
        return self.group_test_df

    def build_combined(self) -> pd.DataFrame:
        """forecast_df (Actual + Forecast) plus the group-level Test rows, one frame."""
        if self.forecast_df is None:
            raise RuntimeError("Run apply_forecasts() first.")
        if self.group_test_df is None:
            self.build_group_test()
        parts = [self.forecast_df]
        if self.group_test_df is not None and not self.group_test_df.empty:
            parts.append(self.group_test_df)
        combined = pd.concat(parts, ignore_index=True)
        combined["type"] = pd.Categorical(
            combined["type"].astype(str),
            categories=["Actual", "Test", "Forecast"], ordered=True,
        )
        self.combined_df = combined.sort_values(
            ["group_id", "type", "as_of_dt"]
        ).reset_index(drop=True)
        return self.combined_df

    # ------------------------------------------------------------------ #
    # Orchestrator
    # ------------------------------------------------------------------ #
    def run(self) -> pd.DataFrame:
        """
        Execute the whole pipeline in the correct order.

        Returns
        -------
        pd.DataFrame
            ONE group-level frame with a `type` column (Actual / Forecast / Test)
            and all original columns. The pieces remain available as attributes:
              .forecast_df     Actual + Forecast rows (what run() used to return first)
              .test_df         CLUSTER-level actual-vs-predicted with model + errors
              .group_test_df   the group-level Test rows in this frame
              .combined_df     same object this returns
        """
        import time

        t0 = time.time()
        if abs(float(self.config.optimism)) > 1e-12:
            self._log(
                "NOTE: optimism = %+.2f is in effect. Ticket size is shifted by %+.2f x one\n"
                "      standard deviation of the forecast distribution. NOA is unaffected.\n"
                "      The unadjusted figures are kept as ticket_size_neutral / "
                "total_balance_neutral.",
                self.config.optimism, self.config.optimism,
            )
        steps = [
            ("1/8 preprocess", self.preprocess),
            ("2/8 cluster", self.cluster),
            ("3/8 cluster series", self.build_cluster_series),
            ("4/8 backtest + select", self.backtest_and_select),
            ("5/8 holdout evaluation", self.evaluate_holdout),
            ("6/8 future forecast", self.forecast_future),
            ("7/8 apply to groups", self.apply_forecasts),
            ("8/8 group-level validation", self.validate_group_level),
            ("+ group-level test rows", self.build_group_test),
        ]
        for label, fn in steps:
            t = time.time()
            self._log("[%s]", label)
            fn()
            self._log("  done in %.1fs", time.time() - t)
        combined = self.build_combined()
        self._log(
            "Combined output: %s rows (%s actual, %s test, %s forecast)",
            f"{len(combined):,}",
            f"{int((combined['type'] == 'Actual').sum()):,}",
            f"{int((combined['type'] == 'Test').sum()):,}",
            f"{int((combined['type'] == 'Forecast').sum()):,}",
        )
        self._log("Total %.1fs", time.time() - t0)
        return combined

    # ------------------------------------------------------------------ #
    # Reporting helpers (optional, not part of the required outputs)
    # ------------------------------------------------------------------ #
    def summary(self) -> pd.DataFrame:
        """Compact per cluster x metric view: winner, why, and how it scored."""
        if self.selection_df is None:
            raise RuntimeError("Run backtest_and_select() first.")
        out = self.selection_df.copy()
        if self.test_df is not None and not self.test_df.empty:
            h = (
                self.test_df.groupby(["cluster", "metric"], observed=True)
                .agg(
                    holdout_MAE=("holdout_MAE", "first"),
                    holdout_RMSE=("holdout_RMSE", "first"),
                    holdout_MAPE=("holdout_MAPE", "first"),
                    holdout_MDAPE=("holdout_MDAPE", "first"),
                    holdout_MASE=("holdout_MASE", "first"),
                )
                .reset_index()
            )
            out = out.merge(h, on=["cluster", "metric"], how="left")
        return out

    # ------------------------------------------------------------------ #
    # Portfolio-level view
    # ------------------------------------------------------------------ #
    def overall_series(self, population: str = "eligible") -> pd.DataFrame:
        """
        Actual, holdout prediction and future forecast for the whole book, on one
        timeline. Returns the numbers so they can be charted here or exported.

        The holdout line is built the same way the production forecast is: each
        group's actual at train-end is scaled by its cluster's cumulative factor,
        then summed. It is therefore what the model would actually have delivered
        for those nine months, not the cluster-level series it was scored on.

        Parameters
        ----------
        population : {'eligible', 'all'}
            'eligible' (default) keeps only groups present in the latest month, so
            actual, test and forecast all describe the same set of groups and the
            lines join cleanly. 'all' includes groups that closed before the latest
            month, which shows real attrition in the history but leaves a step down
            where the forecast begins, because those groups have nothing to forecast.

        Returns
        -------
        pd.DataFrame
            One row per (as_of_dt, type), where `type` is Actual, Test or Forecast:

                as_of_dt, type, total_noa, ticket_size, total_balance,
                total_noa_lower/upper, ticket_size_lower/upper,
                total_balance_lower/upper

            Bounds are populated on Forecast rows only. `type` uses the same three
            labels throughout, so the frame pivots or filters straight into a chart.
        """
        if self.forecast_df is None:
            raise RuntimeError("Run the pipeline first.")
        if population not in {"eligible", "all"}:
            raise ValueError("population must be 'eligible' or 'all'.")

        ids = (
            set(self.group_meta.loc[self.group_meta["eligible"], "group_id"])
            if population == "eligible"
            else set(self.group_meta["group_id"])
        )
        pan = self.panel[self.panel["group_id"].isin(ids)]
        assign = self.cluster_assignments[["group_id", "cluster"]]

        def _aggregate(noa: pd.Series, bal: pd.Series, key: pd.Series) -> pd.DataFrame:
            out = pd.DataFrame({"as_of_dt": key, "noa": noa, "bal": bal})
            out = out.groupby("as_of_dt", observed=True)[["noa", "bal"]].sum()
            out["tkt"] = out["bal"] / out["noa"]
            return out

        # ---- actual ---------------------------------------------------- #
        actual = _aggregate(pan["total_noa"], pan["total_balance"], pan["as_of_dt"])

        # ---- holdout prediction, via the production application path ----- #
        test = pd.DataFrame()
        if self.split_index is not None and self.registry:
            train_end = self.all_dates[self.split_index - 1]
            base = (
                pan[pan["as_of_dt"] == train_end][["group_id", "total_noa", "ticket_size"]]
                .merge(assign, on="group_id", how="inner")
            )
            rows = []
            for (cid, metric), reg in self.registry.items():
                if "holdout_point" not in reg:
                    continue
                anchor = reg.get("train_end_value")
                if not anchor or abs(anchor) < 1e-12:
                    continue
                for dt, p in zip(reg["holdout_index"], reg["holdout_point"]):
                    rows.append({"cluster": cid, "as_of_dt": dt, "metric": metric,
                                 "cum": float(p) / float(anchor)})
            if rows and not base.empty:
                cum = (pd.DataFrame(rows)
                       .pivot_table(index=["cluster", "as_of_dt"], columns="metric", values="cum")
                       .reset_index())
                if {"total_noa", "ticket_size"} <= set(cum.columns):
                    # rename before the merge: `cum` and `base` both carry a
                    # total_noa column, and suffixed duplicates are easy to misread
                    proj = base.merge(
                        cum.rename(columns={"total_noa": "cum_noa", "ticket_size": "cum_tkt"}),
                        on="cluster", how="inner",
                    )
                    pn = proj["total_noa"] * proj["cum_noa"]
                    pt = proj["ticket_size"] * proj["cum_tkt"]
                    test = _aggregate(pn, pn * pt, proj["as_of_dt"])

        # ---- future forecast -------------------------------------------- #
        fc = pd.DataFrame()
        if self.future_factors is not None and not self.future_factors.empty:
            base_f = (
                pan[pan["as_of_dt"] == self.latest_date][["group_id", "total_noa", "ticket_size"]]
                .merge(assign, on="group_id", how="inner")
            )
            wide = self.future_factors.pivot_table(
                index=["cluster", "as_of_dt"], columns="metric",
                values=["cum_factor", "cum_factor_lower", "cum_factor_upper"],
            )
            wide.columns = [f"{a}__{b}" for a, b in wide.columns]
            wide = wide.reset_index()
            proj = base_f.merge(wide, on="cluster", how="inner")
            parts = {}
            for tag, suffix in (("", "cum_factor"), ("_lower", "cum_factor_lower"),
                                ("_upper", "cum_factor_upper")):
                pn = proj["total_noa"] * proj[f"{suffix}__total_noa"]
                pt = proj["ticket_size"] * proj[f"{suffix}__ticket_size"]
                parts[tag] = _aggregate(pn, pn * pt, proj["as_of_dt"])
            fc = parts[""]
            fc_lo, fc_hi = parts["_lower"], parts["_upper"]

        # ---- assemble: one row per (as_of_dt, type) ---------------------- #
        NAMES = {"noa": "total_noa", "tkt": "ticket_size", "bal": "total_balance"}
        METRICS3 = ["total_noa", "ticket_size", "total_balance"]

        def _block(frame, label, lo=None, hi=None):
            if frame is None or frame.empty:
                return None
            d = frame.rename(columns=NAMES).reset_index()
            d = d.rename(columns={d.columns[0]: "as_of_dt"})
            d["type"] = label
            for m in METRICS3:
                # bounds exist for the forecast only. Left as NaN elsewhere rather
                # than copied from the point value, so a chart of the band draws
                # nothing over history instead of a zero-width band that would read
                # as certainty.
                d[f"{m}_lower"] = lo.rename(columns=NAMES)[m].to_numpy() if lo is not None else np.nan
                d[f"{m}_upper"] = hi.rename(columns=NAMES)[m].to_numpy() if hi is not None else np.nan
            return d

        blocks = [_block(actual, "Actual"), _block(test, "Test")]
        if not fc.empty:
            blocks.append(_block(fc, "Forecast", fc_lo, fc_hi))
        out = pd.concat([b for b in blocks if b is not None], ignore_index=True)

        out["type"] = pd.Categorical(out["type"],
                                     categories=["Actual", "Test", "Forecast"], ordered=True)
        # Unlike forecast_df, the Actual rows here are the MODELLING basis: artefact
        # months carry their adjusted value, not the reported one, because this frame
        # exists to show what the model saw. The flag marks them.
        out["anomaly_month"] = out["as_of_dt"].isin(self.anomaly_dates) & (out["type"] == "Actual")
        cols = (["as_of_dt", "type"] + METRICS3
                + [f"{m}{s}" for m in METRICS3 for s in ("_lower", "_upper")]
                + ["anomaly_month"])
        return out[cols].sort_values(["type", "as_of_dt"]).reset_index(drop=True)

    def plot_overall(
        self,
        metrics: Sequence[str] = ("total_noa", "ticket_size", "total_balance"),
        population: str = "eligible",
        figsize: Tuple[float, float] = (13.0, 9.0),
        scale: Optional[Dict[str, float]] = None,
    ):
        """
        Chart the whole book: history, the model's holdout prediction, and the
        forecast with its range.

        The holdout line is drawn on months the model never saw, so the gap between
        it and the actual line is the honest read on recent accuracy. Note that this
        is the portfolio total: individual group errors are larger and partly cancel
        here (see `group_validation_df`).

        The forecast band is the sum of group-level bounds, which assumes every
        cluster misses in the same direction at once. It is therefore wider than a
        properly combined interval. Treat it as a conservative envelope.
        """
        import matplotlib.pyplot as plt
        import matplotlib.ticker as mticker

        data = self.overall_series(population=population)
        labels = {
            "total_noa": "Number of accounts",
            "ticket_size": "Average balance per account",
            "total_balance": "Total balance",
        }
        units = {1: "", 1e3: "thousands", 1e6: "millions", 1e9: "billions"}

        # Auto-scale each panel unless the caller fixed it. Raw deposit balances run
        # to 10-12 digits and unlabelled axis ticks that long are unreadable.
        if scale is None:
            scale = {}
            for metric in metrics:
                vals = data[metric].to_numpy(dtype=float)
                peak = np.nanmax(np.abs(vals)) if np.isfinite(vals).any() else 1.0
                scale[metric] = (
                    1e9 if peak >= 1e11 else
                    1e6 if peak >= 1e8 else
                    1e3 if peak >= 1e5 else 1.0
                )

        act = data[data["type"] == "Actual"].sort_values("as_of_dt")
        tst = data[data["type"] == "Test"].sort_values("as_of_dt")
        fcst = data[data["type"] == "Forecast"].sort_values("as_of_dt")

        fig, axes = plt.subplots(len(metrics), 1, figsize=figsize, squeeze=False)
        split_dt = self.all_dates[self.split_index - 1] if self.split_index else None

        for ax, metric in zip(axes[:, 0], metrics):
            div = scale.get(metric, 1.0)

            if split_dt is not None:
                ax.axvline(split_dt, color="#95a5a6", lw=1.0, ls=":")
            if self.latest_date is not None:
                ax.axvline(self.latest_date, color="#95a5a6", lw=1.0, ls=":")
            # Mark artefact months. The line shows their adjusted value, so without a
            # marker a reader would take a smoothed point for a reported one.
            for dt in self.anomaly_dates:
                ax.axvline(dt, color="#9E3B2E", lw=1.0, ls="-.", alpha=0.55)

            ax.plot(act["as_of_dt"], act[metric] / div, color="#14313D", lw=2.4, label="Actual")

            if not tst.empty:
                # join the test line to the last actual point before it starts
                joint = act[act["as_of_dt"] < tst["as_of_dt"].min()].tail(1)
                xs = list(joint["as_of_dt"]) + list(tst["as_of_dt"])
                ys = list(joint[metric] / div) + list(tst[metric] / div)
                ax.plot(xs, ys, color="#2E6E7E", lw=2.0, ls="--", marker="o", ms=3.5,
                        label="Prediction on held-back months")

            if not fcst.empty:
                last = act.tail(1)
                xs = list(last["as_of_dt"]) + list(fcst["as_of_dt"])
                ys = list(last[metric] / div) + list(fcst[metric] / div)
                lo = list(last[metric] / div) + list(fcst[f"{metric}_lower"] / div)
                hi = list(last[metric] / div) + list(fcst[f"{metric}_upper"] / div)
                ax.fill_between(xs, lo, hi, color="#D97A2B", alpha=0.15, label="Forecast range")
                ax.plot(xs, ys, color="#D97A2B", lw=2.4, ls="--", marker="o", ms=4,
                        label="Forecast")

            unit = units.get(div, f"per {div:,.0f}")
            ax.set_title(labels.get(metric, metric) + (f"  ({unit})" if unit else ""),
                         fontsize=12, loc="left", color="#14313D", pad=8)
            ax.grid(alpha=0.25)
            ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda v, _: f"{v:,.0f}"))
            for side in ("top", "right"):
                ax.spines[side].set_visible(False)

        axes[0, 0].legend(fontsize=9, frameon=False, ncol=4, loc="upper left")
        note = (f"Groups present in the latest month only ({population})."
                if population == "eligible" else "All groups, including those that closed.")
        note += "  Dotted lines mark the end of training and the last actual month."
        if len(self.anomaly_dates):
            note += ("  Dash-dotted red: artefact month, shown adjusted, excluded from "
                     "modelling (reported figure is in forecast_df).")
        fig.text(0.01, 0.005, note, fontsize=8.5, color="#5B6B72")
        fig.tight_layout(rect=(0, 0.02, 1, 1))
        return fig

    def plot_cluster(self, cluster_id: str, metric: str = "total_noa", ax=None):
        """History, holdout prediction and future forecast for one cluster x metric."""
        import matplotlib.pyplot as plt

        if ax is None:
            _, ax = plt.subplots(figsize=(12, 4))
        full = self._series_for(cluster_id, metric)
        ax.plot(full.index, full.to_numpy(), color="#2c3e50", lw=2, label="Actual")

        t = self.test_df[
            (self.test_df["cluster"] == cluster_id) & (self.test_df["metric"] == metric)
        ]
        if not t.empty:
            ax.plot(t["as_of_dt"], t["predicted"], color="#95a5a6",
                    ls="--", marker="o", ms=3, label="Holdout prediction")

        f = self.future_factors[
            (self.future_factors["cluster"] == cluster_id)
            & (self.future_factors["metric"] == metric)
        ]
        if not f.empty:
            ax.plot(f["as_of_dt"], f["predicted_value"], color="#e67e22",
                    ls="--", marker="o", ms=4, label="Forecast")
            ax.fill_between(f["as_of_dt"], f["lower_bound"], f["upper_bound"],
                            color="#e67e22", alpha=0.15, label="95% interval")

        reg = self.registry.get((cluster_id, metric), {})
        title = f"{cluster_id} | {metric} | {reg.get('model_type', '?')}"
        if reg.get("feb_event_applied"):
            title += " | Feb event"
        ax.set_title(title)
        ax.grid(alpha=0.3)
        ax.legend(fontsize=8)
        return ax
