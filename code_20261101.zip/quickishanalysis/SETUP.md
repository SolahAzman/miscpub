# quickishanalysis — setup guide (Windows, Anaconda Prompt)

Takes about 10 minutes the first time. You need **Anaconda or Miniconda** installed and an internet connection.
Every command below is typed in **Anaconda Prompt** (Start menu → *Anaconda Prompt*), not in a normal Command Prompt.

---

## Folder structure

```
D:\Claude_Workspace\local data analysis module\      ← project folder
│
├── quickishanalysis\              THE MODULE — only these four files
│   ├── quickishanalysis.py        the module: class Quickish + cleaning helpers
│   ├── quickishanalysis.yaml      settings; must stay beside the .py with the same name
│   ├── requirements.txt           packages to install (step 5)
│   └── SETUP.md                   this guide
│
├── notebooks\                     your notebooks (demo.ipynb is here)
├── data\                          input files (data\sample_data holds the demo data)
├── outputs\                       everything the module writes
│   ├── .qa_clean\                 cleaned data — SESSION ONLY, emptied at startup and on close
│   ├── .qa_tmp\                   DuckDB spill files
│   ├── .qa_answers\               your saved answers to prompts (kept)
│   ├── qa_pivots\                 explore() pages (deleted after 1 day)
│   ├── qa_charts\                 saved charts
│   ├── exports\                   export() files (by convention)
│   └── qa_prompt.md               to_markdown() prompt (overwritten each time)
│
└── plan\                          module plan + templates
```

The settings in `quickishanalysis.yaml` use paths relative to the `quickishanalysis\` folder, so `..` means the
project folder. That's how outputs land in `outputs\` and why `qa.load("data/...")` works from any notebook.

---

## Step 1 — Open Anaconda Prompt and check conda

```bat
conda --version
```

You need **conda 23.9 or newer** for the certificate setting in step 2. If it's older, update it (if the update
itself fails with an SSL error, use the fallback in step 2b first):

```bat
conda update -n base conda -y
```

---

## Step 2 — Prevent SSL certificate errors on the work laptop (once per laptop)

Work laptops often inspect HTTPS traffic with a company certificate, so conda and pip refuse to download
(`SSL: CERTIFICATE_VERIFY_FAILED`). Set both up once. The settings are saved in your Windows user profile and apply
to every environment.

**2a. pip:** trust the two Python package sites:

```bat
pip config set global.trusted-host "pypi.org files.pythonhosted.org"
pip config list
```

Expected: `global.trusted-host='pypi.org files.pythonhosted.org'`

> What this does: pip stops checking the certificate for those two sites only. That fixes the error, but it also
> means a tampered download from those sites wouldn't be detected. Recent pip (24.2+) on Python 3.10+ already
> trusts the Windows certificate store, where IT installs the company certificate, so this is often just a safety
> net. To undo: `pip config unset global.trusted-host`

**2b. conda:** use the Windows certificate store (the safe equivalent; conda 23.9+):

```bat
conda config --set ssl_verify truststore
conda config --show ssl_verify
```

Expected: `ssl_verify: truststore`

> **Only if step 4 still fails with an SSL error**, switch checking off for the install, then switch it back:
> ```bat
> conda config --set ssl_verify false
> REM ... run step 4 ...
> conda config --set ssl_verify truststore
> ```
> If IT gave you a certificate file (`.pem` / `.crt`), use it instead:
> `conda config --set ssl_verify "C:\path\to\company-root.pem"`

**2c. Only if your office requires a proxy** (ask IT for the address):

```bat
pip config set global.proxy http://proxy-host:port
conda config --set proxy_servers.http  http://proxy-host:port
conda config --set proxy_servers.https http://proxy-host:port
```

---

## Step 3 — Create the project folders

```bat
cd /d "D:\Claude_Workspace\local data analysis module"

if not exist quickishanalysis mkdir quickishanalysis
if not exist notebooks        mkdir notebooks
if not exist data             mkdir data
if not exist outputs\exports  mkdir outputs\exports
if not exist plan             mkdir plan
```

Put the four module files in `quickishanalysis\` (already done if you received the folder ready-made) and check:

```bat
dir /b quickishanalysis
```

Expected: `quickishanalysis.py  quickishanalysis.yaml  requirements.txt  SETUP.md`

The `outputs\.qa_*` subfolders are created automatically the first time the module starts.

---

## Step 4 — Create and activate the conda environment

```bat
conda create -n quickish python=3.12 pip -y
conda activate quickish
```

The prompt now starts with `(quickish)`. **Every remaining step must run in this environment.**
After closing the window: reopen Anaconda Prompt and run `conda activate quickish` again.

> **Licensing note for company laptops:** Anaconda's default package channel requires a paid licence at larger
> organisations. If your company doesn't have one (ask IT), create the environment from the free conda-forge
> channel instead:
> ```bat
> conda create -n quickish -c conda-forge --override-channels python=3.12 pip -y
> ```
> Everything after this step installs from PyPI with pip, so it's unaffected.

---

## Step 5 — Install the packages

```bat
cd /d "D:\Claude_Workspace\local data analysis module\quickishanalysis"
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

This takes a few minutes and ends with `Successfully installed ...`.

| Group | Packages |
|---|---|
| Core | duckdb, pandas, pyarrow, fastparquet, pyyaml, plotly, openpyxl, xlrd, pyxlsb |
| Optional | polars (faster reading), pivottablejs (`explore()`), pyperclip (prompt → clipboard) |
| Notebook | ipykernel, nbformat, notebook |

---

## Step 6 — Register the Jupyter kernel

```bat
python -m ipykernel install --user --name quickishanalysis --display-name "Python (quickishanalysis)"
```

Notebooks (Jupyter or VS Code) can now select **Python (quickishanalysis)**, which runs in this environment.

---

## Step 7 — Check the module works

One line, still in the `quickishanalysis` folder with `(quickish)` active:

```bat
python -c "from quickishanalysis import Quickish; qa = Quickish.startup(); print(qa.sql('select 42 as ok')); qa.close()"
```

Expected: a few `INFO` lines, then a small table with `ok` and `42`.

---

## Step 8 — Open the demo notebook

**Jupyter in the browser:**

```bat
cd /d "D:\Claude_Workspace\local data analysis module\notebooks"
jupyter notebook demo.ipynb
```

Then **Kernel → Change kernel → Python (quickishanalysis)**, and **Run → Run All Cells**.

**VS Code:** open the project folder, open `notebooks\demo.ipynb`, click **Select Kernel → Jupyter Kernel →
Python (quickishanalysis)**, then **Run All**.

The demo reads `data\sample_data\`. If that folder is missing, the load cells will fail.

---

## Using the module in your own notebooks

The module isn't installed into the environment, so each notebook tells Python where to find it.
First cell of every notebook:

```python
import sys
sys.path.insert(0, r"D:\Claude_Workspace\local data analysis module\quickishanalysis")

import pandas as pd
from quickishanalysis import Quickish

qa = Quickish.startup()
```

* Keep the `r` before the path; without it, backslashes such as `\t` or `\n` are read as special characters.
* `insert(0, ...)` rather than `append(...)`, so this folder wins over any other copy Python might find.
* Don't name a variable `dir`: it replaces Python's built-in `dir()` for the rest of the notebook.
* If you move the module folder, update this line in your notebooks.

Paths you give to `qa.load()` / `qa.export()` are relative to the project folder (`"data/..."`,
`"outputs/exports/..."`), or use full paths like `r"D:\exports\sales.csv"`.

**One notebook at a time:** starting or closing a second session clears `outputs\.qa_clean`, which breaks the
other notebook's datasets.

**Every day:**

```bat
conda activate quickish
cd /d "D:\Claude_Workspace\local data analysis module\notebooks"
jupyter notebook
```

(VS Code: just pick the *Python (quickishanalysis)* kernel.)

**After editing `quickishanalysis.py`:** restart the notebook kernel to load the new code, then rerun step 7 to check
nothing is broken.

---

## Troubleshooting

| Symptom | Fix |
|---|---|
| `'conda' is not recognized` | You're in a normal Command Prompt. Use **Anaconda Prompt**. |
| `CERTIFICATE_VERIFY_FAILED` during `conda create` | Step 2b; if it persists, the temporary `ssl_verify false` fallback. |
| `CERTIFICATE_VERIFY_FAILED` / `SSLError` during `pip install` | `pip config list` must show the trusted-host line (step 2a). Behind a proxy also do step 2c. |
| `ProxyError` / timeouts | Step 2c with the proxy address from IT. |
| `ModuleNotFoundError: quickishanalysis` | The `sys.path.insert` line is missing or points to the wrong folder. It must be the folder that **contains** `quickishanalysis.py`. |
| `ModuleNotFoundError: duckdb` (or pandas, …) | Wrong kernel: select *Python (quickishanalysis)*. Or step 5 ran outside the `quickish` environment. |
| `FileNotFoundError: Config file not found` | `quickishanalysis.yaml` was moved or renamed. It must sit beside the `.py` with the same name. |
| Kernel missing in VS Code | Re-run step 6, then restart VS Code. |
| `explore()` shows an empty frame | pivottablejs loads its JavaScript from the internet; a blocked CDN shows a blank frame. The HTML file is still saved in `outputs\qa_pivots`. |
| `PermissionError` when saving | The file is open in Excel. Close it and rerun. |
| Second notebook says *file not found* on a dataset | One notebook at a time (see above). Reload the dataset in the notebook you're using. |

---

## Update or remove

```bat
conda activate quickish
cd /d "D:\Claude_Workspace\local data analysis module\quickishanalysis"
python -m pip install -U -r requirements.txt
```

Remove everything:

```bat
conda deactivate
conda env remove -n quickish -y
jupyter kernelspec uninstall quickishanalysis -y
pip config unset global.trusted-host
```

---

## Known issues

* **fastparquet in pandas 3:** `export()` writes Parquet with `engine="fastparquet"` as specified. pandas 3 marks
  that engine as deprecated. It works today; when pandas removes it, `export()` will need `engine="pyarrow"`
  (same GZIP output).
* Tested with Python 3.13 (Linux) and 3.14 (your PC, earlier setup), DuckDB 2.0, pandas 3.1, pyarrow 26,
  polars 2.1. Python 3.12 in the conda environment uses the same package versions.
