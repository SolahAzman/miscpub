"""quickishanalysis — fast day-to-day data analysis on an office laptop.

Typical notebook session::

    from quickishanalysis import Quickish
    qa = Quickish.startup()                       # reads quickishanalysis.yaml beside this file
    qa.load("sales", "raw/monthly/", pattern="sales_*.csv", to_int=["qty"])
    qa.sql("select country, sum(amount) from sales group by all")
    qa.pivot("sales", index="store", values="amount")
    qa.explore("sales")
    qa.to_markdown("sales", note="why are March totals high?")
    qa.close()

Design (see quickishanalysis_module_plan.xlsx / .txt):
* load() reads raw files with pandas in chunks, applies ONLY the cleaning you name, and writes one
  session-only Parquet per dataset. Everything afterwards is DuckDB SQL returned as pandas.
* Cleaned data lives in io.clean_dir and is deleted at startup and on close()/exit — one notebook
  at a time (R13).
"""
from __future__ import annotations

import ast
import atexit
import datetime as _dt
import functools
import hashlib
import inspect
import json
import logging
import math
import os
import re
import sys
import time
from pathlib import Path
from typing import Any, Callable, Iterator

import duckdb
import numpy as np
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
import yaml

__all__ = [
    "Quickish", "ReaderChainError", "ProbeCancelled",
    "normalize_columns", "to_int", "to_float", "to_str", "to_date", "str_operation", "drop_empty",
]
__version__ = "0.1.0"

log = logging.getLogger("quickishanalysis")
if not log.handlers:
    _h = logging.StreamHandler(sys.stdout)
    _h.setFormatter(logging.Formatter("%(levelname)s %(message)s"))
    log.addHandler(_h)
    log.propagate = False
    log.setLevel(logging.INFO)


# =====================================================================================
# Exceptions
# =====================================================================================
class ReaderChainError(RuntimeError):
    """Every reader failed for a file. ``attempts`` lists (reader, error)."""

    def __init__(self, path, attempts: list[tuple[str, str]]):
        self.path, self.attempts = path, attempts
        lines = "\n".join(f"  - {r}: {e}" for r, e in attempts)
        super().__init__(f"No reader could read {path}:\n{lines}")


class ProbeCancelled(Exception):
    """The user typed q at a prompt; nothing was run or written."""


class _ReaderFailed(Exception):
    """Internal: the reader (not the cleaning) raised while yielding a chunk."""


# =====================================================================================
# Config
# =====================================================================================
DEFAULTS: dict[str, dict[str, Any]] = {
    "meta": {"version": 1},
    "engine": {"database": ":memory:", "memory_limit": "3GB", "threads": 4, "temp_directory": ".qa_tmp"},
    "io": {"data_dir": ".", "clean_dir": ".qa_clean", "answers_dir": ".qa_answers", "chunk_rows": 500_000,
           "whole_read_max_mb": 500, "output_max_age_days": 1},
    "limits": {"confirm_rows_above": 1_000_000},
    "describe": {"sample_rows": 5, "max_unique_values": 20, "max_string_length": 60,
                 "mask_strings": False, "prompt_path": "qa_prompt.md"},
    "explore": {"max_rows": 100_000, "output_dir": "qa_pivots"},
    "chart": {"template": "plotly_white", "export_dir": "qa_charts"},
    "clean": {"normalize": True,
              "date_formats": ["%Y%m%d", "%d%m%Y", "%Y%j", "%Y-%m-%d", "%d/%m/%Y", "%d.%m.%Y",
                               "%Y-%m-%d %H:%M:%S", "excel"]},
    "probe": {"enabled": True},
    "logging": {"level": "INFO"},
}


def _read_yaml(path: Path) -> dict:
    """Read a YAML file into a dict (empty file → {})."""
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Config file not found: {path}")
    with open(path, encoding="utf-8") as fh:
        data = yaml.safe_load(fh)
    if data is None:
        return {}
    if not isinstance(data, dict):
        raise ValueError(f"{path}: top level must be a mapping, got {type(data).__name__}")
    return data


def _validate_config(cfg: dict) -> dict:
    """Apply DEFAULTS and type-check; collect every problem into one ValueError."""
    out = {sec: dict(vals) for sec, vals in DEFAULTS.items()}
    problems: list[str] = []
    for sec, vals in (cfg or {}).items():
        if sec not in out:
            problems.append(f"unknown section '{sec}'")
            continue
        if not isinstance(vals, dict):
            problems.append(f"section '{sec}' must be a mapping")
            continue
        for k, v in vals.items():
            if k not in out[sec]:
                problems.append(f"unknown key '{sec}.{k}'")
                continue
            default = DEFAULTS[sec][k]
            if isinstance(default, bool) and not isinstance(v, bool):
                problems.append(f"{sec}.{k} must be true/false")
            elif isinstance(default, int) and not isinstance(default, bool) and (not isinstance(v, int) or isinstance(v, bool)):
                problems.append(f"{sec}.{k} must be an integer")
            elif isinstance(default, str) and not isinstance(v, str):
                problems.append(f"{sec}.{k} must be text")
            elif isinstance(default, list) and not (isinstance(v, list) and all(isinstance(x, str) for x in v)):
                problems.append(f"{sec}.{k} must be a list of text")
            out[sec][k] = v
    rules = [
        (out["meta"]["version"] == 1, "meta.version must be 1"),
        (isinstance(out["engine"]["threads"], int) and out["engine"]["threads"] >= 1, "engine.threads must be ≥ 1"),
        (isinstance(out["io"]["chunk_rows"], int) and out["io"]["chunk_rows"] >= 10_000, "io.chunk_rows must be ≥ 10000"),
        (isinstance(out["io"]["whole_read_max_mb"], int) and out["io"]["whole_read_max_mb"] >= 0, "io.whole_read_max_mb must be ≥ 0"),
        (isinstance(out["io"]["output_max_age_days"], int) and out["io"]["output_max_age_days"] >= 0, "io.output_max_age_days must be ≥ 0"),
        (isinstance(out["limits"]["confirm_rows_above"], int) and out["limits"]["confirm_rows_above"] > 0, "limits.confirm_rows_above must be > 0"),
        (isinstance(out["explore"]["max_rows"], int) and out["explore"]["max_rows"] > 0, "explore.max_rows must be > 0"),
        (str(out["logging"]["level"]).upper() in {"DEBUG", "INFO", "WARNING", "ERROR"}, "logging.level must be DEBUG/INFO/WARNING/ERROR"),
    ]
    problems += [msg for ok, msg in rules if not ok and msg not in problems]
    if problems:
        raise ValueError("Invalid config:\n  - " + "\n  - ".join(dict.fromkeys(problems)))
    return out


# =====================================================================================
# Notebook interaction: _in_notebook, _ask, _call_string, _probe
# =====================================================================================
def _in_notebook() -> bool:
    """True inside a Jupyter kernel that can take input() (False in scripts, pytest, nbconvert)."""
    try:
        from IPython import get_ipython  # type: ignore
    except Exception:
        return False
    ip = get_ipython()
    if ip is None or "IPKernelApp" not in getattr(ip, "config", {}):
        return False
    kernel = getattr(ip, "kernel", None)
    return bool(getattr(kernel, "_allow_stdin", True))


def _ask(label: str, description: str = "", choices: list | None = None, default: Any = None,
         required: bool = False, multi: bool = False, validator: Callable | None = None) -> Any:
    """One prompt: show description, choices and default; validate; 'q' cancels."""
    header = f"{label}: {description}" if description else label
    print(header)
    if choices:
        for i, c in enumerate(choices, start=1):
            print(f"   {i:>2}  {c}")
    hint = []
    if default is not None:
        hint.append(f"default {default!r}")
    if multi:
        hint.append("comma-separated numbers")
    hint.append("q to cancel")
    while True:
        raw = input(f"  > ({'; '.join(hint)}) ").strip()
        if raw.lower() == "q":
            raise ProbeCancelled(f"cancelled at {label}")
        if raw == "":
            if default is not None or not required:
                return default
            print("  required — please enter a value")
            continue
        if choices and multi:
            try:
                idx = [int(x) for x in raw.split(",") if x.strip()]
                value = [choices[i - 1] for i in idx]
            except (ValueError, IndexError):
                print("  enter numbers from the list, e.g. 1,3")
                continue
        elif choices and raw.isdigit() and 1 <= int(raw) <= len(choices):
            value = choices[int(raw) - 1]
        else:
            try:
                value = ast.literal_eval(raw)
            except (ValueError, SyntaxError):
                value = raw
        if validator:
            err = validator(value)
            if err:
                print(f"  {err}")
                continue
        return value


def _call_string(func_name: str, kwargs: dict, defaults: dict | None = None, var_names: dict | None = None) -> str:
    """Render a call with keyword arguments as paste-ready Python."""
    parts = []
    for k, v in kwargs.items():
        if defaults is not None and k in defaults and defaults[k] is not inspect.Parameter.empty and _eq(defaults[k], v):
            continue
        if isinstance(v, pd.DataFrame):
            parts.append(f"{k}={(var_names or {}).get(id(v), '<DataFrame>')}")
        else:
            parts.append(f"{k}={v!r}")
    prefix = "Quickish." if func_name == "startup" else "qa."
    return f"{prefix}{func_name}(" + ", ".join(parts) + ")"


def _eq(a, b) -> bool:
    try:
        return bool(a == b) if not isinstance(a, pd.DataFrame) and not isinstance(b, pd.DataFrame) else a is b
    except Exception:
        return False


# One line per parameter of the public API; used by the prompts and by the AI module reference.
PARAM_SPEC: dict[str, dict[str, str]] = {
    "load": {
        "name": "Dataset name used in SQL", "source": "File, folder, list of them, or a DataFrame",
        "pattern": "Glob(s) on file names in folders, e.g. 'sales_*.csv'", "recursive": "Also search subfolders",
        "month_end_start": "Add month_end: first file gets this month-end, each next file the next one",
        "usecols": "Read only these raw columns", "nrows": "Read only the first N rows in total",
        "sheet": "Excel sheet index/name, or 'all'", "rename": "{'raw name': 'new name'}",
        "normalize": "snake_case column names", "to_int": "Columns → int64 (round half up, nulls → 0)",
        "to_float": "Columns → float64 (nulls → 0)", "to_str": "Columns → text (nulls → '', trimmed)",
        "to_date": "{col: format} → datetime; a list prompts for formats",
        "str_operation": "{col: [upper_case, lower_case, remove_special_character, remove_space, sentence_case, capitalize_each_word]}",
        "drop_empty": "Drop rows empty in these columns (judged before fills)",
        "where": "pandas query filter after cleaning, e.g. \"amount > 0\"",
        "str_sync": "{col: {'old': 'new'}} value mapping over the whole data",
        "dedup": "Drop duplicate values one column at a time (keeps first; nulls kept)",
        "dedup_combine": "Drop rows duplicated on the combination of these columns",
        "agg": "{'groupby': [...], 'aggs': {col: fn}} → name = summary, name_detail = rows",
        "chunk_rows": "Rows per chunk", "overwrite": "Replace a dataset loaded with different inputs",
        "rebuild": "Re-clean even if identical", "read_kwargs": "Reader options, e.g. sep=';'",
    },
    "sql": {"query": "SQL (DuckDB dialect); datasets and pandas DataFrames are tables",
            "limit": "Append LIMIT", "as_name": "Save the result as a view instead of returning it",
            "frames": "{'name': df} DataFrames usable as tables for this query",
            "no_limit": "Skip the 'Pull N rows into pandas?' question"},
    "filter": {"name": "Dataset", "where": "SQL condition", "columns": "Columns to keep", "order_by": "SQL ORDER BY",
               "limit": "Row limit", "as_name": "Save as view", "no_limit": "Skip the large-pull question"},
    "pivot": {"name": "Dataset", "index": "Row grouping column(s)", "values": "Column(s) to aggregate",
              "columns": "Column grouping column(s)", "agg": "'sum' or {col: fn or [fns]}",
              "where": "SQL filter before aggregation", "fill_value": "Fill for empty cells", "margins": "Add totals"},
    "explore": {"data": "Dataset name or DataFrame", "group_by": "Columns to pre-aggregate on (> explore.max_rows)",
                "rows": "Initial row fields", "cols": "Initial column fields"},
    "chart": {"data": "DataFrame or dataset name", "kind": "bar/line/scatter/hist/box/pie/heatmap", "x": "X column",
              "y": "Y column(s)", "color": "Series column", "title": "Title", "save": ".html or .png file",
              "no_limit": "Skip the large-pull question", "kwargs": "plotly.express options"},
    "to_markdown": {"obj": "Dataset name(s) or a DataFrame", "note": "Your question for the AI",
                    "sample_rows": "Real rows to include", "max_unique": "Unique values per text column",
                    "mask_strings": "Mask text values"},
    "clean": {"df": "Small DataFrame to clean", "name": "Answers file name"},
    "export": {"source": "Dataset name, SELECT or DataFrame", "path": ".csv / .parquet / .xlsx file",
               "fmt": "csv/parquet/xlsx", "sheet_name": "Excel sheet name", "no_limit": "Skip the large-pull question"},
    "drop": {"name": "Dataset to remove"},
    "guide": {"func": "Public function to walk through, e.g. 'load'"},
}
PARAM_SPEC["clean"].update({k: v for k, v in PARAM_SPEC["load"].items()
                            if k in {"rename", "normalize", "to_int", "to_float", "to_str", "to_date", "str_operation",
                                     "drop_empty", "where", "str_sync", "dedup", "dedup_combine"}})


def _probe(func: Callable) -> Callable:
    """Decorator: in a notebook, prompt for missing required args, print the call, confirm, run."""
    sig = inspect.signature(func)

    @functools.wraps(func)
    def wrapper(self, *args, **kwargs):
        try:
            bound = sig.bind_partial(self, *args, **kwargs)
        except TypeError:
            return func(self, *args, **kwargs)
        missing = [p for n, p in sig.parameters.items()
                   if n != "self" and p.default is inspect.Parameter.empty
                   and p.kind not in (p.VAR_KEYWORD, p.VAR_POSITIONAL) and n not in bound.arguments]
        if not missing:
            return func(self, *args, **kwargs)
        if not (_in_notebook() and getattr(self, "probe_enabled", False)):
            return func(self, *args, **kwargs)  # Python raises the normal TypeError
        return self._run_probe(func, sig, dict(bound.arguments), full=False)

    wrapper._probed = True  # type: ignore[attr-defined]
    return wrapper


# =====================================================================================
# Cleaning helpers (module-level, importable, never read config)
# =====================================================================================
_UNNAMED = re.compile(r"^Unnamed: \d+(_level_\d+)?$")
_OPS = {"upper_case", "lower_case", "remove_special_character", "remove_space", "sentence_case", "capitalize_each_word"}
_OP_ALIASES = {"low_case": "lower_case", "centence_case": "sentence_case", "upper": "upper_case", "lower": "lower_case"}


def _is_text(s: pd.Series) -> bool:
    """Text column under pandas 2 (object) and pandas 3 (str)."""
    return s.dtype == object or pd.api.types.is_string_dtype(s)


def _as_list(x) -> list:
    if x is None:
        return []
    return [x] if isinstance(x, (str, Path)) else list(x)


def _check_cols(df: pd.DataFrame, cols, step: str) -> None:
    unknown = [c for c in cols if c not in df.columns]
    if unknown:
        raise KeyError(f"{step}: unknown column(s) {unknown}. Available: {list(df.columns)}")


def _snake(name: str) -> str:
    s = re.sub(r"[^0-9a-zA-Z]+", "_", str(name).strip()).strip("_").lower()
    s = re.sub(r"_+", "_", s)
    if not s:
        s = "col"
    if s[0].isdigit():
        s = f"col_{s}"
    return s


def normalize_columns(df: pd.DataFrame, skip: list[str] | None = None, drop_unnamed: bool = True):
    """snake_case column names (names in ``skip`` untouched); drop 'Unnamed: n'. Returns (df, info)."""
    skip = set(skip or [])
    out = df.copy()
    dropped = [c for c in out.columns if drop_unnamed and isinstance(c, str) and _UNNAMED.match(c)]
    out = out.drop(columns=dropped)
    new, seen, renamed = [], {}, 0
    for c in out.columns:
        n = c if c in skip else _snake(c)
        base, k = n, 2
        while n in seen:
            n = f"{base}_{k}"
            k += 1
        seen[n] = True
        renamed += n != c
        new.append(n)
    out.columns = new
    return out, {"renamed": renamed, "dropped": dropped}


def _parse_numeric(s: pd.Series) -> pd.Series:
    if pd.api.types.is_bool_dtype(s):
        return s.astype("float64")
    if pd.api.types.is_numeric_dtype(s):
        return s.astype("float64")
    t = s.astype("string").str.strip()
    neg = t.str.fullmatch(r"\(.*\)").fillna(False)
    t = t.str.replace(r"[^0-9.\-]", "", regex=True)
    t = t.mask(t.isin(["", "-", ".", "-."]))
    num = pd.to_numeric(t, errors="coerce").astype("float64")
    num[neg.to_numpy(bool)] = -num[neg.to_numpy(bool)].abs()
    return num


def _round_half_up(x: pd.Series) -> pd.Series:
    return np.sign(x) * np.floor(np.abs(x) + 0.5)


def to_int(df: pd.DataFrame, cols):
    """Convert to int64: parse text ('1,234', 'RM 12', '(7)'), round half up, nulls → 0. Returns (df, counts)."""
    cols = _as_list(cols)
    _check_cols(df, cols, "to_int")
    out, counts = df.copy(), {}
    for c in cols:
        before_null = out[c].isna() | (out[c].astype("string").str.strip() == "").fillna(False)
        num = _parse_numeric(out[c])
        coerced = int((num.isna() & ~before_null).sum())
        filled = int(num.isna().sum())
        out[c] = _round_half_up(num.fillna(0)).astype("int64")
        counts[c] = {"coerced": coerced, "filled": filled}
    return out, counts


def to_float(df: pd.DataFrame, cols):
    """Convert to float64: parse text, nulls → 0.0. Returns (df, counts)."""
    cols = _as_list(cols)
    _check_cols(df, cols, "to_float")
    out, counts = df.copy(), {}
    for c in cols:
        before_null = out[c].isna() | (out[c].astype("string").str.strip() == "").fillna(False)
        num = _parse_numeric(out[c])
        counts[c] = {"coerced": int((num.isna() & ~before_null).sum()), "filled": int(num.isna().sum())}
        out[c] = num.fillna(0.0).astype("float64")
    return out, counts


def to_str(df: pd.DataFrame, cols):
    """Convert to text: nulls → '', trim, collapse spaces, '12345.0' → '12345'. Returns (df, counts)."""
    cols = _as_list(cols)
    _check_cols(df, cols, "to_str")
    out, counts = df.copy(), {}
    for c in cols:
        s = out[c]
        filled = int(s.isna().sum())
        if pd.api.types.is_float_dtype(s):
            whole = s.dropna()
            if len(whole) and (whole == np.floor(whole)).all():
                s = s.astype("Int64")
        t = s.astype("string").fillna("")
        t = t.str.replace(r"^(-?\d+)\.0+$", r"\1", regex=True)
        t = t.str.strip().str.replace(r"\s+", " ", regex=True)
        out[c] = t.astype(object)
        counts[c] = {"filled": filled}
    return out, counts


def _numeric_only_format(fmt: str) -> bool:
    return bool(re.fullmatch(r"(%[YmdjHMSy])+", fmt))


def to_date(df: pd.DataFrame, mapping: dict):
    """Convert columns to datetime64[ns] using {col: format}. Numeric-only formats (%Y%m%d, %d%m%Y,
    %Y%j…) strip spaces/non-digits and cut '20240131.0' at the dot; 'excel' converts serial numbers.
    Unparseable → NaT (counted). Returns (df, counts)."""
    if not isinstance(mapping, dict):
        raise ValueError("to_date needs {column: format}; pass a list to load()/clean() to be prompted")
    _check_cols(df, list(mapping), "to_date")
    out, counts = df.copy(), {}
    for c, fmt in mapping.items():
        s = out[c]
        before_null = s.isna() | (s.astype("string").str.strip() == "").fillna(False)
        if pd.api.types.is_datetime64_any_dtype(s):
            res = s
        elif fmt == "excel":
            num = _parse_numeric(s)
            res = pd.to_datetime(num, unit="D", origin="1899-12-30", errors="coerce")
        else:
            if _numeric_only_format(fmt):
                width = len(_dt.datetime(2000, 1, 1).strftime(fmt))
                if pd.api.types.is_numeric_dtype(s):
                    t = _round_half_up(s.astype("float64")).astype("Int64").astype("string")
                else:
                    t = s.astype("string").str.strip()
                    t = t.str.replace(r"^\s*(\d[\d\s]*)\.\d*\s*$", r"\1", regex=True)
                    t = t.str.replace(r"\D", "", regex=True)
                t = t.str.zfill(width)
            else:
                t = s.astype("string").str.strip()
            res = pd.to_datetime(t, format=fmt, errors="coerce")
        res = pd.to_datetime(res, errors="coerce").astype("datetime64[ns]")
        counts[c] = {"coerced": int((res.isna() & ~before_null).sum())}
        out[c] = res
    return out, counts


def _norm_op(op: str) -> str:
    op = _OP_ALIASES.get(op, op)
    if op not in _OPS:
        raise ValueError(f"Unknown string operation '{op}'. Valid: {sorted(_OPS)}")
    return op


def str_operation(df: pd.DataFrame, mapping: dict):
    """Apply string operations {col: [ops]} in order. Returns (df, ops_applied)."""
    if not isinstance(mapping, dict):
        raise ValueError("str_operation needs {column: [ops]}; pass a list to load()/clean() to be prompted")
    _check_cols(df, list(mapping), "str_operation")
    out, done = df.copy(), {}
    for c, ops in mapping.items():
        ops = [_norm_op(o) for o in _as_list(ops)]
        s = out[c].astype("string")
        for op in ops:
            if op == "upper_case":
                s = s.str.upper()
            elif op == "lower_case":
                s = s.str.lower()
            elif op == "remove_special_character":
                s = s.str.replace(r"[^\w\s]|_", "", regex=True)
            elif op == "remove_space":
                s = s.str.replace(r"\s+", "", regex=True)
            elif op == "sentence_case":
                s = s.str.capitalize()
            elif op == "capitalize_each_word":
                s = s.str.title()
        out[c] = s.astype(object).where(s.notna(), None)
        done[c] = ops
    return out, done


def _empty_mask(df: pd.DataFrame, cols) -> pd.DataFrame:
    m = pd.DataFrame(index=df.index)
    for c in cols:
        s = df[c]
        e = s.isna()
        if _is_text(s):
            e = e | (s.astype("string").str.strip() == "").fillna(False)
        m[c] = e.to_numpy(bool)
    return m


def drop_empty(df: pd.DataFrame, cols, null_mask: pd.DataFrame | None = None):
    """Drop rows null/blank in any of ``cols`` (use ``null_mask`` captured before fills). Returns (df, counts)."""
    cols = _as_list(cols)
    _check_cols(df, cols, "drop_empty")
    mask = null_mask[cols] if null_mask is not None else _empty_mask(df, cols)
    drop = mask.any(axis=1).to_numpy(bool)
    by_col = {c: int(mask[c].sum()) for c in cols}
    return df.loc[~drop].copy(), {"rows_dropped": int(drop.sum()), "by_column": by_col}


def _add_counts(report: dict, step: str, counts) -> None:
    """Sum nested counts into the report."""
    cur = report.setdefault(step, {})

    def merge(dst, src):
        for k, v in src.items():
            if isinstance(v, dict):
                merge(dst.setdefault(k, {}), v)
            elif isinstance(v, (int, float)) and not isinstance(v, bool):
                dst[k] = dst.get(k, 0) + v
            else:
                dst[k] = v
    merge(cur, counts)


def _clean_chunk(df: pd.DataFrame, spec: dict, report: dict) -> pd.DataFrame:
    """Per-chunk cleaning in fixed order: rename → normalize → null mask → to_* → str_operation →
    drop_empty → where. Pure: never modifies ``df``."""
    out = df
    rows_in = len(out)
    if spec.get("rename"):
        missing = [c for c in spec["rename"] if c not in out.columns]
        if missing:
            raise KeyError(f"rename: unknown column(s) {missing}. Available: {list(out.columns)}")
        out = out.rename(columns=spec["rename"])
    if spec.get("normalize", True):
        out, info = normalize_columns(out, skip=list((spec.get("rename") or {}).values()))
    mask = _empty_mask(out, _as_list(spec.get("drop_empty"))) if spec.get("drop_empty") else None
    for step, fn, arg in (("to_int", to_int, spec.get("to_int")), ("to_float", to_float, spec.get("to_float")),
                          ("to_str", to_str, spec.get("to_str")), ("to_date", to_date, spec.get("to_date")),
                          ("str_operation", str_operation, spec.get("str_operation"))):
        if arg:
            out, counts = fn(out, arg)
            _add_counts(report, step, counts)
    if spec.get("drop_empty"):
        out, counts = drop_empty(out, spec["drop_empty"], null_mask=mask.loc[out.index] if mask is not None else None)
        _add_counts(report, "drop_empty", counts)
    if spec.get("where"):
        before = len(out)
        out = out.query(spec["where"])
        _add_counts(report, "where", {"rows_dropped": before - len(out)})
    _add_counts(report, "rows", {"in": rows_in, "out": len(out)})
    return out if out is not df else df.copy()


# =====================================================================================
# File discovery and readers
# =====================================================================================
_SUPPORTED = {".csv": "csv", ".txt": "csv", ".tsv": "csv", ".parquet": "parquet", ".pq": "parquet",
              ".xlsx": "xlsx", ".xlsm": "xlsx", ".xls": "xls", ".xlsb": "xlsb"}
_EXCEL_ENGINE = {"xlsx": "openpyxl", "xls": "xlrd", "xlsb": "pyxlsb"}


def _detect_format(path: Path) -> str:
    """Map a file extension to a loader format."""
    fmt = _SUPPORTED.get(Path(path).suffix.lower())
    if fmt is None:
        raise ValueError(f"Unsupported file type '{Path(path).suffix}'. Supported: {sorted(_SUPPORTED)}")
    return fmt


def _natural_key(p: Path):
    return [int(t) if t.isdigit() else t.lower() for t in re.split(r"(\d+)", p.name)]


def _list_files(source, pattern=None, recursive: bool = False) -> list[Path]:
    """Expand a file / folder / list into the sorted list of files to load (natural order)."""
    items = [Path(x) for x in _as_list(source)]
    pats = _as_list(pattern) or ["*"]
    files, skipped = [], []
    for item in items:
        if item.is_file():
            files.append(item)
            continue
        if not item.is_dir():
            raise FileNotFoundError(f"Not found: {item}")
        found = set()
        for pat in pats:
            found.update(item.rglob(pat) if recursive else item.glob(pat))
        for f in sorted(found):
            if not f.is_file():
                continue
            if f.name.startswith("~$"):
                skipped.append(f"{f.name} (Excel lock file)")
            elif f.name.startswith("."):
                skipped.append(f"{f.name} (hidden)")
            elif f.suffix.lower() not in _SUPPORTED:
                skipped.append(f"{f.name} (unsupported type)")
            else:
                files.append(f)
    files = sorted(dict.fromkeys(p.resolve() for p in files), key=_natural_key)
    if not files:
        listing = []
        for item in items:
            if item.is_dir():
                listing += [p.name for p in sorted(item.iterdir())][:30]
        raise FileNotFoundError(f"No files matched {[str(i) for i in items]} with pattern {pats}. "
                                f"Present: {listing or 'nothing'}")
    total = sum(f.stat().st_size for f in files) / 1e9
    if len(files) > 1 or skipped:
        log.info("%d file(s) matched, %.2f GB total%s", len(files), total,
                 f"; skipped: {', '.join(skipped)}" if skipped else "")
    return files


def _csv_kwargs(path: Path, read_kwargs: dict) -> dict:
    kw = dict(read_kwargs)
    if path.suffix.lower() == ".tsv" and "sep" not in kw and "delimiter" not in kw:
        kw["sep"] = "\t"
    return kw


def _read_header(path: Path, fmt: str, sheet=0, read_kwargs: dict | None = None) -> list[str]:
    read_kwargs = read_kwargs or {}
    if fmt == "csv":
        kw = _csv_kwargs(path, read_kwargs)
        if path.suffix.lower() == ".txt" and "sep" not in kw:
            kw.update(sep=None, engine="python")
        for enc in ([kw.pop("encoding")] if "encoding" in kw else ["utf-8", "utf-8-sig", "cp1252"]):
            try:
                return list(pd.read_csv(path, nrows=0, encoding=enc, **kw).columns)
            except UnicodeDecodeError:
                continue
        raise ValueError(f"Cannot decode header of {path}")
    if fmt == "parquet":
        return list(pq.read_schema(path).names)
    sh = 0 if sheet == "all" else sheet
    return list(pd.read_excel(path, sheet_name=sh, nrows=0, engine=_EXCEL_ENGINE[fmt]).columns)


def _check_headers(files: list[Path], usecols=None, rename=None, normalize=True, read_kwargs=None, sheet=0) -> None:
    """Read only headers; raise ValueError with a table if files differ (after rename/normalise)."""
    sets = {}
    for f in files:
        cols = _read_header(f, _detect_format(f), sheet, read_kwargs)
        if usecols:
            cols = [c for c in cols if c in set(usecols)]
        cols = [(rename or {}).get(c, c) for c in cols]
        if normalize:
            keep = set((rename or {}).values())
            cols = [c if c in keep else _snake(c) for c in cols if not (isinstance(c, str) and _UNNAMED.match(c))]
        sets[f] = set(cols)
    ref = sets[files[0]]
    if all(s == ref for s in sets.values()):
        log.info("Header check: %d files, %d columns OK", len(files), len(ref))
        return
    union = set().union(*sets.values())
    rows = [f"  {f.name:<32} missing={sorted(union - s) or '-'}  extra={sorted(s - ref) or '-'}"
            for f, s in sets.items() if s != union or s != ref]
    raise ValueError("Header mismatch across files:\n" + "\n".join(rows) +
                     "\nFix: usecols=[...] to pick the shared columns, or rename={...}.")


def _month_end_map(files: list[Path], month_end_start: str) -> dict[Path, _dt.date]:
    """Assign sequential month-ends to files in load order, starting from ``month_end_start``."""
    try:
        start = _dt.date.fromisoformat(str(month_end_start))
    except ValueError:
        raise ValueError(f"month_end_start must be 'YYYY-MM-DD', got {month_end_start!r}") from None
    me = (pd.Timestamp(start) + pd.offsets.MonthEnd(0)).date()
    if me != start:
        raise ValueError(f"month_end_start {start} is not a month-end; did you mean {me}?")
    return {f: (pd.Timestamp(start) + pd.offsets.MonthEnd(i)).date() for i, f in enumerate(files)}


def _slices(df: pd.DataFrame, n: int) -> Iterator[pd.DataFrame]:
    if len(df) == 0:
        yield df
        return
    for i in range(0, len(df), n):
        yield df.iloc[i:i + n]


def _reader_candidates(path: Path, fmt: str, whole: bool, chunk_rows: int, usecols, nrows, sheet,
                       read_kwargs: dict) -> list[tuple[str, Callable[[], Iterator[pd.DataFrame]]]]:
    """Ordered reader chain for one file. Each factory returns an iterator of pandas chunks; any
    exception it raises while iterating is a READER failure (the caller tries the next reader)."""
    kw = _csv_kwargs(path, read_kwargs)
    is_txt = path.suffix.lower() == ".txt" and "sep" not in kw
    cands: list[tuple[str, Callable]] = []

    def whole_reader(fn):
        def gen():
            df = fn()
            for c in df.columns:  # pyarrow engine returns raw bytes for non-UTF-8 text instead of failing
                if df[c].dtype == object and len(df) and isinstance(df[c].dropna().head(50).tolist()[:1] or [None], list) \
                        and any(isinstance(v, (bytes, bytearray)) for v in df[c].dropna().head(50)):
                    raise UnicodeDecodeError("utf-8", b"", 0, 1, f"column {c!r} is not valid UTF-8")
            if nrows is not None:
                df = df.head(nrows)
            yield from _slices(df, chunk_rows)
        return gen

    if fmt == "csv":
        encs = [None] if "encoding" in kw else [None, "utf-8-sig", "cp1252"]
        if whole:
            try:
                import polars as pl  # noqa: F401
                if set(kw) <= {"sep"} and not is_txt:
                    def _pl():
                        import polars as pl
                        return pl.read_csv(path, columns=usecols, n_rows=nrows, separator=kw.get("sep", ","),
                                           infer_schema_length=10_000).to_pandas()
                    cands.append(("polars", whole_reader(_pl)))
            except ImportError:
                log.debug("polars not installed: skipped")
            if not is_txt:
                cands.append(("pandas-pyarrow", whole_reader(lambda: pd.read_csv(path, engine="pyarrow", usecols=usecols, **kw))))
            cands.append(("pandas-c", whole_reader(lambda: pd.read_csv(path, usecols=usecols, nrows=nrows, low_memory=False, **kw))))
        for enc in encs:
            ek = dict(kw) if enc is None else {**kw, "encoding": enc}
            tag = "" if enc is None else f"[{enc}]"
            if not is_txt:
                cands.append((f"pandas-c-chunked{tag}",
                              lambda ek=ek: pd.read_csv(path, usecols=usecols, nrows=nrows, chunksize=chunk_rows,
                                                        low_memory=False, **ek)))
            pyk = dict(ek)
            if is_txt:
                pyk["sep"] = None
            cands.append((f"pandas-python-chunked{tag}",
                          lambda pyk=pyk: pd.read_csv(path, usecols=usecols, nrows=nrows, chunksize=chunk_rows,
                                                      engine="python", **pyk)))
    elif fmt == "parquet":
        if whole:
            try:
                import polars  # noqa: F401
                cands.append(("polars", whole_reader(lambda: __import__("polars").read_parquet(path, columns=usecols, n_rows=nrows).to_pandas())))
            except ImportError:
                log.debug("polars not installed: skipped")
            cands.append(("pandas-fastparquet", whole_reader(lambda: pd.read_parquet(path, engine="fastparquet", columns=usecols))))
            cands.append(("pandas-pyarrow", whole_reader(lambda: pd.read_parquet(path, engine="pyarrow", columns=usecols))))

        def _pa_batches():
            left = nrows
            pf = pq.ParquetFile(path)
            for b in pf.iter_batches(batch_size=chunk_rows, columns=usecols):
                df = b.to_pandas()
                if left is not None:
                    df = df.head(left)
                    left -= len(df)
                yield df
                if left is not None and left <= 0:
                    return
        cands.append(("pyarrow-batches", _pa_batches))

        def _fp_groups():
            from fastparquet import ParquetFile
            left = nrows
            for df in ParquetFile(str(path)).iter_row_groups(columns=usecols):
                if left is not None:
                    df = df.head(left)
                    left -= len(df)
                yield df
                if left is not None and left <= 0:
                    return
        cands.append(("fastparquet-row-groups", _fp_groups))
    else:
        engine = _EXCEL_ENGINE[fmt]

        def _excel():
            if sheet == "all":
                book = pd.read_excel(path, sheet_name=None, usecols=usecols, nrows=nrows, engine=engine)
                for name, df in book.items():
                    yield df.assign(_sheet=name)
            else:
                yield pd.read_excel(path, sheet_name=sheet, usecols=usecols, nrows=nrows, engine=engine)
        cands.append((f"pandas-{engine}", _excel))
    return cands


def _read_whole(path: Path, fmt: str, usecols=None, nrows=None, sheet=0, read_kwargs=None) -> tuple[pd.DataFrame, str]:
    """Read a whole (small) file with the reader chain; return (frame, reader)."""
    attempts = []
    for name, make in _reader_candidates(Path(path), fmt, True, 10 ** 12, usecols, nrows, sheet, read_kwargs or {}):
        try:
            return pd.concat(list(make()), ignore_index=True), name
        except Exception as e:  # noqa: BLE001 - reader errors are collected
            attempts.append((name, f"{type(e).__name__}: {e}"[:300]))
            log.warning("reader %s failed for %s: %s", name, Path(path).name, attempts[-1][1])
    raise ReaderChainError(path, attempts)


def _align_schema(df: pd.DataFrame, schema: pa.Schema) -> pa.Table:
    """Cast a chunk to the schema locked on the first chunk. Missing columns → nulls; extra columns
    dropped with a warning; a cast that would lose data raises ArrowInvalid naming the column."""
    df = _arrow_safe(df)
    extra = [c for c in df.columns if c not in schema.names]
    if extra:
        log.warning("dropping columns not in the first chunk: %s", extra)
    table = pa.Table.from_pandas(df.drop(columns=extra), preserve_index=False)
    cols = []
    for field in schema:
        if field.name not in table.column_names:
            cols.append(pa.nulls(len(table), type=field.type))
            continue
        col = table[field.name]
        if col.type != field.type:
            if col.null_count == len(col):
                col = pa.nulls(len(table), type=field.type)
            else:
                try:
                    col = col.cast(field.type)
                except (pa.ArrowInvalid, pa.ArrowNotImplementedError) as e:
                    raise pa.ArrowInvalid(
                        f"column '{field.name}' was {field.type} in the first chunk but {col.type} later "
                        f"({e}). Convert it explicitly with to_str / to_float / to_int.") from None
        cols.append(col)
    return pa.Table.from_arrays(cols, schema=schema)


def _arrow_safe(df: pd.DataFrame) -> pd.DataFrame:
    """Object columns with mixed Python types (common in Excel) → strings so Arrow accepts them."""
    out = None
    for c in df.columns:
        s = df[c]
        if s.dtype == object:
            nn = s.dropna()
            if len(nn) and not nn.map(type).eq(str).all():
                out = df.copy() if out is None else out
                out[c] = s.where(s.isna(), s.astype(str))
    return df if out is None else out


def _lock_schema(df: pd.DataFrame) -> pa.Schema:
    sch = pa.Schema.from_pandas(_arrow_safe(df), preserve_index=False)
    fields = [pa.field(f.name, pa.string()) if pa.types.is_null(f.type) else f for f in sch]
    return pa.schema(fields)


# =====================================================================================
# SQL building, masking, markdown
# =====================================================================================
_AGG = {"sum": "sum({c})", "count": "count({c})", "avg": "avg({c})", "mean": "avg({c})", "min": "min({c})",
        "max": "max({c})", "first": "first({c})", "last": "last({c})", "count_distinct": "count(DISTINCT {c})",
        "median": "median({c})"}


def _q(name: str) -> str:
    return '"' + str(name).replace('"', '""') + '"'


def _norm_aggs(values, agg) -> dict[str, list[str]]:
    values = _as_list(values)
    if isinstance(agg, str):
        aggs = {v: [agg] for v in values}
    else:
        aggs = {k: _as_list(v) for k, v in agg.items()}
        for v in values:
            aggs.setdefault(v, ["sum"])
    for col, fns in aggs.items():
        if len(set(fns)) != len(fns):
            raise ValueError(f"agg for '{col}' repeats a function: {fns}")
        for fn in fns:
            if fn not in _AGG:
                raise ValueError(f"Unknown aggregate '{fn}'. Valid: {sorted(_AGG)}")
    return aggs


def _build_group_sql(source: str, groupby: list[str], aggs: dict[str, list[str]], where: str | None = None) -> str:
    """SELECT groupby…, fn(col) AS col_fn … FROM source [WHERE] GROUP BY ALL."""
    sel = [_q(g) for g in groupby]
    for col, fns in aggs.items():
        for fn in fns:
            alias = f"{col}_{'avg' if fn == 'mean' else fn}"
            sel.append(f"{_AGG[fn].format(c=_q(col))} AS {_q(alias)}")
    sql = f"SELECT {', '.join(sel)} FROM {source}"
    if where:
        sql += f" WHERE {where}"
    if groupby:
        sql += " GROUP BY ALL ORDER BY " + ", ".join(_q(g) for g in groupby)
    return sql


def _mask_value(value: Any, max_len: int = 60) -> str:
    """Same-shape placeholder: letters → A/a, digits → 9."""
    if value is None or (isinstance(value, float) and math.isnan(value)):
        return ""
    s = str(value)
    out = "".join("A" if ch.isupper() else "a" if ch.isalpha() else "9" if ch.isdigit() else ch for ch in s)
    return out if len(out) <= max_len else out[: max_len - 1] + "…"


def _df_to_md_table(df: pd.DataFrame, max_rows: int = 50, float_fmt: str = "{:.4g}") -> str:
    """GitHub-flavoured markdown table, no external dependency."""
    d = df.head(max_rows)

    def cell(v):
        if v is None or (isinstance(v, float) and math.isnan(v)) or v is pd.NaT:
            return ""
        if isinstance(v, float):
            v = float_fmt.format(v)
        return str(v).replace("|", "\\|").replace("\r", " ").replace("\n", " ")
    head = "| " + " | ".join(str(c) for c in d.columns) + " |"
    sep = "|" + "|".join("---" for _ in d.columns) + "|"
    rows = ["| " + " | ".join(cell(v) for v in r) + " |" for r in d.itertuples(index=False, name=None)]
    return "\n".join([head, sep, *rows])


def _module_reference(cls) -> str:
    """Compact cheat sheet of the public API, generated from the live code."""
    lines = ["Object `qa` is a quickishanalysis.Quickish session. Public methods:"]
    for name, fn in inspect.getmembers(cls, predicate=inspect.isfunction):
        if name.startswith("_") or name == "startup":
            continue
        sig = str(inspect.signature(fn)).replace("(self, ", "(").replace("(self)", "()")
        sig = re.sub(r":\s*'([^']*)'", r": \1", sig)
        sig = re.sub(r"->\s*'([^']*)'", r"-> \1", sig)
        doc = (inspect.getdoc(fn) or "").split("\n")[0]
        lines.append(f"- qa.{name}{sig} — {doc}")
    lines += [
        "load() cleaning parameters: " + "; ".join(f"{k}: {v}" for k, v in PARAM_SPEC["load"].items()
                                                 if k in {"to_int", "to_float", "to_str", "to_date", "str_sync",
                                                          "dedup", "dedup_combine", "drop_empty", "where", "agg"}),
        "SQL dialect: DuckDB — GROUP BY ALL, QUALIFY, SELECT * EXCLUDE (...), strftime(date, '%Y-%m'), "
        "date_trunc('month', d), last_day(d), read_parquet(...). qa.sql() returns a pandas DataFrame; "
        "pandas DataFrames in the notebook can be queried by variable name or via frames={'n': df}.",
    ]
    return "\n".join(lines)


# =====================================================================================
# Quickish
# =====================================================================================
_CLEAN_KEYS = ["rename", "normalize", "to_int", "to_float", "to_str", "to_date", "str_operation", "drop_empty",
               "where", "str_sync", "dedup", "dedup_combine"]


class Quickish:
    """A notebook session: one DuckDB connection, a config and a registry of datasets."""

    # ---------------------------------------------------------------- lifecycle
    @classmethod
    def startup(cls, path: str | Path | None = None) -> "Quickish":
        """Start a session from quickishanalysis.yaml (default: beside this .py)."""
        path = Path(path) if path else Path(__file__).with_suffix(".yaml")
        cfg = _validate_config(_read_yaml(path))
        log.info("Config loaded from %s", path.resolve())
        return cls(cfg, base_dir=path.resolve().parent)

    def __init__(self, config: dict, base_dir: Path | None = None):
        """Open DuckDB, apply pragmas, clear session data, purge old outputs, register the exit hook."""
        self.config = config
        self._base_dir = Path(base_dir) if base_dir else Path.cwd()
        log.setLevel(str(config["logging"]["level"]).upper())
        for key in (("io", "clean_dir"), ("io", "answers_dir"), ("explore", "output_dir"),
                    ("engine", "temp_directory")):
            self._path(config[key[0]][key[1]]).mkdir(parents=True, exist_ok=True)
        db = config["engine"]["database"]
        self._con = duckdb.connect(db if db == ":memory:" else str(self._path(db)))
        self._con.execute(f"SET memory_limit = '{config['engine']['memory_limit']}'")
        self._con.execute(f"SET threads = {int(config['engine']['threads'])}")
        self._con.execute(f"SET temp_directory = '{self._path(config['engine']['temp_directory']).as_posix()}'")
        try:
            self._con.execute("SET python_scan_all_frames = true")
        except duckdb.Error:
            log.debug("python_scan_all_frames not supported by this DuckDB version")
        self.probe_enabled = bool(config["probe"]["enabled"])
        self._datasets: dict[str, dict] = {}
        self.last_result: pd.DataFrame | None = None
        self.last_clean_report: dict | None = None
        n = self._clear_clean()
        log.info("DuckDB %s memory_limit=%s threads=%s | cleared %d cleaned file(s) from %s (one notebook at a time)",
                 db, config["engine"]["memory_limit"], config["engine"]["threads"], n, config["io"]["clean_dir"])
        purged = self._purge_outputs(config["io"]["output_max_age_days"])
        if any(purged.values()):
            log.info("Purged %d pivot file(s), %d spill file(s) older than %d day(s)", purged["pivots_removed"],
                     purged["spill_removed"], config["io"]["output_max_age_days"])
        self._exit_hook = atexit.register(self.close)

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()

    def __repr__(self):
        return f"<Quickish datasets={list(self._datasets)}>"

    def close(self) -> None:
        """Close DuckDB and delete this session's cleaned data (.qa_clean)."""
        if getattr(self, "_con", None) is not None:
            try:
                self._con.close()
            finally:
                self._con = None
            n = self._clear_clean()
            log.info("Closed. Cleared %d cleaned file(s) from %s", n, self.config["io"]["clean_dir"])

    def _path(self, p) -> Path:
        p = Path(p)
        return p if p.is_absolute() else (self._base_dir / p).resolve()

    def _data_path(self, p) -> Path:
        p = Path(p)
        return p if p.is_absolute() else (self._path(self.config["io"]["data_dir"]) / p).resolve()

    def _clear_clean(self) -> int:
        """Delete every file in io.clean_dir (session data)."""
        n = 0
        for f in self._path(self.config["io"]["clean_dir"]).glob("*"):
            if f.is_file():
                try:
                    f.unlink()
                    n += 1
                except OSError as e:
                    log.warning("could not delete %s: %s", f.name, e)
        return n

    def _purge_outputs(self, max_age_days: int) -> dict:
        """Delete explore HTML and DuckDB spill leftovers older than ``max_age_days``."""
        res = {"pivots_removed": 0, "spill_removed": 0}
        if not max_age_days:
            return res
        cutoff = time.time() - max_age_days * 86400
        for key, folder in (("pivots_removed", self.config["explore"]["output_dir"]),
                            ("spill_removed", self.config["engine"]["temp_directory"])):
            for f in self._path(folder).rglob("*"):
                if f.is_file() and f.stat().st_mtime < cutoff:
                    try:
                        f.unlink()
                        res[key] += 1
                    except OSError as e:
                        log.warning("could not delete %s: %s", f.name, e)
        return res

    # ---------------------------------------------------------------- probing
    def _choices_for(self, fname: str, pname: str, collected: dict) -> list | None:
        if pname in {"name", "data", "obj"} or (fname in {"export"} and pname == "source"):
            return list(self._datasets) or None
        ds = collected.get("name") or collected.get("data")
        if isinstance(ds, str) and ds in self._datasets and pname in {"index", "values", "columns", "x", "y", "color",
                                                                      "group_by", "rows", "cols"}:
            return list(self.sql(f"SELECT * FROM {_q(ds)} LIMIT 0", no_limit=True).columns)
        if pname == "kind":
            return ["bar", "line", "scatter", "hist", "box", "pie", "heatmap"]
        if pname == "func":
            return self._public_methods()
        return None

    @classmethod
    def _public_methods(cls) -> list[str]:
        return [n for n, f in inspect.getmembers(cls, inspect.isfunction)
                if not n.startswith("_") and getattr(f, "_probed", False)]

    def _run_probe(self, func, sig, collected: dict, full: bool):
        fname = func.__name__
        spec = PARAM_SPEC.get(fname, {})
        collected.pop("self", None)
        params = [p for n, p in sig.parameters.items() if n != "self"]
        required = [p for p in params if p.default is inspect.Parameter.empty
                    and p.kind not in (p.VAR_KEYWORD, p.VAR_POSITIONAL)]
        optional = [p for p in params if p not in required and p.kind != p.VAR_POSITIONAL]
        print(f"— qa.{fname}() —")
        for p in required:
            if p.name not in collected:
                collected[p.name] = _ask(p.name, spec.get(p.name, ""), self._choices_for(fname, p.name, collected),
                                         required=True)
        if full or _ask("Set optional parameters too? [y/N]", default="n") in ("y", "Y", "yes"):
            for p in optional:
                if p.name in collected:
                    continue
                default = None if p.kind == p.VAR_KEYWORD else p.default
                v = _ask(p.name, spec.get(p.name, ""), self._choices_for(fname, p.name, collected), default=default,
                         multi=p.name in {"index", "values", "group_by", "rows", "cols", "columns", "usecols"} and
                         bool(self._choices_for(fname, p.name, collected)))
                if p.kind == p.VAR_KEYWORD:
                    if isinstance(v, dict):
                        collected.update(v)
                elif not _eq(v, p.default):
                    collected[p.name] = v
        defaults = {n: p.default for n, p in sig.parameters.items()}
        print(_call_string(fname, collected, defaults))
        if _ask("Run now? [Y/n]", default="y") in ("n", "N", "no"):
            return None
        return func(self, **collected)

    @_probe
    def guide(self, func: str):
        """Walk through every parameter of a public function, print the call, confirm and run it."""
        if func not in self._public_methods():
            raise ValueError(f"'{func}' is not a public function. Choose from {self._public_methods()}")
        target = getattr(type(self), func)
        raw = inspect.unwrap(target)
        return self._run_probe(raw, inspect.signature(raw), {}, full=True)

    # ---------------------------------------------------------------- load
    @_probe
    def load(self, name: str, source, pattern=None, recursive: bool = False, month_end_start: str | None = None,
             usecols: list[str] | None = None, nrows: int | None = None, sheet: int | str = 0,
             rename: dict | None = None, normalize: bool | None = None, to_int=None, to_float=None, to_str=None,
             to_date=None, str_operation=None, drop_empty=None, where: str | None = None, str_sync=None,
             dedup=None, dedup_combine=None, agg: dict | None = None, chunk_rows: int | None = None,
             overwrite: bool = False, rebuild: bool = False, **read_kwargs) -> dict:
        """Load a file, folder or list (or a DataFrame), clean it as specified, register it for SQL."""
        if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", str(name)):
            raise ValueError(f"Dataset name {name!r} must be a valid identifier (letters, digits, _)")
        spec = {"rename": rename, "normalize": self.config["clean"]["normalize"] if normalize is None else normalize,
                "to_int": to_int, "to_float": to_float, "to_str": to_str, "to_date": to_date,
                "str_operation": str_operation, "drop_empty": drop_empty, "where": where, "str_sync": str_sync,
                "dedup": dedup, "dedup_combine": dedup_combine}
        is_frame = isinstance(source, pd.DataFrame)
        files = [] if is_frame else _list_files([self._data_path(s) for s in _as_list(source)], pattern, recursive)
        multi = (not is_frame) and (len(_as_list(source)) > 1 or any(self._data_path(s).is_dir() for s in _as_list(source)))
        identity = {"files": [(str(f), f.stat().st_size, int(f.stat().st_mtime)) for f in files],
                    "frame": id(source) if is_frame else None, "spec": spec, "usecols": usecols, "nrows": nrows,
                    "sheet": sheet, "month_end_start": month_end_start, "read_kwargs": read_kwargs, "agg": agg}
        if name in self._datasets and not overwrite:
            if self._datasets[name].get("identity") == json.loads(json.dumps(identity, default=str)) and not rebuild:
                log.info("%s already loaded with identical inputs, nothing to do", name)
                return self._datasets[name]["entry"]
            raise ValueError(f"Dataset '{name}' is already loaded with different inputs. Use overwrite=True "
                             f"or another name.")
        if name in self._datasets:
            self._drop_objects(name)
        t0 = time.time()
        report: dict = {}

        if is_frame:
            df, spec = self._clean_frame(source, spec, report, name)
            self._con.register(f"{name}_detail", df)
            entry = self._register(name, agg, mode="frame", cleaned_path=None, n_files=0, readers=["memory"],
                                   source="<DataFrame>", report=report, partial=False, month_end=False)
            self._datasets[name].update(identity=json.loads(json.dumps(identity, default=str)), frame=df)
            return entry

        chunk_rows = chunk_rows or self.config["io"]["chunk_rows"]
        if len(files) > 1:
            _check_headers(files, usecols, rename, spec["normalize"], read_kwargs, sheet)
        me_map = None
        if month_end_start:
            me_map = _month_end_map(files, month_end_start)
            print("Month-end mapping:")
            for f, d in me_map.items():
                print(f"   {f.name:<36} → {d}")
            if _in_notebook() and self.probe_enabled:
                if _ask("Assign these month-ends? [Y/n]", default="y") in ("n", "N", "no"):
                    raise ProbeCancelled("month-end mapping declined")
        key = hashlib.sha1(json.dumps(identity, default=str, sort_keys=True).encode()).hexdigest()[:10]
        target = self._path(self.config["io"]["clean_dir"]) / f"{name}__{key}.parquet"
        log.info("Loading %s from %d file(s)", name, len(files))
        schema = None
        pieces, readers, row_offset, remaining = [], [], 0, nrows
        try:
            for fi, f in enumerate(files):
                if remaining is not None and remaining <= 0:
                    break
                extra = {}
                if multi:
                    extra["_source_file"] = f.name
                if me_map:
                    extra["month_end"] = pd.Timestamp(me_map[f])
                piece = target.with_name(f"{target.stem}.part{fi:04d}.tmp")
                rows, rname, schema, spec = self._write_file(name, f, piece, spec, report, schema, chunk_rows,
                                                             usecols, remaining, sheet, read_kwargs, extra, row_offset)
                pieces.append(piece)
                readers.append(rname)
                row_offset += rows
                if remaining is not None:
                    remaining -= report.get("_raw_rows_last", 0)
            self._combine(pieces, target)
            post = self._post_write(name, target, spec)
            for k, v in post.items():
                report[k] = v
        except BaseException:
            for p in pieces + [target.with_suffix(".tmp")]:
                p.unlink(missing_ok=True)
            raise
        finally:
            report.pop("_raw_rows_last", None)
        self._con.execute(f"CREATE OR REPLACE VIEW {_q(name + '_detail')} AS "
                          f"SELECT * EXCLUDE (_row_id) FROM read_parquet('{target.as_posix()}')")
        entry = self._register(name, agg, mode="parquet-view", cleaned_path=str(target), n_files=len(files),
                               readers=readers, source=", ".join(str(s) for s in _as_list(source)), report=report,
                               partial=nrows is not None, month_end=bool(me_map))
        self._datasets[name]["identity"] = json.loads(json.dumps(identity, default=str))
        rows = report.get("rows", {})
        log.info("%s: %s rows in → %s out from %d file(s) in %.1fs", name, f"{rows.get('in', 0):,}",
                 f"{entry['rows']:,}", len(files), time.time() - t0)
        self.last_clean_report = report
        return entry

    def _write_file(self, name, path, piece, spec, report, schema, chunk_rows, usecols, nrows, sheet, read_kwargs,
                    extra, row_offset):
        """Read one file with its reader chain, clean every chunk, write a Parquet piece."""
        fmt = _detect_format(path)
        size_mb = path.stat().st_size / 1e6
        limit = self.config["io"]["whole_read_max_mb"]
        whole = bool(limit) and size_mb <= limit and fmt in ("csv", "parquet")
        cands = _reader_candidates(path, fmt, whole, chunk_rows, usecols, nrows, sheet, read_kwargs)
        log.info("%s %.0f MB → %s chain", path.name, size_mb, "whole-file" if whole else
                 ("per-sheet" if fmt in _EXCEL_ENGINE else "chunked"))
        attempts = []
        for rname, make in cands:
            writer, rows, raw_rows, local_report = None, 0, 0, {}
            sch = schema
            spec_now = spec
            try:
                try:
                    it = iter(make())
                except Exception as e:  # noqa: BLE001
                    raise _ReaderFailed(e) from e
                while True:
                    try:
                        chunk = next(it)
                    except StopIteration:
                        break
                    except Exception as e:  # noqa: BLE001
                        raise _ReaderFailed(e) from e
                    raw_rows += len(chunk)
                    if spec_now is spec and any(isinstance(spec.get(k), (list, str)) for k in ("to_date", "str_operation")):
                        spec_now = self._resolve_prompts(name, spec, sample=self._preview_clean(chunk, spec))
                    cleaned = _clean_chunk(chunk, spec_now, local_report)
                    for k, v in extra.items():
                        cleaned[k] = v
                    cleaned["_row_id"] = np.arange(row_offset + rows, row_offset + rows + len(cleaned), dtype="int64")
                    if sch is None:
                        sch = _lock_schema(cleaned)
                    table = _align_schema(cleaned, sch)
                    if writer is None:
                        writer = pq.ParquetWriter(piece, sch)
                    writer.write_table(table)
                    rows += len(cleaned)
                if writer is None:  # empty file: still write an empty piece with a schema
                    if sch is None:
                        sch = _lock_schema(_clean_chunk(pd.DataFrame(), spec_now, {}).assign(_row_id=pd.Series(dtype="int64")))
                    writer = pq.ParquetWriter(piece, sch)
                writer.close()
                for k, v in local_report.items():
                    _add_counts(report, k, v) if isinstance(v, dict) else None
                report["_raw_rows_last"] = raw_rows
                log.info("   reader %s ok: %s rows", rname, f"{rows:,}")
                return rows, rname, sch, spec_now
            except _ReaderFailed as e:
                if writer is not None:
                    writer.close()
                piece.unlink(missing_ok=True)
                err = e.__cause__ or e
                attempts.append((rname, f"{type(err).__name__}: {err}"[:300]))
                log.warning("reader %s failed for %s: %s", rname, path.name, attempts[-1][1])
                continue
            except BaseException:
                if writer is not None:
                    writer.close()
                piece.unlink(missing_ok=True)
                raise
        raise ReaderChainError(path, attempts)

    @staticmethod
    def _preview_clean(chunk: pd.DataFrame, spec: dict) -> pd.DataFrame:
        pre = dict(spec, to_date=None, str_operation=None, drop_empty=None, where=None)
        return _clean_chunk(chunk.head(1000), pre, {})

    def _combine(self, pieces: list[Path], target: Path) -> None:
        if len(pieces) == 1:
            os.replace(pieces[0], target)
            return
        tmp = target.with_suffix(".tmp")
        lst = ", ".join(f"'{p.as_posix()}'" for p in pieces)
        self._con.execute(f"COPY (SELECT * FROM read_parquet([{lst}]) ORDER BY _row_id) TO '{tmp.as_posix()}' "
                          f"(FORMAT PARQUET)")
        os.replace(tmp, target)
        for p in pieces:
            p.unlink(missing_ok=True)

    def _register(self, name, agg, **info) -> dict:
        if agg:
            n = self._aggregate(name, agg)
            mode = "table"
        else:
            self._con.execute(f"CREATE OR REPLACE VIEW {_q(name)} AS SELECT * FROM {_q(name + '_detail')}")
            mode = info["mode"]
        rows = self._con.execute(f"SELECT count(*) FROM {_q(name + '_detail')}").fetchall()[0][0]
        entry = {"name": name, "mode": mode, "source": info["source"], "n_files": info["n_files"],
                 "readers": info["readers"], "partial": info["partial"], "month_end": info["month_end"],
                 "agg": bool(agg), "rows": int(rows), "cleaned_path": info["cleaned_path"],
                 "loaded_at": _dt.datetime.now().isoformat(timespec="seconds")}
        if agg:
            entry["agg_rows"] = int(n)
        self._datasets[name] = {"entry": entry, "report": info["report"], "kind": "loaded"}
        return entry

    def _aggregate(self, name: str, agg: dict) -> int:
        """Materialize the agg result as table ``name`` over ``name_detail``."""
        if not isinstance(agg, dict) or "aggs" not in agg:
            raise ValueError("agg must be {'groupby': [...], 'aggs': {col: fn or [fns]}}")
        aggs = _norm_aggs(list(agg["aggs"]), agg["aggs"])
        sql = _build_group_sql(_q(name + "_detail"), _as_list(agg.get("groupby")), aggs)
        self._con.execute(f"CREATE OR REPLACE TABLE {_q(name)} AS {sql}")
        n = self._con.execute(f"SELECT count(*) FROM {_q(name)}").fetchall()[0][0]
        log.info("%s: %s aggregated rows; detail as %s_detail", name, f"{n:,}", name)
        return n

    def _resolve_prompts(self, name: str, spec: dict, sample: pd.DataFrame | None = None,
                         distinct: dict | None = None, which=("to_date", "str_operation")) -> dict:
        """List-form to_date / str_operation / str_sync → dicts: saved answers, else prompt; save answers."""
        spec = dict(spec)
        afile = self._path(self.config["io"]["answers_dir"]) / f"{name}.yaml"
        answers = (yaml.safe_load(afile.read_text(encoding="utf-8")) or {}) if afile.exists() else {}
        changed = False
        for param in which:
            val = spec.get(param)
            if not val or isinstance(val, dict):
                continue
            resolved = {}
            for col in _as_list(val):
                saved = (answers.get(param) or {}).get(col)
                if saved is not None:
                    resolved[col] = saved
                    continue
                if not (_in_notebook() and self.probe_enabled):
                    example = {"to_date": "{'%s': '%%d%%m%%Y'}" % col, "str_operation": "{'%s': ['upper_case']}" % col,
                               "str_sync": "{'%s': {'OLD': 'NEW'}}" % col}[param]
                    raise RuntimeError(f"{param}={val!r} needs answers for '{col}'. Pass a dict instead, e.g. "
                                       f"{param}={example}")
                if param == "to_date":
                    vals = sample[col].dropna().astype(str).head(5).tolist() if sample is not None and col in sample else []
                    print(f"to_date '{col}' — sample values: {vals}")
                    fmts = self.config["clean"]["date_formats"]
                    shown = [f"{f:<20} e.g. {_dt.datetime(2024, 1, 31, 10, 30).strftime(f) if f != 'excel' else '45322 (serial number)'}"
                             for f in fmts] + ["other (type it)"]
                    pick = _ask("format", "pick the format these values use", shown, required=True)
                    fmt = fmts[shown.index(pick)] if pick in shown[:-1] else _ask("format", "strptime format", required=True)
                    resolved[col] = fmt
                elif param == "str_operation":
                    vals = sample[col].dropna().astype(str).head(5).tolist() if sample is not None and col in sample else []
                    print(f"str_operation '{col}' — sample values: {vals}")
                    resolved[col] = _ask("operations", "in the order to apply", sorted(_OPS), required=True, multi=True)
                else:
                    vals = (distinct or {}).get(col, [])
                    print(f"str_sync '{col}' — {len(vals)} distinct values:\n   {vals[:200]}")
                    mapping = {}
                    while True:
                        old = _ask("old value", "blank when done")
                        if old in (None, ""):
                            break
                        mapping[str(old)] = str(_ask("new value", f"replace {old!r} with", required=True))
                    resolved[col] = mapping
                answers.setdefault(param, {})[col] = resolved[col]
                changed = True
            spec[param] = resolved
            print(f"{param}={resolved!r}   ← paste this into the cell to skip the prompt next time")
        if changed:
            afile.write_text(yaml.safe_dump(answers, allow_unicode=True, sort_keys=False), encoding="utf-8")
            log.info("answers saved to %s", afile)
        return spec

    def _post_write(self, name: str, path: Path, spec: dict) -> dict:
        """Whole-file passes in DuckDB: str_sync → dedup (per column, in order) → dedup_combine."""
        res = {}
        src = f"read_parquet('{path.as_posix()}')"
        if spec.get("str_sync"):
            sync = spec["str_sync"]
            if not isinstance(sync, dict):
                distinct = {c: [r[0] for r in self._con.execute(
                    f"SELECT DISTINCT {_q(c)} FROM {src} WHERE {_q(c)} IS NOT NULL ORDER BY 1 LIMIT 1000").fetchall()]
                    for c in _as_list(sync)}
                sync = self._resolve_prompts(name, {"str_sync": sync}, distinct=distinct, which=("str_sync",))["str_sync"]
            cols = [r[0] for r in self._con.execute(f"DESCRIBE SELECT * FROM {src}").fetchall()]
            unknown = [c for c in sync if c not in cols]
            if unknown:
                raise KeyError(f"str_sync: unknown column(s) {unknown}. Available: {cols}")
            counts, repl = {}, []
            for c, mapping in sync.items():
                if not mapping:
                    continue
                cases = " ".join(f"WHEN {_q(c)} = ? THEN ?" for _ in mapping)
                repl.append((c, f"CASE {cases} ELSE {_q(c)} END AS {_q(c)}", [x for kv in mapping.items() for x in kv]))
                olds = list(mapping)
                counts[c] = self._con.execute(
                    f"SELECT count(*) FROM {src} WHERE {_q(c)} IN ({', '.join('?' for _ in olds)})", olds).fetchall()[0][0]
            if repl:
                params = [p for _, _, ps in repl for p in ps]
                self._rewrite(path, f"SELECT * REPLACE ({', '.join(e for _, e, _ in repl)}) FROM {src}", params)
            res["str_sync"] = counts
        if spec.get("dedup") or spec.get("dedup_combine"):
            res.update(self._dedup_parquet(path, _as_list(spec.get("dedup")), _as_list(spec.get("dedup_combine"))))
        return res

    def _rewrite(self, path: Path, select_sql: str, params=None) -> None:
        tmp = path.with_suffix(".rewrite.tmp")
        self._con.execute(f"COPY ({select_sql} ORDER BY _row_id) TO '{tmp.as_posix()}' (FORMAT PARQUET)", params or [])
        os.replace(tmp, path)

    def _dedup_parquet(self, path: Path, dedup: list[str], dedup_combine: list[str]) -> dict:
        """Drop duplicates one column at a time (keep first by _row_id, nulls kept), then on a combination."""
        out = {}
        src = f"read_parquet('{path.as_posix()}')"
        cols = [r[0] for r in self._con.execute(f"DESCRIBE SELECT * FROM {src}").fetchall()]
        unknown = [c for c in dedup + dedup_combine if c not in cols]
        if unknown:
            raise KeyError(f"dedup: unknown column(s) {unknown}. Available: {cols}")
        for c in dedup:
            before = self._con.execute(f"SELECT count(*) FROM {src}").fetchall()[0][0]
            self._rewrite(path, f"SELECT * FROM {src} QUALIFY {_q(c)} IS NULL OR "
                                f"row_number() OVER (PARTITION BY {_q(c)} ORDER BY _row_id) = 1")
            out.setdefault("dedup", {})[c] = before - self._con.execute(f"SELECT count(*) FROM {src}").fetchall()[0][0]
        if dedup_combine:
            before = self._con.execute(f"SELECT count(*) FROM {src}").fetchall()[0][0]
            part = ", ".join(_q(c) for c in dedup_combine)
            self._rewrite(path, f"SELECT * FROM {src} QUALIFY row_number() OVER (PARTITION BY {part} ORDER BY _row_id) = 1")
            out["dedup_combine"] = before - self._con.execute(f"SELECT count(*) FROM {src}").fetchall()[0][0]
        for k, v in out.items():
            log.info("%s: %s", k, v)
        return out

    def _clean_frame(self, df: pd.DataFrame, spec: dict, report: dict, name: str):
        """Whole-frame version of load()'s cleaning (used by load(DataFrame) and clean())."""
        if any(isinstance(spec.get(k), (list, str)) for k in ("to_date", "str_operation")):
            spec = self._resolve_prompts(name, spec, sample=self._preview_clean(df, spec))
        out = _clean_chunk(df, spec, report)
        if spec.get("str_sync"):
            sync = spec["str_sync"]
            if not isinstance(sync, dict):
                distinct = {c: sorted(out[c].dropna().astype(str).unique().tolist()) for c in _as_list(sync)}
                sync = self._resolve_prompts(name, {"str_sync": sync}, distinct=distinct, which=("str_sync",))["str_sync"]
            _check_cols(out, list(sync), "str_sync")
            counts = {}
            for c, mapping in sync.items():
                counts[c] = int(out[c].isin(list(mapping)).sum())
                out[c] = out[c].replace(mapping)
            report["str_sync"] = counts
        for c in _as_list(spec.get("dedup")):
            _check_cols(out, [c], "dedup")
            before = len(out)
            keep = out[c].isna() | ~out.duplicated(subset=[c], keep="first")
            out = out[keep]
            report.setdefault("dedup", {})[c] = before - len(out)
        if spec.get("dedup_combine"):
            _check_cols(out, _as_list(spec["dedup_combine"]), "dedup_combine")
            before = len(out)
            out = out.drop_duplicates(subset=_as_list(spec["dedup_combine"]), keep="first")
            report["dedup_combine"] = before - len(out)
        return out.reset_index(drop=True), spec

    def _drop_objects(self, name: str) -> None:
        for obj in (name, f"{name}_detail"):
            for kind in ("VIEW", "TABLE"):
                try:
                    self._con.execute(f"DROP {kind} IF EXISTS {_q(obj)}")
                except duckdb.Error:
                    pass
            try:
                self._con.unregister(obj)
            except Exception:  # noqa: BLE001
                pass

    # ---------------------------------------------------------------- query
    def _confirm_pull(self, n: int, types: list, no_limit: bool = False) -> bool:
        """Ask (notebook) or warn (script) before pulling more than limits.confirm_rows_above rows."""
        cap = self.config["limits"]["confirm_rows_above"]
        if n <= cap:
            return True
        per_row = sum(50 if "VARCHAR" in str(t).upper() else 8 for t in types)
        gb = n * per_row / 1e9
        msg = f"Pull {n:,} rows (~{gb:.1f} GB est.) into pandas?"
        if no_limit or not (_in_notebook() and self.probe_enabled):
            log.warning("%s proceeding%s", msg, " (no_limit=True)" if no_limit else "")
            return True
        return _ask(f"{msg} [y/N]", default="n") in ("y", "Y", "yes")

    def _notebook_frames(self) -> dict:
        try:
            from IPython import get_ipython  # type: ignore
            ip = get_ipython()
            return {k: v for k, v in (ip.user_ns.items() if ip else []) if isinstance(v, pd.DataFrame) and not k.startswith("_")}
        except Exception:  # noqa: BLE001
            return {}

    @_probe
    def sql(self, query: str, limit: int | None = None, as_name: str | None = None, frames: dict | None = None,
            no_limit: bool = False):
        """Run SQL over datasets and pandas DataFrames; returns a pandas DataFrame (None with as_name=)."""
        q = query.strip().rstrip(";")
        frames = frames or {}
        for k in frames:
            if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", k):
                raise ValueError(f"frames key {k!r} must be an identifier")
        for k in set(self._notebook_frames()) & set(self._datasets):
            if re.search(rf"\b{re.escape(k)}\b", q) and k not in frames:
                log.warning("notebook DataFrame '%s' is shadowed by the dataset of the same name; the dataset is used", k)
        for k, df in frames.items():
            self._con.register(k, df)
        try:
            if as_name:
                if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", as_name):
                    raise ValueError(f"as_name {as_name!r} must be an identifier")
                self._con.execute(f"CREATE OR REPLACE VIEW {_q(as_name)} AS {q}" + (f" LIMIT {int(limit)}" if limit else ""))
                n = self._con.execute(f"SELECT count(*) FROM {_q(as_name)}").fetchall()[0][0]
                self._datasets[as_name] = {"entry": {"name": as_name, "mode": "sql-view", "source": q[:200], "n_files": 0,
                                                     "readers": [], "partial": False, "month_end": False, "agg": False,
                                                     "rows": int(n), "cleaned_path": None,
                                                     "loaded_at": _dt.datetime.now().isoformat(timespec="seconds")},
                                           "report": {}, "kind": "view"}
                log.info("view %s: %s rows", as_name, f"{n:,}")
                return None
            stmts = self._con.extract_statements(q)
            if len(stmts) != 1 or "SELECT" not in str(stmts[0].type):  # DDL / DML / several statements
                self._con.execute(q)
                log.info("statement executed (no result set)")
                return None
            qq = q + (f" LIMIT {int(limit)}" if limit else "")
            n = self._con.execute(f"SELECT count(*) FROM ({qq}) _q").fetchall()[0][0]
            types = [r[1] for r in self._con.execute(f"DESCRIBE {qq}").fetchall()]
            if not self._confirm_pull(n, types, no_limit):
                print("Not pulled. Use limit=…, as_name='…' (keep it in DuckDB), or no_limit=True.")
                return None
            df = self._con.execute(qq).df()
            self.last_result = df
            return df
        except duckdb.Error as e:
            raise type(e)(f"{e}\n-- in query: {q[:200]}") from None
        finally:
            for k in frames:
                try:
                    self._con.unregister(k)
                except Exception:  # noqa: BLE001
                    pass

    @_probe
    def filter(self, name: str, where: str | None = None, columns: list[str] | None = None,
               order_by: str | None = None, limit: int | None = None, as_name: str | None = None,
               no_limit: bool = False):
        """SELECT without writing it: where / columns / order_by / limit; returns a DataFrame."""
        if name not in self._datasets:
            raise KeyError(f"Unknown dataset '{name}'. Loaded: {list(self._datasets)}")
        cols = ", ".join(_q(c) for c in columns) if columns else "*"
        q = f"SELECT {cols} FROM {_q(name)}"
        if where:
            q += f" WHERE {where}"
        if order_by:
            q += f" ORDER BY {order_by}"
        log.debug("filter SQL: %s", q)
        return self.sql(q, limit=limit, as_name=as_name, no_limit=no_limit)

    @_probe
    def pivot(self, name: str, index, values, columns=None, agg="sum", where: str | None = None,
              fill_value: Any = 0, margins: bool = False) -> pd.DataFrame:
        """Pivot table aggregated in DuckDB; agg may list several functions per column."""
        if name not in self._datasets:
            raise KeyError(f"Unknown dataset '{name}'. Loaded: {list(self._datasets)}")
        index, columns, values = _as_list(index), _as_list(columns), _as_list(values)
        aggs = _norm_aggs(values, agg)
        measures = [f"{c}_{'avg' if f == 'mean' else f}" for c, fns in aggs.items() for f in fns]
        src = _q(name)
        flat = self.sql(_build_group_sql(src, index + columns, aggs, where), no_limit=True)
        if not columns:
            out = flat.set_index(index) if index else flat
            if margins:
                tot = self.sql(_build_group_sql(src, [], aggs, where), no_limit=True)
                tot.index = pd.Index(["Total"] if len(index) <= 1 else [tuple(["Total"] * len(index))])
                out = pd.concat([out, tot])
            return out
        wide = flat.pivot_table(index=index, columns=columns, values=measures, aggfunc="first", fill_value=fill_value,
                                dropna=False)
        wide = wide.reindex(columns=measures, level=0)
        if margins:
            by_idx = self.sql(_build_group_sql(src, index, aggs, where), no_limit=True).set_index(index)
            for m in measures:
                key = (m, "Total") if len(columns) == 1 else (m,) + ("Total",) * len(columns)
                wide[key] = by_idx[m]
            by_col = self.sql(_build_group_sql(src, columns, aggs, where), no_limit=True)
            overall = self.sql(_build_group_sql(src, [], aggs, where), no_limit=True)
            row = {}
            for m in measures:
                for _, r in by_col.iterrows():
                    ck = tuple(r[c] for c in columns)
                    row[(m,) + ck] = r[m]
                row[(m, "Total") if len(columns) == 1 else (m,) + ("Total",) * len(columns)] = overall[m].iloc[0]
            label = "Total" if len(index) == 1 else tuple(["Total"] * len(index))
            wide.loc[label] = pd.Series(row)
            wide = wide.reindex(columns=measures, level=0)
        return wide

    @_probe
    def explore(self, data, group_by: list[str] | None = None, rows: list[str] | None = None,
                cols: list[str] | None = None):
        """Drag-and-drop pivot table (pivottablejs); pre-aggregates in DuckDB above explore.max_rows."""
        try:
            from pivottablejs import pivot_ui
        except ImportError:
            raise ImportError("explore() needs pivottablejs: pip install pivottablejs") from None
        cap = self.config["explore"]["max_rows"]
        if isinstance(data, pd.DataFrame):
            label, n = "dataframe", len(data)
            self._con.register("_qa_explore_src", data)
            src = "_qa_explore_src"
        else:
            if data not in self._datasets:
                raise KeyError(f"Unknown dataset '{data}'. Loaded: {list(self._datasets)}")
            label, src = data, _q(data)
            n = self._con.execute(f"SELECT count(*) FROM {src}").fetchall()[0][0]
        try:
            opts: dict = {}
            if n <= cap:
                df = self._con.execute(f"SELECT * FROM {src}").df()
            else:
                types = dict(self._con.execute(f"DESCRIBE SELECT * FROM {src}").fetchall() and
                             [(r[0], r[1]) for r in self._con.execute(f"DESCRIBE SELECT * FROM {src}").fetchall()])
                if group_by is None:
                    if not (_in_notebook() and self.probe_enabled):
                        raise ValueError(f"{label} has {n:,} rows > explore.max_rows ({cap:,}). Pass group_by=[...] "
                                         f"to pre-aggregate on the columns you want to pivot.")
                    print(f"{label} has {n:,} rows > {cap:,}. Pick columns to pivot on (pre-aggregated in DuckDB):")
                    group_by = _ask("group_by", "", [c for c in types if c != "_row_id"], required=True, multi=True)
                group_by = _as_list(group_by)
                nums = [c for c, t in types.items() if c not in group_by and c != "_row_id" and
                        re.match(r"(BIGINT|INTEGER|SMALLINT|TINYINT|HUGEINT|DOUBLE|FLOAT|REAL|DECIMAL|UBIGINT|UINTEGER)", t)]
                sel = ", ".join([_q(g) for g in group_by] + ["count(*) AS n_rows"] + [f"sum({_q(c)}) AS {_q(c)}" for c in nums])
                df = self._con.execute(f"SELECT {sel} FROM {src} GROUP BY ALL").df()
                if len(df) > cap:
                    worst = max(group_by, key=lambda g: self._con.execute(f"SELECT count(DISTINCT {_q(g)}) FROM {src}").fetchall()[0][0])
                    raise ValueError(f"Grouping on {group_by} still gives {len(df):,} rows > {cap:,}. "
                                     f"'{worst}' has the most distinct values — leave it out.")
                opts = {"aggregatorName": "Integer Sum", "vals": ["n_rows"]}
                log.info("%s: %s rows pre-aggregated to %s on %s (averages: use 'Sum over Sum')", label, f"{n:,}",
                         f"{len(df):,}", group_by)
        finally:
            if src == "_qa_explore_src":
                self._con.unregister("_qa_explore_src")
        for c in df.columns:  # pivottable.js works on text-like values
            if pd.api.types.is_datetime64_any_dtype(df[c]):
                df[c] = df[c].dt.strftime("%Y-%m-%d")
        out = self._path(self.config["explore"]["output_dir"]) / f"{label}__{_dt.datetime.now():%Y%m%d_%H%M%S}.html"
        pivot_ui(df, outfile_path=str(out), rows=rows or [], cols=cols or [], **opts)
        log.info("explore: %s rows → %s", f"{len(df):,}", out)
        import warnings
        from IPython.display import HTML
        html = out.read_text(encoding="utf-8")
        srcdoc = html.replace("&", "&amp;").replace('"', "&quot;")
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            return HTML(f'<iframe srcdoc="{srcdoc}" style="width:100%;height:560px;border:0"></iframe>')

    @_probe
    def chart(self, data, kind: str, x: str, y=None, color: str | None = None, title: str | None = None,
              save: str | None = None, no_limit: bool = False, **kwargs):
        """Plotly chart from a DataFrame or dataset name; returns the figure."""
        import plotly.express as px
        kinds = {"bar": px.bar, "line": px.line, "scatter": px.scatter, "hist": px.histogram, "box": px.box,
                 "pie": px.pie, "heatmap": px.density_heatmap}
        if kind not in kinds:
            raise ValueError(f"Unknown kind '{kind}'. Valid: {sorted(kinds)}")
        df = data if isinstance(data, pd.DataFrame) else self.sql(f"SELECT * FROM {_q(data)}", no_limit=no_limit)
        if df is None:
            return None
        if kind == "pie":
            fig = px.pie(df, names=x, values=y, color=color, title=title, template=self.config["chart"]["template"], **kwargs)
        else:
            fig = kinds[kind](df, x=x, y=y, color=color, title=title, template=self.config["chart"]["template"], **kwargs)
        if save:
            p = Path(save)
            p = p if p.is_absolute() else self._path(self.config["chart"]["export_dir"]) / p
            p.parent.mkdir(parents=True, exist_ok=True)
            fig.write_image(p) if p.suffix.lower() == ".png" else fig.write_html(p)
            log.info("chart saved %s", p)
        return fig

    # ---------------------------------------------------------------- outputs
    @_probe
    def to_markdown(self, obj, note: str | None = None, sample_rows: int | None = None,
                    max_unique: int | None = None, mask_strings: bool | None = None) -> str:
        """Write an AI prompt (task, how to answer, module reference, data) to describe.prompt_path."""
        d = self.config["describe"]
        sample_rows = d["sample_rows"] if sample_rows is None else sample_rows
        max_unique = d["max_unique_values"] if max_unique is None else max_unique
        mask = d["mask_strings"] if mask_strings is None else mask_strings
        maxlen = d["max_string_length"]
        parts = ["# Task", note or "(no question given — describe what you can help with for this data)", "",
                 "# How to answer",
                 "Help me analyse this data in a Jupyter notebook with the `quickishanalysis` module (session object "
                 "`qa`). Prefer qa.* calls and DuckDB SQL via qa.sql() over raw pandas. The data lives in DuckDB; "
                 "only pull small results into pandas. Reply with code cells I can paste and run. "
                 "If something can't be answered from the description below, tell me which query to run first.", "",
                 "# Module reference", _module_reference(type(self)), "", "# Data"]
        named = [obj] if isinstance(obj, (str, pd.DataFrame)) else list(obj)
        for item in named:
            parts += self._describe(item, sample_rows, max_unique, mask, maxlen)
        names = {n for n in named if isinstance(n, str)}
        others = [n for n in self._datasets if n not in names]
        if others:
            parts += ["## Other datasets (name: columns)"]
            for n in others:
                cols = [r[0] for r in self._con.execute(f"DESCRIBE SELECT * FROM {_q(n)}").fetchall()]
                parts.append(f"- {n}: {', '.join(cols)}")
        text = "\n".join(parts) + "\n"
        path = self._path(d["prompt_path"])
        path.write_text(text, encoding="utf-8")
        copied = False
        try:
            import pyperclip
            pyperclip.copy(text)
            copied = True
        except Exception:  # noqa: BLE001 - pyperclip missing or no clipboard
            pass
        log.info("Prompt written to %s%s", path, " and copied to clipboard" if copied else "")
        return text

    def _describe(self, item, sample_rows, max_unique, mask, maxlen) -> list[str]:
        unmasked = {"_source_file", "_sheet", "month_end"}

        def fmt_val(v, col=None):
            if isinstance(v, pd.Timestamp):
                return v.strftime("%Y-%m-%d") if v == v.normalize() else str(v)
            if isinstance(v, str):
                if mask and col not in unmasked:
                    return _mask_value(v, maxlen)
                return v if len(v) <= maxlen else v[: maxlen - 1] + "…"
            return v
        if isinstance(item, pd.DataFrame):
            df = item
            title = "## In-memory pandas DataFrame (not in DuckDB — suggest qa.load('name', df) if SQL helps)"
            shape = f"**Shape:** {len(df):,} rows × {df.shape[1]} columns"
            schema = pd.DataFrame({"column": df.columns, "dtype": [str(t) for t in df.dtypes],
                                   "example": [fmt_val(df[c].dropna().iloc[0], c) if df[c].notna().any() else "" for c in df.columns]})
            sample = df.head(sample_rows)
            uniq = {c: (sorted(map(str, df[c].dropna().unique()))[:max_unique], df[c].nunique())
                    for c in df.columns if _is_text(df[c])}
            extra = []
        else:
            if item not in self._datasets:
                raise KeyError(f"Unknown dataset '{item}'. Loaded: {list(self._datasets)}")
            meta = self._datasets[item]
            e = meta["entry"]
            n = self._con.execute(f"SELECT count(*) FROM {_q(item)}").fetchall()[0][0]
            desc = self._con.execute(f"DESCRIBE SELECT * FROM {_q(item)}").fetchall()
            title = f"## Dataset `{item}`"
            shape = (f"**Shape:** {n:,} rows × {len(desc)} columns · mode {e['mode']} · source: {e['source']}"
                     + (f" ({e['n_files']} files)" if e.get("n_files", 0) > 1 else "")
                     + (f" · detail rows in `{item}_detail` ({e['rows']:,})" if e.get("agg") else ""))
            sample = self._con.execute(f"SELECT * FROM {_q(item)} LIMIT {int(sample_rows)}").df()
            ex = self._con.execute(f"SELECT * FROM {_q(item)} LIMIT 200").df()
            schema = pd.DataFrame({"column": [r[0] for r in desc], "dtype": [r[1] for r in desc],
                                   "example": [fmt_val(ex[r[0]].dropna().iloc[0], r[0]) if ex[r[0]].notna().any() else ""
                                               for r in desc]})
            uniq = {}
            for c, t, *_ in desc:
                if t == "VARCHAR":
                    vals = [r[0] for r in self._con.execute(
                        f"SELECT DISTINCT {_q(c)} FROM {_q(item)} WHERE {_q(c)} IS NOT NULL ORDER BY 1 LIMIT {int(max_unique) + 1}").fetchall()]
                    total = self._con.execute(f"SELECT approx_count_distinct({_q(c)}) FROM {_q(item)}").fetchall()[0][0]
                    uniq[c] = (vals[:max_unique], total)
            extra = []
            if e.get("partial"):
                extra.append("**PARTIAL LOAD:** loaded with nrows=…, totals are not the full data.")
            rep = {k: v for k, v in meta.get("report", {}).items() if k != "rows"}
            if rep:
                extra += ["### Cleaning applied"] + [f"- {k}: {json.dumps(v, default=str)}" for k, v in rep.items()]
        sample = sample.copy()
        for c in sample.columns:
            if _is_text(sample[c]) or pd.api.types.is_datetime64_any_dtype(sample[c]):
                sample[c] = sample[c].astype(object).map(lambda v, c=c: fmt_val(v, c))
        lines = [title, shape, *extra, "### Schema", _df_to_md_table(schema, max_rows=500),
                 f"### Sample rows ({len(sample)})", _df_to_md_table(sample)]
        if uniq:
            lines.append("### Unique values (text columns)")
            nrows = len(item) if isinstance(item, pd.DataFrame) else self._con.execute(
                f"SELECT count(*) FROM {_q(item)}").fetchall()[0][0]
            for c, (vals, total) in uniq.items():
                if total and nrows and total > 1000 and total >= 0.5 * nrows:
                    lines.append(f"- {c}: ~{total:,} distinct values — looks like an ID / free text, not listed")
                    continue
                shown_vals = [str(fmt_val(v, c)) for v in vals]
                if mask and c not in unmasked:
                    shown_vals = [f"{v} ({shown_vals.count(v)} values)" if shown_vals.count(v) > 1 else v
                                  for v in dict.fromkeys(shown_vals)]
                more = f" (+{total - len(vals)} more)" if total and total > len(vals) else ""
                lines.append(f"- {c} (~{total}): {', '.join(shown_vals)}{more}")
        return lines + [""]

    @_probe
    def clean(self, df: pd.DataFrame, name: str = "clean", rename=None, normalize=None, to_int=None, to_float=None,
              to_str=None, to_date=None, str_operation=None, drop_empty=None, where=None, str_sync=None, dedup=None,
              dedup_combine=None):
        """Apply load()'s cleaning parameters to a small in-memory DataFrame; returns (df, report)."""
        spec = {"rename": rename, "normalize": self.config["clean"]["normalize"] if normalize is None else normalize,
                "to_int": to_int, "to_float": to_float, "to_str": to_str, "to_date": to_date,
                "str_operation": str_operation, "drop_empty": drop_empty, "where": where, "str_sync": str_sync,
                "dedup": dedup, "dedup_combine": dedup_combine}
        report: dict = {}
        out, _ = self._clean_frame(df, spec, report, name)
        self.last_clean_report = report
        return out, report

    @_probe
    def export(self, source, path, fmt: str | None = None, sheet_name: str = "Sheet1", no_limit: bool = False):
        """Write a dataset, SELECT or DataFrame with pandas to .csv (utf-8-sig) / .parquet (fastparquet GZIP) / .xlsx."""
        if isinstance(source, pd.DataFrame):
            df = source
        elif source in self._datasets:
            df = self.sql(f"SELECT * FROM {_q(source)}", no_limit=no_limit)
        else:
            df = self.sql(source, no_limit=no_limit)
        if df is None:
            log.warning("export cancelled: nothing written")
            return None
        p = self._data_path(path)
        fmt = (fmt or p.suffix.lstrip(".")).lower()
        p.parent.mkdir(parents=True, exist_ok=True)
        if fmt == "csv":
            df.to_csv(p, header=True, index=False, encoding="utf-8-sig")
        elif fmt == "parquet":
            df.to_parquet(p, engine="fastparquet", compression="GZIP")
        elif fmt in ("xlsx", "excel"):
            if len(df) > 1_048_576:
                raise ValueError(f"{len(df):,} rows exceed Excel's 1,048,576-row limit; export to csv or parquet")
            df.to_excel(p, sheet_name=sheet_name, index=False)
        else:
            raise ValueError(f"Unknown format '{fmt}'. Use csv, parquet or xlsx")
        log.info("Exported %s rows → %s", f"{len(df):,}", p)
        return p

    # ---------------------------------------------------------------- housekeeping
    def datasets(self) -> pd.DataFrame:
        """Registered datasets: mode, source, files, readers, partial, month_end, agg, rows."""
        rows = [m["entry"] for m in self._datasets.values()]
        cols = ["name", "mode", "rows", "n_files", "readers", "partial", "month_end", "agg", "source", "loaded_at"]
        return pd.DataFrame(rows, columns=cols)

    @_probe
    def drop(self, name: str) -> None:
        """Unregister a dataset (and its _detail twin) and delete its session Parquet."""
        if name not in self._datasets:
            raise KeyError(f"Unknown dataset '{name}'. Loaded: {list(self._datasets)}")
        self._drop_objects(name)
        p = self._datasets.pop(name)["entry"].get("cleaned_path")
        if p:
            Path(p).unlink(missing_ok=True)
        log.info("dropped %s", name)
